package com.raccoonsquare.reels.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.ImageLoader;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Item;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.List;


public class AdvancedItemListAdapter extends RecyclerView.Adapter<AdvancedItemListAdapter.ViewHolder> implements Constants {

    private List<Item> items = new ArrayList<>();

    private Context context;

    ImageLoader imageLoader = App.getInstance().getImageLoader();

    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {

        void onItemClick(View view, Item obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {

        this.mOnItemClickListener = mItemClickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public CircularImageView mItemAuthorPhoto, mItemVerifiedIcon;
        public TextView mItemAuthorFullname, mItemDescription, mItemLikesCount;
        public LinearLayout mItemLabelLayout;
        public RelativeLayout mParentLayout;
        public ProgressBar mItemImageProgress;

        public ImageView mItemImg;

        public ViewHolder(View v, int itemType) {

            super(v);

            mParentLayout = (RelativeLayout) v.findViewById(R.id.parent_layout);

            mItemImageProgress = v.findViewById(R.id.item_image_progress);
            mItemAuthorPhoto = (CircularImageView) v.findViewById(R.id.user_image);
            mItemVerifiedIcon = v.findViewById(R.id.verified_image);

            mItemLabelLayout = v.findViewById(R.id.item_label_layout);

            mItemAuthorFullname = v.findViewById(R.id.first_last_name_txt);
            mItemDescription = v.findViewById(R.id.description_txt);
            mItemLikesCount = v.findViewById(R.id.likes_count_txt);

            mItemImg = v.findViewById(R.id.item_image);
        }

    }

    public AdvancedItemListAdapter(Context ctx, List<Item> items) {

        this.context = ctx;
        this.items = items;

        if (imageLoader == null) {

            imageLoader = App.getInstance().getImageLoader();
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video_layout, parent, false);

        return new ViewHolder(v, viewType);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final Item p = items.get(position);

        onBindItem(holder, position);
    }

    public void onBindItem(ViewHolder holder, final int position) {

        final Item p = items.get(position);

        holder.mItemLabelLayout.setVisibility(View.GONE);

        if (p.getRating() > 1000) {

            holder.mItemLabelLayout.setVisibility(View.VISIBLE);
        }

        holder.mItemVerifiedIcon.setVisibility(View.GONE);

        if (p.getFromUserVerify() == 1) {

            holder.mItemVerifiedIcon.setVisibility(View.VISIBLE);
        }

        holder.mItemAuthorPhoto.setVisibility(View.VISIBLE);

        if (p.getFromUserPhotoUrl().length() != 0) {

            imageLoader.get(p.getFromUserPhotoUrl(), ImageLoader.getImageListener(holder.mItemAuthorPhoto, R.drawable.profile_default_photo, R.drawable.profile_default_photo));

        } else {

            holder.mItemAuthorPhoto.setVisibility(View.VISIBLE);
            holder.mItemAuthorPhoto.setImageResource(R.drawable.profile_default_photo);
        }

        holder.mItemImg.setVisibility(View.GONE);
        holder.mItemImageProgress.setVisibility(View.VISIBLE);

        if (p.getPreviewVideoImgUrl().length() == 0) {

            p.setPreviewVideoImgUrl("https://images.pexels.com/photos/5086489/pexels-photo-5086489.jpeg");
        }

        if (p.getPreviewVideoImgUrl().length() != 0) {

            final ProgressBar progressView = holder.mItemImageProgress;
            final ImageView imageView = holder.mItemImg;

            Picasso.with(context)
                    .load(p.getPreviewVideoImgUrl())
                    .into(holder.mItemImg, new Callback() {

                        @Override
                        public void onSuccess() {

                            imageView.setVisibility(View.VISIBLE);
                            progressView.setVisibility(View.GONE);
                        }

                        @Override
                        public void onError() {

                            progressView.setVisibility(View.GONE);
                            imageView.setVisibility(View.VISIBLE);
                            imageView.setImageResource(R.drawable.img_loading_error);
                        }
                    });

        }

        if (p.getFromUserProfileType() == 0) {

            holder.mItemAuthorFullname.setText(p.getFromUserFullname());

        } else {

            holder.mItemAuthorFullname.setText(p.getFromUserCompany());
        }

        holder.mItemDescription.setText(p.getPost());

        holder.mItemLikesCount.setText(Integer.toString(p.getLikesCount()));

        holder.mParentLayout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (mOnItemClickListener != null) {

                    mOnItemClickListener.onItemClick(view, p, position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {

        return items.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {

        final Item p = items.get(position);

        if (p.getAd() == 0) {

            return 0;

        } else {

            return 1;
        }
    }
}