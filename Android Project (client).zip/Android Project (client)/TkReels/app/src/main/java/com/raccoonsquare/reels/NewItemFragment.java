package com.raccoonsquare.reels;

import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_CANCEL;
import static com.arthenica.mobileffmpeg.Config.RETURN_CODE_SUCCESS;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.Editable;
import android.text.InputFilter;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.webkit.MimeTypeMap;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.SwitchCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.aghajari.emojiview.view.AXEmojiEditText;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.arthenica.mobileffmpeg.Config;
import com.arthenica.mobileffmpeg.FFmpeg;
import com.balysv.materialripple.MaterialRippleLayout;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.otaliastudios.transcoder.Transcoder;
import com.otaliastudios.transcoder.TranscoderListener;
import com.otaliastudios.transcoder.strategy.DefaultVideoStrategy;
import com.raccoonsquare.reels.adapter.FeelingsListAdapter;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Feeling;
import com.raccoonsquare.reels.model.Item;
import com.raccoonsquare.reels.util.Api;
import com.raccoonsquare.reels.util.CountingRequestBody;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.util.Helper;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import okhttp3.Call;
import okhttp3.Interceptor;
import okhttp3.MultipartBody;

public class NewItemFragment extends Fragment implements Constants {

    private static final int BUFFER_SIZE = 1024 * 2;

    private static final int VIDEO_FILES_LIMIT = 1;
    private static final int IMAGE_FILES_LIMIT = 18;

    public static final int REQUEST_TAKE_GALLERY_VIDEO = 1001;

    private static final String STATE_LIST = "State Adapter Data";

    public static final int RESULT_OK = -1;

    private static final int ITEM_FEELINGS = 1;

    private FusedLocationProviderClient mFusedLocationClient;
    protected Location mLastLocation;

    TextView mTitleCounter, mDescCounter;

    private MaterialRippleLayout mOpenBottomSheet;
    private ImageView mPreviewImage, mPlayImage;

    private BottomSheetBehavior mBehavior;
    private BottomSheetDialog mBottomSheetDialog;
    private View mBottomSheet;
    private LinearLayout mFooterLayout;
    private Button mActionButton;
    private MaterialRippleLayout mActionButtonLayout;
    private SwitchCompat mPrivacySwitch, mCommentsSwitch;
    private ProgressDialog pDialog;

    private AXEmojiEditText mPostEdit;
    private int position = 0;

    private Item item;

    private Boolean loading = false;
    private Boolean uploading = false;
    private Boolean compressing = false;

    private String selectedCameraImg = "";

    String selectedVideoPath, selectedVideoThumb;

    private ActivityResultLauncher<String> cameraPermissionLauncher;
    private ActivityResultLauncher<String[]> storagePermissionLauncher;
    private ActivityResultLauncher<Intent> imgFromCameraActivityResultLauncher;
    private ActivityResultLauncher<Intent> imgFromGalleryActivityResultLauncher;
    private ActivityResultLauncher<Intent> videoFromGalleryActivityResultLauncher;

    private ActivityResultLauncher<Intent> videoFromCameraActivityResultLauncher;
    private ActivityResultLauncher<String> recordAudioPermissionLauncher;
    private ActivityResultLauncher<String[]> videoCapturePermissionLauncher;

    public NewItemFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setRetainInstance(true);
        setHasOptionsMenu(false);

        initpDialog();

        Intent i = getActivity().getIntent();

        position = i.getIntExtra("position", 0);

        if (i.getExtras() != null) {

            item = (Item) i.getExtras().getParcelable("item");

            if (item == null) {

                item = new Item();
            }

        } else {

            item = new Item();
        }

        item.setSoundId(App.getInstance().getSelectedSoundId());
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_new_item, container, false);

        if (savedInstanceState != null) {

            item = savedInstanceState.getParcelable("item");

            loading = savedInstanceState.getBoolean("loading");
            uploading = savedInstanceState.getBoolean("uploading");
            compressing = savedInstanceState.getBoolean("compressing");

        } else {

            loading = false;
            uploading = false;
            compressing = false;
        }

        //

        Helper helper = new Helper(App.getInstance().getApplicationContext());

        File file =  new File(App.getInstance().getDirectory(), VIDEO_SRC_FILE);

        if (file.exists()) {

            Log.e("MyApp file size: ", Long.toString(file.length()));

            selectedVideoPath = file.getPath();

            String video_file = Uri.fromFile(new File(App.getInstance().getDirectory(), VIDEO_SRC_FILE)).toString();
            String thumb_file = Uri.fromFile(new File(App.getInstance().getDirectory(), VIDEO_THUMBNAIL_FILE)).toString();

            helper.ffmpegCreateThumbnail(video_file, thumb_file);

            selectedVideoThumb = VIDEO_THUMBNAIL_FILE;

        } else {

            String video_file = Uri.fromFile(new File(App.getInstance().getSelectedVideoPath())).toString();
            String thumb_file = Uri.fromFile(new File(App.getInstance().getDirectory(), VIDEO_THUMBNAIL_FILE)).toString();

            helper.ffmpegCreateThumbnail(video_file, thumb_file);

            selectedVideoPath = App.getInstance().getSelectedVideoPath();
            selectedVideoThumb = VIDEO_THUMBNAIL_FILE;
        }

        //

        videoCapturePermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), (Map<String, Boolean> isGranted) -> {

            boolean granted = true;

            for (Map.Entry<String, Boolean> x : isGranted.entrySet())

                if (!x.getValue()) granted = false;

            if (granted) {

                captureVideo();

            } else {

                // Permission is denied

                Log.e("Permissions", "denied");

                Snackbar.make(getView(), getString(R.string.label_no_camera_or_video_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(getActivity(), getString(R.string.label_grant_camera_and_audio_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }
        });

        //

        videoFromCameraActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == 100) {

                    File file =  new File(App.getInstance().getDirectory(), VIDEO_SRC_FILE);

                    if (file.exists()) {

                        Log.e("MyApp file size: ", Long.toString(file.length()));

                        //
                    }
                }
            }
        });

        //

        videoFromGalleryActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    // The document selected by the user won't be returned in the intent.
                    // Instead, a URI to that document will be contained in the return intent
                    // provided to this method as a parameter.  Pull that uri using "resultData.getData()"

                    if (result.getData() != null) {

                        String selectedImagePath = Helper.getRealPath(result.getData().getData());

                        File videoFile = new File(selectedImagePath);

                        if (videoFile.length() > VIDEO_FILE_MAX_SIZE_FROM_GALLERY) {

                            Toast.makeText(getActivity(), getString(R.string.msg_video_too_large), Toast.LENGTH_SHORT).show();

                        } else {

                            //
                        }
                    }
                }
            }
        });

        //

        cameraPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {

            if (isGranted) {

                // Permission is granted
                Log.e("Permissions", "Permission is granted");

                choiceImageAction();

            } else {

                // Permission is denied

                Log.e("Permissions", "denied");

                Snackbar.make(getView(), getString(R.string.label_no_camera_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(getActivity(), getString(R.string.label_grant_camera_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }
        });

        //

        storagePermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), (Map<String, Boolean> isGranted) -> {

            boolean granted = false;
            String storage_permission = Manifest.permission.READ_EXTERNAL_STORAGE;

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

                storage_permission = Manifest.permission.READ_MEDIA_IMAGES;
            }

            for (Map.Entry<String, Boolean> x : isGranted.entrySet()) {

                if (x.getKey().equals(storage_permission)) {

                    if (x.getValue()) {

                        granted = true;
                    }
                }
            }

            if (granted) {

                Log.e("Permissions", "granted");

                showBottomSheet();

            } else {

                Log.e("Permissions", "denied");

                Snackbar.make(getView(), getString(R.string.label_no_storage_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(getActivity(), getString(R.string.label_grant_storage_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }

        });

        //

        imgFromCameraActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    String selectedImagePath = new File(App.getInstance().getDirectory(), selectedCameraImg).getPath();

                    //
                }
            }
        });

        //

        imgFromGalleryActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    // The document selected by the user won't be returned in the intent.
                    // Instead, a URI to that document will be contained in the return intent
                    // provided to this method as a parameter.  Pull that uri using "resultData.getData()"

                    if (result.getData() != null) {

                        String newFileName = Helper.randomString(6) + ".jpg";

                        Helper helper = new Helper(App.getInstance().getApplicationContext());
                        helper.createImage(result.getData().getData(), newFileName);

                        String selectedImagePath = new File(App.getInstance().getDirectory(), newFileName).getPath();

                        //
                    }
                }
            }
        });

        //

        if (loading) {

            showpDialog();
        }

        //

        mTitleCounter = (TextView) rootView.findViewById(R.id.title_counter);

        //

        mFooterLayout = (LinearLayout) rootView.findViewById(R.id.footer_layout);
        mFooterLayout.setVisibility(View.VISIBLE);

        mOpenBottomSheet = (MaterialRippleLayout) rootView.findViewById(R.id.open_bottom_sheet_button);
        mOpenBottomSheet.setVisibility(View.GONE);

        mOpenBottomSheet.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                showBottomSheet();
            }
        });

        // Prepare bottom sheet

        mBottomSheet = rootView.findViewById(R.id.bottom_sheet);
        mBehavior = BottomSheetBehavior.from(mBottomSheet);

        //

        mPlayImage = rootView.findViewById(R.id.play_image);
        mPlayImage.setVisibility(View.VISIBLE);

        mPreviewImage = (ImageView) rootView.findViewById(R.id.video_image);

        mPreviewImage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent i = new Intent(getActivity(), CapturePreviewActivity.class);
                i.putExtra("imagePath", selectedVideoPath);
                i.putExtra("videoUrl", item.getVideoUrl());
                i.putExtra("previewMode", 1);
                startActivity(i);
            }
        });

        if (item.getId() != 0) {

            ImageLoader imageLoader = App.getInstance().getImageLoader();
            imageLoader.get(item.getPreviewVideoImgUrl(), ImageLoader.getImageListener(mPreviewImage, R.drawable.ic_video_preview_src, R.drawable.ic_video_preview_src));

        } else {

            mPreviewImage.setImageURI(Uri.fromFile(new File(App.getInstance().getDirectory(), VIDEO_THUMBNAIL_FILE)));
        }

        //

        mPrivacySwitch = (SwitchCompat) rootView.findViewById(R.id.privacy_switch);

        mPrivacySwitch.setChecked(true);

        if (item.getPrivacyType() != 0) {

            mPrivacySwitch.setChecked(false);
        }

        //

        mCommentsSwitch = (SwitchCompat) rootView.findViewById(R.id.allow_comments_switch);

        mCommentsSwitch.setChecked(true);

        if (item.getAllowComments() != 1) {

            mCommentsSwitch.setChecked(false);
        }

        //

        mActionButtonLayout = (MaterialRippleLayout) rootView.findViewById(R.id.action_button_layout);

        mActionButton = (Button) rootView.findViewById(R.id.action_button);
        mActionButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(Context.INPUT_METHOD_SERVICE);

                View focusedView = getActivity().getCurrentFocus();

                if (focusedView != null) {

                    imm.hideSoftInputFromWindow(focusedView.getWindowToken(), 0);
                }

                //

                item.setPost(mPostEdit.getText().toString().trim());

                //

                item.setAllowComments(1);

                if (!mCommentsSwitch.isChecked()) {

                    item.setAllowComments(0);
                }

                //

                item.setPrivacyType(0);

                if (!mPrivacySwitch.isChecked()) {

                    item.setPrivacyType(1);
                }

                //

                loading = true;

                if (item.getPost().length() > 0) {

                    uploadImages(0);

                } else {

                    Toast.makeText(getActivity(), getActivity().getString(R.string.error_field_empty), Toast.LENGTH_SHORT).show();
                }
            }
        });

        //

        mPostEdit = (AXEmojiEditText) rootView.findViewById(R.id.post_edit);

        setEditTextMaxLength(VIDEO_TITLE_LIMIT);

        mPostEdit.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable s) {
                // TODO Auto-generated method stub

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                int cnt = s.length();

                mTitleCounter.setText(Integer.toString(cnt) + "/" + Integer.toString(VIDEO_TITLE_LIMIT));
            }
        });

        mPostEdit.setText(item.getPost().replaceAll("<br>", "\n"));

        updateTitle();

        // Inflate the layout for this fragment
        return rootView;
    }

    private void updateTitle() {

        if (isAdded()) {

            if (item.getId() != 0) {

                getActivity().setTitle(getText(R.string.title_edit_item));
                mActionButton.setText(getString(R.string.action_save));

            } else {

                getActivity().setTitle(getText(R.string.title_new_item));
                mActionButton.setText(getString(R.string.action_post));
            }
        }
    }

    public void setEditTextMaxLength(int length) {

        InputFilter[] FilterArray = new InputFilter[1];
        FilterArray[0] = new InputFilter.LengthFilter(length);
        mPostEdit.setFilters(FilterArray);
    }

    public void onDestroy() {

        super.onDestroy();

        hidepDialog();
    }

    public void onDestroyView() {

        super.onDestroyView();

        hidepDialog();
    }

    protected void initpDialog() {

        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage(getString(R.string.msg_loading));
        pDialog.setCancelable(false);
    }

    protected void showpDialog() {

        if (pDialog == null) {

            initpDialog();
        }

        if (uploading) {

            pDialog.setMessage(getString(R.string.msg_uploading));
            pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);

        } else {

            if (compressing) {

                pDialog.setMessage(getString(R.string.msg_compressing_video));
                pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
            }
        }

        pDialog.setProgressNumberFormat(null);
        pDialog.setProgress(0);
        pDialog.setMax(100);

        if (!pDialog.isShowing()) pDialog.show();
    }

    protected void hidepDialog() {

        if (pDialog.isShowing() && pDialog != null) pDialog.dismiss();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putParcelable("item", item);

        outState.putBoolean("loading", loading);
        outState.putBoolean("loading", loading);
        outState.putBoolean("compressing", compressing);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        // Inflate the menu; this adds items to the action bar if it is present.

        super.onCreateOptionsMenu(menu, inflater);
    }

    private void uploadImages(int index) {

        Log.e("uploadImages", "uploadImages:" + Integer.toString(index));

        if (item.getId() == 0 && item.getVideoUrl().length() == 0) {

            File f = new File(selectedVideoPath);
            File f_thumb = new File(App.getInstance().getDirectory(), VIDEO_THUMBNAIL_FILE);

            //uploadVideoFile(METHOD_VIDEO_UPLOAD, f, f_thumb);

            if (f.length() > VIDEO_FILE_MAX_SIZE) {

                compressingVideoFile(f, new File(App.getInstance().getDirectory(), VIDEO_DEST_FILE));

            } else {

                prepareToUploadVideo(f, f_thumb);
            }

        } else {

            sendPost();
        }
    }

    public void choiceImageAction() {

        AlertDialog.Builder builderSingle = new AlertDialog.Builder(getActivity());

        final ArrayAdapter<String> arrayAdapter = new ArrayAdapter<String>(getActivity(), android.R.layout.simple_list_item_1);

        arrayAdapter.add(getText(R.string.action_gallery).toString());
        arrayAdapter.add(getText(R.string.action_camera).toString());

        builderSingle.setTitle(getText(R.string.dlg_choice_image_title));


        builderSingle.setAdapter(arrayAdapter, new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                switch (which) {

                    case 0: {

                        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                        intent.addCategory(Intent.CATEGORY_OPENABLE);
                        intent.setType("image/jpeg");

                        imgFromGalleryActivityResultLauncher.launch(intent);

                        break;
                    }

                    default: {

                        Helper helper = new Helper(getActivity());

                        if (helper.checkPermission(Manifest.permission.CAMERA)) {

                            try {

                                selectedCameraImg = Helper.randomString(6) + ".jpg";

                                Uri selectedImage = FileProvider.getUriForFile(App.getInstance().getApplicationContext(), App.getInstance().getPackageName() + ".provider", new File(App.getInstance().getDirectory(), selectedCameraImg));

                                Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                                cameraIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, selectedImage);
                                cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                                cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);

                                imgFromCameraActivityResultLauncher.launch(cameraIntent);

                            } catch (Exception e) {

                                Log.e("Camera", "Error occured. Please try again later.");
                            }

                        } else {

                            requestCameraPermission();
                        }

                        break;
                    }
                }
            }
        });

        builderSingle.setNegativeButton(getText(R.string.action_cancel), new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {

                dialog.dismiss();
            }
        });

        AlertDialog d = builderSingle.create();
        d.show();
    }

    public void sendPost() {

        if (this.item.getId() != 0) {

            savePost();

        } else {

            newPost();
        }
    }

    private void savePost() {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ITEMS_EDIT, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {


                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            savePostSuccess();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                savePostSuccess();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());

                params.put("postId", Long.toString(item.getId()));
                params.put("rePostId", Long.toString(item.getRePostId()));
                params.put("postMode", Integer.toString(item.getAccessMode()));
                params.put("postText", item.getPost());
                params.put("postImg", item.getImgUrl());
                params.put("postArea", item.getArea());
                params.put("postCountry", item.getCountry());
                params.put("postCity", item.getCity());
                params.put("postLat", Double.toString(item.getLat()));
                params.put("postLng", Double.toString(item.getLng()));

                params.put("feeling", Integer.toString(item.getFeeling()));

                params.put("allowComments", Integer.toString(item.getAllowComments()));
                params.put("soundId", Long.toString(item.getSoundId()));
                params.put("privacyType", Integer.toString(item.getPrivacyType()));

                params.put("videoImgUrl", item.getPreviewVideoImgUrl());
                params.put("videoUrl", item.getVideoUrl());

                return params;
            }
        };

        int socketTimeout = 0;//0 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        jsonReq.setRetryPolicy(policy);

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void savePostSuccess() {

        loading = false;

        hidepDialog();

        if (isAdded()) {

            Intent i = new Intent();
            i.putExtra("item", item);
            i.putExtra("position", position);

            getActivity().setResult(RESULT_OK, i);

            Toast.makeText(getActivity(), getText(R.string.msg_item_saved), Toast.LENGTH_SHORT).show();

            deleteTmpDir();

            getActivity().finish();
        }
    }

    private void newPost() {

        Log.e("newPost 2", item.getVideoUrl());

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ITEMS_NEW, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {


                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("newPost", response.toString());

                            sendPostSuccess();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                sendPostSuccess();

//                     Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_LONG).show();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());

                params.put("postText", item.getPost());

                params.put("allowComments", Integer.toString(item.getAllowComments()));
                params.put("soundId", Long.toString(item.getSoundId()));
                params.put("privacyType", Integer.toString(item.getPrivacyType()));

                params.put("videoImgUrl", item.getPreviewVideoImgUrl());
                params.put("videoUrl", item.getVideoUrl());

                return params;
            }
        };

        int socketTimeout = 0;//0 seconds - change to what you want
        RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        jsonReq.setRetryPolicy(policy);

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void sendPostSuccess() {

        loading = false;

        hidepDialog();

        if (isAdded()) {

            Intent i = new Intent();
            getActivity().setResult(RESULT_OK, i);

            Toast.makeText(getActivity(), getText(R.string.msg_item_posted), Toast.LENGTH_SHORT).show();

            deleteTmpDir();

            // Interstitial ad

            if (App.getInstance().getInterstitialAdSettings().getInterstitialAdAfterNewItem() != 0 && App.getInstance().getAccount().getAdmobMode() == ADMOB_DISABLED) {

                App.getInstance().getInterstitialAdSettings().setCurrentInterstitialAdAfterNewItem(App.getInstance().getInterstitialAdSettings().getCurrentInterstitialAdAfterNewItem() + 1);

                if (App.getInstance().getInterstitialAdSettings().getCurrentInterstitialAdAfterNewItem() >= App.getInstance().getInterstitialAdSettings().getInterstitialAdAfterNewItem()) {

                    App.getInstance().getInterstitialAdSettings().setCurrentInterstitialAdAfterNewItem(0);

                    App.getInstance().showInterstitialAd(null);
                }

                App.getInstance().saveData();
            }

            //

            getActivity().finish();
        }
    }

    private void deleteTmpDir() {

        try {

            // if (f_src_video.exists()) {

            File f_src_video = new File(App.getInstance().getDirectory(), VIDEO_SRC_FILE);
            f_src_video.delete();

            File f_dest_video = new File(App.getInstance().getDirectory(), VIDEO_DEST_FILE);
            f_dest_video.delete();

            File f_thumb = new File(App.getInstance().getDirectory(), VIDEO_THUMBNAIL_FILE);
            f_thumb.delete();

            File f_src_mp3 = new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + File.separator + APP_TEMP_FOLDER + File.separator + MP3_SRC_FILE);
            f_src_mp3.delete();

        } catch (Exception e) {

            Log.e("deleteTmpDir", "Unable to delete tmp folder");
        }
    }



    @Override
    public void onAttach(Context context) {

        super.onAttach(context);
    }

    @Override
    public void onDetach() {

        super.onDetach();
    }


    private void showBottomSheet() {

        if (mBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {

            mBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }

        if (App.getInstance().getAccount().getCountry().length() == 0 && App.getInstance().getAccount().getCity().length() == 0) {

            if (App.getInstance().getAccount().getLat() != 0.000000 && App.getInstance().getAccount().getLng() != 0.000000) {

                App.getInstance().getAddress(App.getInstance().getAccount().getLat(), App.getInstance().getAccount().getLng());
            }
        }

        final View view = getLayoutInflater().inflate(R.layout.item_editor_sheet_list, null);

        MaterialRippleLayout mAddImageButton = (MaterialRippleLayout) view.findViewById(R.id.add_image_button);
        MaterialRippleLayout mAddVideoButton = (MaterialRippleLayout) view.findViewById(R.id.add_video_button);
        MaterialRippleLayout mCaptureVideoButton = (MaterialRippleLayout) view.findViewById(R.id.capture_video_button);
        MaterialRippleLayout mAddLocationButton = (MaterialRippleLayout) view.findViewById(R.id.add_location_button);
        MaterialRippleLayout mAddFeelingButton = (MaterialRippleLayout) view.findViewById(R.id.add_feeling_button);

        mAddImageButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mBottomSheetDialog != null) {

                    mBottomSheetDialog.dismiss();
                }
            }
        });

        mAddVideoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mBottomSheetDialog != null) {

                    mBottomSheetDialog.dismiss();
                }
            }
        });

        mCaptureVideoButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mBottomSheetDialog != null) {

                    mBottomSheetDialog.dismiss();
                }

                if (ContextCompat.checkSelfPermission(getActivity(), android.Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED && ContextCompat.checkSelfPermission(getActivity(), android.Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED) {

                    captureVideo();

                } else {

                    requestVideoCapturePermission();
                }
            }
        });

        mAddLocationButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (mBottomSheetDialog != null) {

                    mBottomSheetDialog.dismiss();
                }
            }
        });

        mAddFeelingButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (mBottomSheetDialog != null) {

                    mBottomSheetDialog.dismiss();
                }
            }
        });

        mBottomSheetDialog = new BottomSheetDialog(getActivity());

        mBottomSheetDialog.setContentView(view);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    // Prevent dialog dismiss when orientation changes
    private static void doKeepDialog(Dialog dialog){

        WindowManager.LayoutParams lp = new  WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);
    }

    public void captureVideo() {

        Intent intent = new Intent(getActivity(), CaptureActivity.class);
        //intent.putExtra("profileId", obj.getId());
        videoFromCameraActivityResultLauncher.launch(intent);
    }

    private void compressingVideoFile(File src, File dest) {

        loading = true;
        compressing = true;

        pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pDialog.setProgressNumberFormat(null);
        pDialog.setProgress(0);
        pDialog.setMax(100);

        showpDialog();

        DefaultVideoStrategy strategy = new DefaultVideoStrategy.Builder()
                .bitRate(8000000)
                //.exact(1080, 720)
//                .bitRate(DefaultVideoStrategy.BITRATE_UNKNOWN) // tries to estimate
//                .frameRate(frameRate) // will be capped to the input frameRate
//                .keyFrameInterval(interval) // interval between key-frames in seconds
                .build();

        strategy = DefaultVideoStrategy.exact(1280, 720).bitRate(App.getInstance().getAppSettings().getVideoBitrate()).build();

        Transcoder.into(dest.getPath())
                .addDataSource(src.getPath()) // or...
                .setVideoTrackStrategy(strategy)
                .setListener(new TranscoderListener() {
                    public void onTranscodeProgress(double progress) {

                        double prgs = progress * 100;

                        pDialog.setProgress((int) prgs);

                        Log.e("Dimon", "onTranscodeProgress:" + Integer.valueOf((int) prgs).toString());
                    }

                    public void onTranscodeCompleted(int successCode) {

                        uploading = false;
                        loading = false;
                        compressing = false;

                        pDialog.hide();

                        Log.e("compressing", "onTranscodeCompleted");
                        Log.e("compressing src", Long.toString(src.length()));
                        Log.e("compressing dest", Long.toString(dest.length()));

                        File f = new File(App.getInstance().getDirectory(), VIDEO_DEST_FILE);
                        File f_thumb = new File(App.getInstance().getDirectory(), VIDEO_THUMBNAIL_FILE);

                        prepareToUploadVideo(f, f_thumb);
                    }

                    public void onTranscodeCanceled() {

                        uploading = false;
                        loading = false;
                        compressing = false;

                        Log.e("compressing", "onTranscodeCanceled");
                        pDialog.hide();
                    }

                    public void onTranscodeFailed(@NonNull Throwable exception) {

                        uploading = false;
                        loading = false;
                        compressing = false;

                        pDialog.hide();
                        Log.e("compressing", exception.toString());
                    }
                }).transcode();
    }

    public void prepareToUploadVideo(File videoFile,  File videoThumb) {

        if (item.getId() == 0 && item.getSoundId() != 0) {

            String mp3_file = Uri.fromFile(new File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_MUSIC) + File.separator + APP_TEMP_FOLDER + File.separator + MP3_SRC_FILE)).toString();
            String mp4_file = Uri.fromFile(videoFile).toString();
            String new_mp4_file = Uri.fromFile(new File(App.getInstance().getDirectory(), VIDEO_NEW_FILE)).toString();

            // Replace audio in video

            int rc = FFmpeg.execute("-i " + mp4_file + " -i " + mp3_file + " -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k -shortest " + new_mp4_file);

            if (rc == RETURN_CODE_SUCCESS) {

                Log.i(Config.TAG, "Command execution completed successfully.");

                File new_video_file = new File(App.getInstance().getDirectory(), VIDEO_NEW_FILE);
                uploadVideoFile(METHOD_VIDEO_UPLOAD, new_video_file, videoThumb);

            } else if (rc == RETURN_CODE_CANCEL) {

                Log.i(Config.TAG, "Command execution cancelled by user.");

                uploadVideoFile(METHOD_VIDEO_UPLOAD, videoFile, videoThumb);

            } else {

                Log.i(Config.TAG, String.format("Command execution failed with rc=%d and the output below.", rc));
                Config.printLastCommandOutput(Log.INFO);

                uploadVideoFile(METHOD_VIDEO_UPLOAD, videoFile, videoThumb);
            }

        } else {

            uploadVideoFile(METHOD_VIDEO_UPLOAD, videoFile, videoThumb);
        }
    }

    public Boolean uploadVideoFile(String serverURL, File videoFile,  File videoThumb) {

        loading = true;
        uploading = true;

        pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pDialog.setProgressNumberFormat(null);
        pDialog.setProgress(0);
        pDialog.setMax(100);

        showpDialog();

        final CountingRequestBody.Listener progressListener = new CountingRequestBody.Listener() {
            @Override
            public void onRequestProgress(long bytesRead, long contentLength) {

                if (bytesRead >= contentLength) {

                    if (isAdded() && getActivity() != null && pDialog != null) {

                        requireActivity().runOnUiThread(new Runnable() {

                            public void run() {
                                //            progressBar.setVisibility(View.GONE);
                            }
                        });
                    }

                } else {

                    if (contentLength > 0) {

                        final int progress = (int) (((double) bytesRead / contentLength) * 100);

                        if (isAdded() && getActivity() != null && pDialog != null) {

                            requireActivity().runOnUiThread(new Runnable() {

                                public void run() {

                                    pDialog.setProgress(progress);
                                }
                            });
                        }

                        if (progress >= 100) {

                            if (isAdded() && getActivity() != null && pDialog != null) {

                                pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            }
                        }

                        Log.e("uploadProgress called", progress + " ");
                    }
                }
            }
        };

        final okhttp3.OkHttpClient client = new okhttp3.OkHttpClient().newBuilder().addNetworkInterceptor(new Interceptor() {

                    @NonNull
                    @Override
                    public okhttp3.Response intercept(@NonNull Chain chain) throws IOException {

                        okhttp3.Request originalRequest = chain.request();

                        if (originalRequest.body() == null) {

                            return chain.proceed(originalRequest);
                        }

                        okhttp3.Request progressRequest = originalRequest.newBuilder()
                                .method(originalRequest.method(),
                                        new CountingRequestBody(originalRequest.body(), progressListener))
                                .build();

                        return chain.proceed(progressRequest);

                    }
                })
                .connectTimeout(OKHTTP3_REQUEST_SECONDS, TimeUnit.SECONDS)
                .readTimeout(OKHTTP3_REQUEST_SECONDS, TimeUnit.SECONDS)
                .writeTimeout(OKHTTP3_REQUEST_SECONDS, TimeUnit.SECONDS)
                .build();

        //client.setProtocols(Arrays.asList(Protocol.HTTP_1_1));

        String vidFileExtension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(videoFile).toString());
        String thumbFileExtension = MimeTypeMap.getFileExtensionFromUrl(Uri.fromFile(videoThumb).toString());
        String vidMime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(vidFileExtension.toLowerCase());
        String thumbMime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(thumbFileExtension.toLowerCase());

        try {

            okhttp3.RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("uploaded_file", videoThumb.getName(), okhttp3.RequestBody.create(videoThumb, okhttp3.MediaType.parse(thumbMime)))
                    .addFormDataPart("uploaded_video_file", videoFile.getName(), okhttp3.RequestBody.create(videoFile, okhttp3.MediaType.parse(vidMime)))
                    .addFormDataPart("soundId", Long.toString(item.getSoundId()))
                    .addFormDataPart("accountId", Long.toString(App.getInstance().getId()))
                    .addFormDataPart("accessToken", App.getInstance().getAccessToken())
                    .build();

            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(serverURL)
                    .addHeader("Accept", "application/json;")
                    .post(requestBody)
                    .build();

            client.newCall(request).enqueue(new okhttp3.Callback() {

                @Override
                public void onFailure(@NonNull Call call, @NonNull IOException e) {

                    uploading = false;
                    loading = false;
                    compressing = false;

                    hidepDialog();

                    Log.e("failure", request.toString());
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull okhttp3.Response response) throws IOException {

                    String jsonData = response.body().string();

                    Log.e("response", jsonData);

                    try {

                        JSONObject result = new JSONObject(jsonData);

                        if (!result.getBoolean("error")) {

                            item.setVideoUrl(result.getString("videoFileUrl"));
                            item.setPreviewVideoImgUrl(result.getString("imgFileUrl"));

                            Log.e("newPost", item.getVideoUrl());

                        } else {


                        }

                        Log.d("My App", response.toString());

                    } catch (Throwable t) {

                        Log.e("My App", "Could not parse malformed JSON: \"" + t.getMessage() + "\"");
                        Toast.makeText(getActivity(), "An error occurred while trying to upload a file to the server. Try again or try later.", Toast.LENGTH_SHORT).show();

                    } finally {

                        if (item.getVideoUrl().length() != 0) {

                            uploadImages(0);

                        } else {

                            Toast.makeText(getActivity(), "Failed to upload file. Check your internet connection and try again.", Toast.LENGTH_SHORT).show();
                        }

                        Log.e("response", jsonData);
                    }
                }

            });

            return true;

        } catch (Exception ex) {
            // Handle the error

            uploading = false;
            loading = false;
            compressing = false;

            hidepDialog();
        }

        return false;
    }

    private void choiceFeelingDialog() {

        final FeelingsListAdapter feelingsAdapter;

        feelingsAdapter = new FeelingsListAdapter(getActivity(), App.getInstance().getFeelingsList());

        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.dialog_feelings);
        dialog.setCancelable(true);

        final ProgressBar mProgressBar = (ProgressBar) dialog.findViewById(R.id.progress_bar);
        mProgressBar.setVisibility(View.GONE);

        TextView mDlgTitle = (TextView) dialog.findViewById(R.id.title_label);
        mDlgTitle.setText(R.string.dlg_choice_feeling_title);

        AppCompatButton mDlgCancelButton = (AppCompatButton) dialog.findViewById(R.id.cancel_button);
        mDlgCancelButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });

        NestedScrollView mDlgNestedView = (NestedScrollView) dialog.findViewById(R.id.nested_view);
        final RecyclerView mDlgRecyclerView = (RecyclerView) dialog.findViewById(R.id.recycler_view);

        final LinearLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), Helper.getStickersGridSpanCount(getActivity()));
        mDlgRecyclerView.setLayoutManager(mLayoutManager);
        mDlgRecyclerView.setHasFixedSize(true);
        mDlgRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mDlgRecyclerView.setAdapter(feelingsAdapter);

        mDlgRecyclerView.setNestedScrollingEnabled(true);

        feelingsAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {

            @Override
            public void onChanged() {

                super.onChanged();

                if (App.getInstance().getFeelingsList().size() != 0) {

                     mDlgRecyclerView.setVisibility(View.VISIBLE);
                     mProgressBar.setVisibility(View.GONE);
                }
            }
        });

        feelingsAdapter.setOnItemClickListener(new FeelingsListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, Feeling obj, int position) {

                item.setFeeling(position);

                //updateFeeling();

                dialog.dismiss();
            }
        });

        if (App.getInstance().getFeelingsList().size() == 0) {

            mDlgRecyclerView.setVisibility(View.GONE);
            mProgressBar.setVisibility(View.VISIBLE);

            Api api = new Api(getActivity());
            api.getFeelings(feelingsAdapter);
        }

        dialog.show();

        doKeepDialog(dialog);
    }

    @Override
    public void onStart() {

        super.onStart();

        getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onStop() {

        super.onStop();

        getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private void requestStoragePermission() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            storagePermissionLauncher.launch(new String[]{Manifest.permission.READ_MEDIA_IMAGES, Manifest.permission.READ_MEDIA_VIDEO});

        } else {

            storagePermissionLauncher.launch(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE});
        }
    }

    private void requestCameraPermission() {

        cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
    }

    private void requestVideoCapturePermission() {

        videoCapturePermissionLauncher.launch(new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.CAMERA});
    }
}