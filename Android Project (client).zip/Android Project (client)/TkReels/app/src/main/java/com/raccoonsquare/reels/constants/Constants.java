package com.raccoonsquare.reels.constants;

public interface Constants {

    // Attention! You can only change the values of the following constants:

    // CLIENT_ID, CLIENT_SECRET, API_DOMAIN, PACKAGE_NAME,
    // VIDEO_FILE_MAX_SIZE, VIDEO_FILE_MAX_SIZE_FROM_GALLERY, WEB_SITE, EMOJI_KEYBOARD, WEB_SITE_AVAILABLE

    // It is forbidden to change the value of constants, which are not indicated above !!!

    // CLIENT_ID - for identify the application | Must be the same with CLIENT_ID from server config: db.inc.php
    String CLIENT_ID = "1";  // Correct example: 12567 | Incorrect example: 0987

    // CLIENT_SECRET - text constant | Must be the same with CLIENT_SECRET from server config: db.inc.php
    String CLIENT_SECRET = "f*Hk86&_Hrfv7cjnf-I=yT";    // Example: "f*Hk86&_Hrfv7cjnf-I=yT"

    // API_DOMAIN - url address to which the application sends requests || http://10.0.2.2/ - for test on emulator in localhost [XAMPP]
    String API_DOMAIN = "https://tkreels.raccoonsquare.com/"; // must be / (slash) at the end

    // PACKAGE_NAME - for configure in-app purchases
    String PACKAGE_NAME = "com.raccoonsquare.reels";

    //

    public static final int VIDEO_FILE_MAX_SIZE = 51457280; // If the file is larger than this size, then it will be compressed before uploading to the server. Max size for video file in bytes | For example 7mb = 7*1024*1024
    public static final int VIDEO_FILE_MAX_SIZE_FROM_GALLERY = 300457280; //Max size for video file in bytes | For example 7mb = 7*1024*1024

    public static final String WEB_SITE = "https://tkreels.raccoonsquare.com/";  //web site url address

    //

    public static final Boolean EMOJI_KEYBOARD = true; // false = Do not display your own Emoji keyboard | true = allow display your own Emoji keyboard

    public static final Boolean WEB_SITE_AVAILABLE = false; // false = Do not show menu items (Open in browser, Copy profile link) in profile page | true = show menu items (Open in browser, Copy profile link) in profile page

    public static final int MY_AD_AFTER_ITEM_NUMBER = 0;  //After first item

    public static final String APP_TEMP_FOLDER = "tkreels"; //directory for temporary storage of images from the camera

    ////////////////////////////////////////

    public static final String API_FILE_EXTENSION = "";     // Attention! Do not change the value for this constant!
    public static final String API_VERSION = "v2";          // Attention! Do not change the value for this constant!

    // Attention! Do not change values for next constants!

    public static final String METHOD_NOTIFICATIONS_CLEAR = API_DOMAIN + "api/" + API_VERSION + "/method/notifications.clear" + API_FILE_EXTENSION;
    public static final String METHOD_GUESTS_CLEAR = API_DOMAIN + "api/" + API_VERSION + "/method/guests.clear" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_PRIVACY = API_DOMAIN + "api/" + API_VERSION + "/method/account.privacy" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_GET_SETTINGS = API_DOMAIN + "api/" + API_VERSION + "/method/account.getSettings" + API_FILE_EXTENSION;
    public static final String METHOD_DIALOGS_NEW_GET = API_DOMAIN + "api/" + API_VERSION + "/method/dialogs_new.get" + API_FILE_EXTENSION;
    public static final String METHOD_CHAT_UPDATE = API_DOMAIN + "api/" + API_VERSION + "/method/chat.update" + API_FILE_EXTENSION;

    public static final String METHOD_ACCOUNT_LOGIN = API_DOMAIN + "api/" + API_VERSION + "/method/account.signIn" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_SIGNUP = API_DOMAIN + "api/" + API_VERSION + "/method/account.signUp" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_AUTHORIZE = API_DOMAIN + "api/" + API_VERSION + "/method/account.authorize" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_SET_GCM_TOKEN = API_DOMAIN + "api/" + API_VERSION + "/method/account.setGcmToken" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_RECOVERY = API_DOMAIN + "api/" + API_VERSION + "/method/account.recovery" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_SETPASSWORD = API_DOMAIN + "api/" + API_VERSION + "/method/account.setPassword" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_DEACTIVATE = API_DOMAIN + "api/" + API_VERSION + "/method/account.deactivate" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_SAVE_SETTINGS = API_DOMAIN + "api/" + API_VERSION + "/method/account.saveSettings" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_LOGOUT = API_DOMAIN + "api/" + API_VERSION + "/method/account.logOut" + API_FILE_EXTENSION;
    public static final String METHOD_GIFTS_REMOVE = API_DOMAIN + "api/" + API_VERSION + "/method/gifts.remove" + API_FILE_EXTENSION;
    public static final String METHOD_GIFTS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/gifts.get" + API_FILE_EXTENSION;
    public static final String METHOD_GIFTS_SELECT = API_DOMAIN + "api/" + API_VERSION + "/method/gifts.select" + API_FILE_EXTENSION;
    public static final String METHOD_GIFTS_SEND = API_DOMAIN + "api/" + API_VERSION + "/method/gifts.send" + API_FILE_EXTENSION;

    public static final String METHOD_ACCOUNT_SET_GEO_LOCATION = API_DOMAIN + "api/" + API_VERSION + "/method/account.setGeoLocation" + API_FILE_EXTENSION;

    public static final String METHOD_PROFILE_PEOPLE_NEARBY_GET = API_DOMAIN + "api/" + API_VERSION + "/method/profile.getPeopleNearby" + API_FILE_EXTENSION;

    public static final String METHOD_GUESTS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/guests.get" + API_FILE_EXTENSION;

    public static final String METHOD_SUPPORT_SEND_TICKET = API_DOMAIN + "api/" + API_VERSION + "/method/support.sendTicket" + API_FILE_EXTENSION;

    public static final String METHOD_PROFILE_GET = API_DOMAIN + "api/" + API_VERSION + "/method/profile.get" + API_FILE_EXTENSION;
    public static final String METHOD_PROFILE_FOLLOWINGS = API_DOMAIN + "api/" + API_VERSION + "/method/profile.followings" + API_FILE_EXTENSION;
    public static final String METHOD_PROFILE_FOLLOWERS = API_DOMAIN + "api/" + API_VERSION + "/method/profile.followers" + API_FILE_EXTENSION;
    public static final String METHOD_PROFILE_FOLLOW = API_DOMAIN + "api/" + API_VERSION + "/method/profile.follow" + API_FILE_EXTENSION;
    public static final String METHOD_WALL_GET = API_DOMAIN + "api/" + API_VERSION + "/method/wall.get" + API_FILE_EXTENSION;

    public static final String METHOD_BLACKLIST_GET = API_DOMAIN + "api/" + API_VERSION + "/method/blacklist.get" + API_FILE_EXTENSION;
    public static final String METHOD_BLACKLIST_ADD = API_DOMAIN + "api/" + API_VERSION + "/method/blacklist.add" + API_FILE_EXTENSION;
    public static final String METHOD_BLACKLIST_REMOVE = API_DOMAIN + "api/" + API_VERSION + "/method/blacklist.remove" + API_FILE_EXTENSION;

    public static final String METHOD_NOTIFICATIONS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/notifications.get" + API_FILE_EXTENSION;
    public static final String METHOD_HASHTAGS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/hashtags.get" + API_FILE_EXTENSION;
    public static final String METHOD_ITEM_GET = API_DOMAIN + "api/" + API_VERSION + "/method/item.get" + API_FILE_EXTENSION;
    public static final String METHOD_POPULAR_GET = API_DOMAIN + "api/" + API_VERSION + "/method/popular.get" + API_FILE_EXTENSION;

    public static final String METHOD_APP_CHECKUSERNAME = API_DOMAIN + "api/" + API_VERSION + "/method/app.checkUsername" + API_FILE_EXTENSION;
    public static final String METHOD_APP_TERMS = API_DOMAIN + "api/" + API_VERSION + "/method/app.terms" + API_FILE_EXTENSION;
    public static final String METHOD_APP_PRIVACY = API_DOMAIN + "api/" + API_VERSION + "/method/app.privacy" + API_FILE_EXTENSION;
    public static final String METHOD_APP_THANKS = API_DOMAIN + "api/" + API_VERSION + "/method/app.thanks" + API_FILE_EXTENSION;
    public static final String METHOD_USERS_SEARCH = API_DOMAIN + "api/" + API_VERSION + "/method/users.search" + API_FILE_EXTENSION;

    public static final String METHOD_ITEMS_REMOVE = API_DOMAIN + "api/" + API_VERSION + "/method/items.remove" + API_FILE_EXTENSION;
    public static final String METHOD_ITEMS_NEW = API_DOMAIN + "api/" + API_VERSION + "/method/items.new" + API_FILE_EXTENSION;
    public static final String METHOD_ITEMS_EDIT = API_DOMAIN + "api/" + API_VERSION + "/method/items.edit" + API_FILE_EXTENSION;

    public static final String METHOD_FAVORITES_GET = API_DOMAIN + "api/" + API_VERSION + "/method/favorites.get" + API_FILE_EXTENSION;

    public static final String METHOD_CHAT_GET = API_DOMAIN + "api/" + API_VERSION + "/method/chat.get" + API_FILE_EXTENSION;
    public static final String METHOD_CHAT_REMOVE = API_DOMAIN + "api/" + API_VERSION + "/method/chat.remove" + API_FILE_EXTENSION;
    public static final String METHOD_CHAT_GET_PREVIOUS = API_DOMAIN + "api/" + API_VERSION + "/method/chat.getPrevious" + API_FILE_EXTENSION;

    public static final String METHOD_MSG_NEW = API_DOMAIN + "api/" + API_VERSION + "/method/msg.new" + API_FILE_EXTENSION;
    public static final String METHOD_MSG_UPLOAD_IMG = API_DOMAIN + "api/" + API_VERSION + "/method/msg.uploadImg" + API_FILE_EXTENSION;

    public static final String METHOD_REFERRALS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/referrals.get" + API_FILE_EXTENSION;

    public static final String METHOD_MARKET_SEARCH = API_DOMAIN + "api/" + API_VERSION + "/method/market.search" + API_FILE_EXTENSION;
    public static final String METHOD_MARKET_GET = API_DOMAIN + "api/" + API_VERSION + "/method/market.get" + API_FILE_EXTENSION;
    public static final String METHOD_MARKET_NEW_ITEM = API_DOMAIN + "api/" + API_VERSION + "/method/market.newItem" + API_FILE_EXTENSION;
    public static final String METHOD_MARKET_REMOVE_ITEM = API_DOMAIN + "api/" + API_VERSION + "/method/market.removeItem" + API_FILE_EXTENSION;
    public static final String METHOD_MARKET_UPLOAD_IMG = API_DOMAIN + "api/" + API_VERSION + "/method/market.uploadImg" + API_FILE_EXTENSION;

    public static final String METHOD_GET_STICKERS = API_DOMAIN + "api/" + API_VERSION + "/method/stickers.get" + API_FILE_EXTENSION;

    public static final String METHOD_CHAT_NOTIFY = API_DOMAIN + "api/" + API_VERSION + "/method/chat.notify" + API_FILE_EXTENSION;

    public static final String METHOD_FEELINGS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/feelings.get" + API_FILE_EXTENSION;
    public static final String METHOD_ACCOUNT_SET_FEELING = API_DOMAIN + "api/" + API_VERSION + "/method/account.setMood" + API_FILE_EXTENSION;

    public static final String METHOD_APP_CHECK_EMAIL = API_DOMAIN + "api/" + API_VERSION + "/method/app.checkEmail" + API_FILE_EXTENSION;
    public static final String METHOD_ITEM_GET_COMMENTS = API_DOMAIN + "api/" + API_VERSION + "/method/item.getComments" + API_FILE_EXTENSION;
    public static final String METHOD_PROFILE_UPLOAD_IMAGE = API_DOMAIN + "api/" + API_VERSION + "/method/profile.uploadImg" + API_FILE_EXTENSION;

    public static final String METHOD_GALLERY_UPLOAD_IMAGE = API_DOMAIN + "api/" + API_VERSION + "/method/gallery.uploadImg" + API_FILE_EXTENSION;

    public static final String METHOD_REPORT_NEW = API_DOMAIN + "api/" + API_VERSION + "/method/reports.new" + API_FILE_EXTENSION;

    public static final String METHOD_COMMENTS_REMOVE = API_DOMAIN + "api/" + API_VERSION + "/method/comments.remove" + API_FILE_EXTENSION;
    public static final String METHOD_COMMENTS_NEW = API_DOMAIN + "api/" + API_VERSION + "/method/comments.new" + API_FILE_EXTENSION;

    public static final String METHOD_VIDEO_UPLOAD = API_DOMAIN + "api/" + API_VERSION + "/method/items.uploadVideo" + API_FILE_EXTENSION;

    public static final String METHOD_ACCOUNT_UPGRADE = API_DOMAIN + "api/" + API_VERSION + "/method/account.upgrade" + API_FILE_EXTENSION;

    public static final String METHOD_PAYMENTS_NEW = API_DOMAIN + "api/" + API_VERSION + "/method/payments.new" + API_FILE_EXTENSION;
    public static final String METHOD_PAYMENTS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/payments.get" + API_FILE_EXTENSION;

    public static final String METHOD_ITEMS_RESTORE = API_DOMAIN + "api/" + API_VERSION + "/method/items.restore" + API_FILE_EXTENSION;
    public static final String METHOD_ITEMS_GET_RECENTLY_DELETED = API_DOMAIN + "api/" + API_VERSION + "/method/items.getRecentlyDeleted" + API_FILE_EXTENSION;

    public static final String METHOD_ITEMS_PIN = API_DOMAIN + "api/" + API_VERSION + "/method/items.pin" + API_FILE_EXTENSION;

    public static final String METHOD_ACCOUNT_OTP = API_DOMAIN + "api/" + API_VERSION + "/method/account.otp" + API_FILE_EXTENSION;

    public static final String METHOD_REACTIONS_MAKE = API_DOMAIN + "api/" + API_VERSION + "/method/reactions.make" + API_FILE_EXTENSION;
    public static final String METHOD_REACTIONS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/reactions.get" + API_FILE_EXTENSION;

    public static final String METHOD_ACCOUNT_OAUTH = API_DOMAIN + "api/" + API_VERSION + "/method/account.oauth" + API_FILE_EXTENSION;

    public static final String METHOD_HOME_GET = API_DOMAIN + "api/" + API_VERSION + "/method/home.get" + API_FILE_EXTENSION;
    public static final String METHOD_ITEMS_VIEW = API_DOMAIN + "api/" + API_VERSION + "/method/items.view" + API_FILE_EXTENSION;
    public static final String METHOD_PRIVATE_ITEMS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/items.private" + API_FILE_EXTENSION;
    public static final String METHOD_ITEMS_SEARCH = API_DOMAIN + "api/" + API_VERSION + "/method/items.search" + API_FILE_EXTENSION;

    public static final String METHOD_BOOKMARK_MAKE = API_DOMAIN + "api/" + API_VERSION + "/method/bookmark.make" + API_FILE_EXTENSION;
    public static final String METHOD_BOOKMARK_VIDEOS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/bookmark.getVideos" + API_FILE_EXTENSION;
    public static final String METHOD_BOOKMARK_HASHTAGS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/bookmark.getHashtags" + API_FILE_EXTENSION;
    public static final String METHOD_BOOKMARK_SOUNDS_GET = API_DOMAIN + "api/" + API_VERSION + "/method/bookmark.getSounds" + API_FILE_EXTENSION;

    public static final String METHOD_VERIFICATION_REQUEST = API_DOMAIN + "api/" + API_VERSION + "/method/verification.request" + API_FILE_EXTENSION;
    public static final String METHOD_VERIFICATION_CHECK = API_DOMAIN + "api/" + API_VERSION + "/method/verification.check" + API_FILE_EXTENSION;

    public static final String METHOD_SOUND_GET = API_DOMAIN + "api/" + API_VERSION + "/method/sound.get" + API_FILE_EXTENSION;
    public static final String METHOD_SOUND_GET_VIDEOS = API_DOMAIN + "api/" + API_VERSION + "/method/sound.getVideos" + API_FILE_EXTENSION;

    // for version 1.1

    String METHOD_AGORA_VIDEO_CALL = API_DOMAIN + "api/" + API_VERSION + "/method/agora.videoCall" + API_FILE_EXTENSION;
    String METHOD_AGORA_VIDEO_CALL_STATUS = API_DOMAIN + "api/" + API_VERSION + "/method/agora.videoCallStatus" + API_FILE_EXTENSION;
    String METHOD_PAYMENTS_STRIPE = API_DOMAIN + "api/" + API_VERSION + "/method/payments.stripe" + API_FILE_EXTENSION;

    // Other Constants

    public static final int PAGE_ANY = 0;
    int PAGE_PROFILE = 1;
    int PAGE_GALLERY = 2;
    int PAGE_FRIENDS = 3;
    int PAGE_MATCHES = 4;
    int PAGE_MESSAGES = 5;
    int PAGE_NOTIFICATIONS = 6;
    int PAGE_GUESTS = 7;
    int PAGE_LIKES = 8;
    int PAGE_LIKED = 9;
    int PAGE_UPGRADES = 10;
    int PAGE_NEARBY = 11;
    int PAGE_MEDIA_STREAM = 12;
    int PAGE_MEDIA_FEED = 13;
    int PAGE_SEARCH = 14;
    int PAGE_SETTINGS = 15;
    int PAGE_HOTGAME = 16;
    int PAGE_FINDER = 17;
    int PAGE_MENU = 18;
    int PAGE_MAIN = 19;

    //

    int ACCOUNT_TYPE_PERSONAL = 0;
    int ACCOUNT_TYPE_PRIVATE_SELLER = 1;
    int ACCOUNT_TYPE_CAR_DEALER = 2;

    //

    public static final int SIGNIN_EMAIL = 0;
    public static final int SIGNIN_OTP = 1;
    public static final int SIGNIN_FACEBOOK = 2;
    public static final int SIGNIN_GOOGLE = 3;
    public static final int SIGNIN_APPLE = 4;
    public static final int SIGNIN_TWITTER = 5;

    public static final int OAUTH_TYPE_FACEBOOK = 0;
    public static final int OAUTH_TYPE_GOOGLE = 1;
    public static final int OAUTH_TYPE_APPLE = 2;

    //

    public static final int APP_TYPE_ALL = -1;
    public static final int APP_TYPE_MANAGER = 0;
    public static final int APP_TYPE_WEB = 1;
    public static final int APP_TYPE_ANDROID = 2;
    public static final int APP_TYPE_IOS = 3;


    public static final int IMAGE_TYPE_PROFILE_PHOTO = 0;
    public static final int IMAGE_TYPE_PROFILE_COVER = 1;

    public static final int GALLERY_ITEM_TYPE_IMAGE = 0;
    public static final int GALLERY_ITEM_TYPE_VIDEO = 1;

    public static final int REPORT_TYPE_ITEM = 0;
    public static final int REPORT_TYPE_PROFILE = 1;
    public static final int REPORT_TYPE_MESSAGE = 2;
    public static final int REPORT_TYPE_COMMENT = 3;
    public static final int REPORT_TYPE_GALLERY_ITEM = 4;
    public static final int REPORT_TYPE_MARKET_ITEM = 5;
    public static final int REPORT_TYPE_COMMUNITY = 6;

    public static final int VOLLEY_REQUEST_SECONDS = 15; //SECONDS TO REQUEST
    int OKHTTP3_REQUEST_SECONDS = 150; //SECONDS TO REQUEST

    String MP3_SRC_FILE = "src_mp3.mp3";
    String VIDEO_SRC_FILE = "src_video.mp4";
    String VIDEO_DEST_FILE = "dest_video.mp4";
    String VIDEO_NEW_FILE = "new_video.mp4";
    String VIDEO_THUMBNAIL_FILE = "mp4_thumbnail.jpg";
    String IMAGE_FILE = "image.jpg";

    public static final int POST_TYPE_DEFAULT = 0;
    public static final int POST_TYPE_PHOTO_UPDATE = 1;
    public static final int POST_TYPE_COVER_UPDATE = 2;
    public static final int POST_TYPE_ALERT = 3;

    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE_PHOTO = 1;                  //WRITE_EXTERNAL_STORAGE
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE_COVER = 2;                  //WRITE_EXTERNAL_STORAGE
    public static final int MY_PERMISSIONS_REQUEST_ACCESS_LOCATION = 3;                               //ACCESS_COARSE_LOCATION
    public static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE_VIDEO_IMAGE = 4;            //WRITE_EXTERNAL_STORAGE

    public static final int LIST_ITEMS = 20;

    public static final int POST_CHARACTERS_LIMIT = 1000;

    public static final int VIDEO_TITLE_LIMIT = 400;
    public static final int VIDEO_DESC_LIMIT = 700;

    public static final int ENABLED = 1;
    public static final int DISABLED = 0;

    public static final int GCM_ENABLED = 1;
    public static final int GCM_DISABLED = 0;

    public static final int ADMOB_ENABLED = 1;
    public static final int ADMOB_DISABLED = 0;

    public static final int COMMENTS_ENABLED = 1;
    public static final int COMMENTS_DISABLED = 0;

    public static final int MESSAGES_ENABLED = 1;
    public static final int MESSAGES_DISABLED = 0;

    public static final int ERROR_SUCCESS = 0;

    public static final int SEX_UNKNOWN = 0;
    public static final int SEX_MALE = 1;
    public static final int SEX_FEMALE = 2;

    public static final int NOTIFY_TYPE_LIKE = 0;
    public static final int NOTIFY_TYPE_FOLLOWER = 1;
    public static final int NOTIFY_TYPE_MESSAGE = 2;
    public static final int NOTIFY_TYPE_COMMENT = 3;
    public static final int NOTIFY_TYPE_COMMENT_REPLY = 4;
    public static final int NOTIFY_TYPE_FRIEND_REQUEST_ACCEPTED = 5;
    public static final int NOTIFY_TYPE_GIFT = 6;

    public static final int NOTIFY_TYPE_IMAGE_COMMENT = 7;
    public static final int NOTIFY_TYPE_IMAGE_COMMENT_REPLY = 8;
    public static final int NOTIFY_TYPE_IMAGE_LIKE = 9;

    public static final int NOTIFY_TYPE_VIDEO_COMMENT = 10;
    public static final int NOTIFY_TYPE_VIDEO_COMMENT_REPLY = 11;
    public static final int NOTIFY_TYPE_VIDEO_LIKE = 12;

    public static final int NOTIFY_TYPE_PROFILE_PHOTO_APPROVE = 2003;
    public static final int NOTIFY_TYPE_PROFILE_PHOTO_REJECT = 2004;
    public static final int NOTIFY_TYPE_PROFILE_COVER_APPROVE = 2007;
    public static final int NOTIFY_TYPE_PROFILE_COVER_REJECT = 2008;

    public static final int NOTIFY_TYPE_REFERRAL = 14;

    public static final int GCM_NOTIFY_CONFIG = 0;
    public static final int GCM_NOTIFY_SYSTEM = 1;
    public static final int GCM_NOTIFY_CUSTOM = 2;
    public static final int GCM_NOTIFY_LIKE = 3;
    public static final int GCM_NOTIFY_ANSWER = 4;
    public static final int GCM_NOTIFY_QUESTION = 5;
    public static final int GCM_NOTIFY_COMMENT = 6;
    public static final int GCM_NOTIFY_FOLLOWER = 7;
    public static final int GCM_NOTIFY_PERSONAL = 8;
    public static final int GCM_NOTIFY_MESSAGE = 9;
    public static final int GCM_NOTIFY_COMMENT_REPLY = 10;
    public static final int GCM_FRIEND_REQUEST_INBOX = 11;
    public static final int GCM_FRIEND_REQUEST_ACCEPTED = 12;
    public static final int GCM_NOTIFY_GIFT = 14;
    public static final int GCM_NOTIFY_SEEN = 15;
    public static final int GCM_NOTIFY_TYPING = 16;
    public static final int GCM_NOTIFY_URL = 17;

    public static final int GCM_NOTIFY_IMAGE_COMMENT_REPLY = 18;
    public static final int GCM_NOTIFY_IMAGE_COMMENT = 19;
    public static final int GCM_NOTIFY_IMAGE_LIKE = 20;

    public static final int GCM_NOTIFY_VIDEO_COMMENT_REPLY = 21;
    public static final int GCM_NOTIFY_VIDEO_COMMENT = 22;
    public static final int GCM_NOTIFY_VIDEO_LIKE = 23;

    public static final int GCM_NOTIFY_REFERRAL = 24;

    public static final int GCM_NOTIFY_TYPING_START = 27;
    public static final int GCM_NOTIFY_TYPING_END = 28;

    int GCM_NOTIFY_VERIFICATION_REJECT = 2997;
    int GCM_NOTIFY_VERIFICATION_ACCEPT = 2998;
    int GCM_NOTIFY_AGENT = 2999;
    int NOTIFY_TYPE_AGENT = 3999;

    public static final int GCM_NOTIFY_PROFILE_PHOTO_APPROVE = 1003;
    public static final int GCM_NOTIFY_PROFILE_PHOTO_REJECT = 1004;
    public static final int GCM_NOTIFY_PROFILE_COVER_APPROVE = 1007;
    public static final int GCM_NOTIFY_PROFILE_COVER_REJECT = 1008;


    public static final int ERROR_LOGIN_TAKEN = 300;
    public static final int ERROR_EMAIL_TAKEN = 301;
    public static final int ERROR_FACEBOOK_ID_TAKEN = 302;
    public static final int ERROR_PHONE_TAKEN = 303;
    public static final int ERROR_OAUTH_ID_TAKEN = 304;

    int ERROR_OTP_VERIFICATION = 506;
    int ERROR_OTP_PHONE_NUMBER_TAKEN = 507;

    int ERROR_IMAGE_FILE_ADULT = 555;
    int ERROR_IMAGE_FILE_VIOLENCE = 556;
    int ERROR_IMAGE_FILE_RACY = 557;

    int ERROR_MULTI_ACCOUNT = 500;

    int ERROR_CLIENT_ID = 19100;
    int ERROR_CLIENT_SECRET = 19101;
    int ERROR_RECAPTCHA = 19102;

    public static final int ACCOUNT_STATE_ENABLED = 0;
    public static final int ACCOUNT_STATE_DISABLED = 1;
    public static final int ACCOUNT_STATE_BLOCKED = 2;
    public static final int ACCOUNT_STATE_DEACTIVATED = 3;

    public static final int ACCOUNT_TYPE_USER = 0;
    public static final int ACCOUNT_TYPE_GROUP = 1;

    public static final int ERROR_UNKNOWN = 100;
    public static final int ERROR_ACCESS_TOKEN = 101;

    public static final int ERROR_ACCOUNT_ID = 400;

    public static final int UPLOAD_TYPE_PHOTO = 0;
    public static final int UPLOAD_TYPE_COVER = 1;

    public static final int ACTION_NEW = 1;
    public static final int ACTION_EDIT = 2;
    public static final int SELECT_POST_IMG = 3;
    public static final int VIEW_CHAT = 4;
    public static final int CREATE_POST_IMG = 5;
    public static final int SELECT_CHAT_IMG = 6;
    public static final int CREATE_CHAT_IMG = 7;
    public static final int FEED_NEW_POST = 8;
    public static final int FRIENDS_SEARCH = 9;
    public static final int ITEM_EDIT = 10;
    public static final int STREAM_NEW_POST = 11;
    public static final int ITEM_REPOST = 12;
    public static final int ITEM_ACTIONS_MENU = 14;
    public static final int ITEM_ACTION_REPOST = 15;

    public static final int ITEM_TYPE_IMAGE = 0;
    public static final int ITEM_TYPE_VIDEO = 1;
    public static final int ITEM_TYPE_POST = 2;
    public static final int ITEM_TYPE_COMMENT = 3;
    public static final int ITEM_TYPE_GALLERY = 4;

    public static final int PA_BUY_CREDITS = 0;
    public static final int PA_BUY_GIFT = 1;
    public static final int PA_BUY_VERIFIED_BADGE = 2;
    public static final int PA_BUY_GHOST_MODE = 3;
    public static final int PA_BUY_DISABLE_ADS = 4;
    public static final int PA_BUY_REGISTRATION_BONUS = 5;
    public static final int PA_BUY_REFERRAL_BONUS = 6;
    public static final int PA_BUY_MANUAL_BONUS = 7;
    public static final int PA_BUY_PRO_MODE = 8;
    public static final int PA_BUY_SPOTLIGHT = 9;
    public static final int PA_BUY_MESSAGE_PACKAGE = 10;
    public static final int PA_BUY_OTP_VERIFICATION = 11;
    public static final int PA_BUY_BLOGGER_MODE = 12;
    public static final int PA_BUY_MUSIC_FAN_MODE = 14;

    public static final int PT_UNKNOWN = 0;
    public static final int PT_CREDITS = 1;
    public static final int PT_CARD = 2;
    public static final int PT_GOOGLE_PURCHASE = 3;
    public static final int PT_APPLE_PURCHASE = 4;
    public static final int PT_ADMOB_REWARDED_ADS = 5;
    public static final int PT_BONUS = 6;

    public static final int PT_STRIPE = 10;
    public static final int PT_PAYSTACK = 11;

    //

    int GCM_NOTIFY_AGORA_VIDEO_CALL = 10001;

    public static final int VIDEO_CALL_ACTIVE = 0;
    public static final int VIDEO_CALL_CANCELED = 10001;
    public static final int VIDEO_CALL_DECLINED = 10002;
    public static final int VIDEO_CALL_ENDED = 10003;
    public static final int VIDEO_CALL_INCOMING = 10004;
    public static final int VIDEO_CALL_OUTGOING = 10005;

    //

    public static final String TAG = "TAG";

    public static final String HASHTAGS_COLOR = "#5BCFF2";

    public static final String TAG_UPDATE_BADGES = "update_badges";

    public static final String TAG_SELECT_SOUND_ITEM = "select_sound_item";
    public static final String TAG_UPDATE_VIDEO_ITEM = "update_video_item";
    public static final String TAG_SHOW_AUTH_BOTTOM_SHEET = "show_auth_bottom_sheet";
    public static final String TAG_ITEM_ACTION_BOTTOM_SHEET = "item_action_bottom_sheet";

    //

    static final String ITEM_SKU_1 = PACKAGE_NAME + ".iap1";          // Change to: yourdomain.com.iap1
    static final String ITEM_SKU_2 = PACKAGE_NAME + ".iap2";          // Change to: yourdomain.com.iap2
    static final String ITEM_SKU_3 = PACKAGE_NAME + ".iap3";          // Change to: yourdomain.com.iap3
    static final String ITEM_SKU_4 = "android.test.purchased";          // Not used. For testing

    //

    public static final int SECTION_FOLLOWING = 0;
    public static final int SECTION_ADS = 1;
    public static final int SECTION_RELATED = 2;
}