package com.raccoonsquare.reels.model;

import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import org.json.JSONObject;
import com.raccoonsquare.reels.constants.Constants;


public class Profile implements Constants, Parcelable {

    private long id;

    private int profile_type = 0, account_free = 0, otpVerified = 0;

    private int ghostMode = 0, balance = 0, admobMode = 0, bloggerMode = 0, musicFanMode = 0;

    private String otpPhone = "", google_id = "", fb_id = "", area = "", country = "", city = "";

    private Double lat = 0.000000, lng = 0.000000;

    private int mood, state, sex, year, month, day, verified, pro, itemsCount, galleryItemsCount, likesCount, giftsCount, friendsCount, followingsCount, followersCount, allowShowLikedVideos = 1, allowDownloadVideos = 1, allowComments, allowMessages, lastAuthorize, accountType;

    private int allowShowMyInfo, allowShowMyFriends, allowShowMyGallery, allowShowMyGifts;

    private int allowGalleryComments;

    private int allowVideoCalls = 1;

    private double distance = 0;

    private int reaction = 0;

    private String username, fullname, lowPhotoUrl, bigPhotoUrl, normalPhotoUrl, normalCoverUrl, location, facebookPage, instagramPage, bio, lastAuthorizeDate, lastAuthorizeTimeAgo;

    private Boolean blocked = false;

    private Boolean inBlackList = false;

    private Boolean follower = false;

    private Boolean follow = false;

    private Boolean friend = false;

    private Boolean online = false;

    private int profileType = 0;
    private String companyName = "", public_email = "", public_phone = "";

    public Profile() {


    }

    public Profile(JSONObject jsonData) {

        try {

            if (!jsonData.getBoolean("error")) {

                this.setId(jsonData.getLong("id"));
                this.setState(jsonData.getInt("state"));
                this.setType(jsonData.getInt("accountType"));
                this.setSex(jsonData.getInt("sex"));
                this.setYear(jsonData.getInt("year"));
                this.setMonth(jsonData.getInt("month"));
                this.setDay(jsonData.getInt("day"));
                this.setUsername(jsonData.getString("username"));
                this.setFullname(jsonData.getString("fullname"));
                this.setLocation(jsonData.getString("location"));
                this.setFacebookPage(jsonData.getString("fb_page"));
                this.setInstagramPage(jsonData.getString("instagram_page"));
                this.setBio(jsonData.getString("status"));
                this.setVerified(jsonData.getInt("verified"));

                this.setMood(jsonData.getInt("mood"));

                this.setLowPhotoUrl(jsonData.getString("lowPhotoUrl"));
                this.setNormalPhotoUrl(jsonData.getString("normalPhotoUrl"));
                this.setBigPhotoUrl(jsonData.getString("bigPhotoUrl"));

                this.setNormalCoverUrl(jsonData.getString("normalCoverUrl"));

                this.setFollowersCount(jsonData.getInt("followersCount"));
                this.setFollowingsCount(jsonData.getInt("followingCount"));
                this.setFriendsCount(jsonData.getInt("friendsCount"));
                this.setItemsCount(jsonData.getInt("postsCount"));
                this.setLikesCount(jsonData.getInt("likesCount"));
                this.setGalleryItemsCount(jsonData.getInt("galleryItemsCount"));
                this.setGiftsCount(jsonData.getInt("giftsCount"));

                this.setAllowShowMyInfo(jsonData.getInt("allowShowMyInfo"));
                this.setAllowShowMyFriends(jsonData.getInt("allowShowMyFriends"));
                this.setAllowShowMyGallery(jsonData.getInt("allowShowMyGallery"));
                this.setAllowShowMyGifts(jsonData.getInt("allowShowMyGifts"));

                this.setAllowComments(jsonData.getInt("allowComments"));
                this.setAllowMessages(jsonData.getInt("allowMessages"));

                if (jsonData.has("inBlackList")) {

                    this.setInBlackList(jsonData.getBoolean("inBlackList"));
                }

                if (jsonData.has("follower")) {

                    this.setFollower(jsonData.getBoolean("follower"));
                }

                if (jsonData.has("follow")) {

                    this.setFollow(jsonData.getBoolean("follow"));
                }

                if (jsonData.has("friend")) {

                    this.setFriend(jsonData.getBoolean("friend"));
                }

                if (jsonData.has("online")) {

                    this.setOnline(jsonData.getBoolean("online"));
                }

                if (jsonData.has("blocked")) {

                    this.setBlocked(jsonData.getBoolean("blocked"));
                }

                this.setLastActive(jsonData.getInt("lastAuthorize"));
                this.setLastActiveDate(jsonData.getString("lastAuthorizeDate"));
                this.setLastActiveTimeAgo(jsonData.getString("lastAuthorizeTimeAgo"));

                if (jsonData.has("allowVideoCalls")) {

                    this.setAllowVideoCalls(jsonData.getInt("allowVideoCalls"));
                }

                if (jsonData.has("allowGalleryComments")) {

                    this.setAllowGalleryComments(jsonData.getInt("allowGalleryComments"));
                }

                if (jsonData.has("distance")) {

                    this.setDistance(jsonData.getDouble("distance"));
                }

                if (jsonData.has("pro")) {

                    this.setProMode(jsonData.getInt("pro"));
                }

                if (jsonData.has("reaction")) {

                    this.setReaction(jsonData.getInt("reaction"));
                }

                if (jsonData.has("profileType")) {

                    this.setProfileType(jsonData.getInt("profileType"));
                }

                if (jsonData.has("account_free")) {

                    this.setAccountFree(jsonData.getInt("account_free"));
                }

                if (jsonData.has("gl_id")) {

                    this.setGoogleId(jsonData.getString("gl_id"));
                }

                if (jsonData.has("fb_id")) {

                    this.setFacebookId(jsonData.getString("fb_id"));
                }

                if (jsonData.has("companyName")) {

                    this.setCompanyName(jsonData.getString("companyName"));
                }

                if (jsonData.has("public_phone")) {

                    this.setPublicPhone(jsonData.getString("public_phone"));
                }

                if (jsonData.has("public_email")) {

                    this.setPublicEmail(jsonData.getString("public_email"));
                }

                if (jsonData.has("allowShowLikedVideos")) {

                    this.setAllowShowLikedVideos(jsonData.getInt("allowShowLikedVideos"));
                }

                if (jsonData.has("allowDownloadVideos")) {

                    this.setAllowDownloadVideos(jsonData.getInt("allowDownloadVideos"));
                }

                if (jsonData.has("balance")) {

                    this.setBalance(jsonData.getInt("balance"));
                }

                if (jsonData.has("ghost")) {

                    this.setGhostMode(jsonData.getInt("ghost"));
                }

                if (jsonData.has("blogger")) {

                    this.setBloggerMode(jsonData.getInt("blogger"));
                }

                if (jsonData.has("music_fan")) {

                    this.setMusicFanMode(jsonData.getInt("music_fan"));
                }

                if (jsonData.has("admob")) {

                    this.setAdmobMode(jsonData.getInt("admob"));
                }

                if (jsonData.has("otpPhone")) {

                    this.setOtpPhone(jsonData.getString("otpPhone"));
                }

                if (jsonData.has("otpVerified")) {

                    this.setOtpVerified(jsonData.getInt("otpVerified"));
                }
            }

        } catch (Throwable t) {

            Log.e("Profile", "Could not parse malformed JSON: \"" + jsonData.toString() + "\"");

        } finally {

            Log.d("Profile", jsonData.toString());
        }
    }

    protected Profile(Parcel in) {
        id = in.readLong();
        profile_type = in.readInt();
        account_free = in.readInt();
        otpVerified = in.readInt();
        ghostMode = in.readInt();
        balance = in.readInt();
        admobMode = in.readInt();
        bloggerMode = in.readInt();
        musicFanMode = in.readInt();
        otpPhone = in.readString();
        google_id = in.readString();
        fb_id = in.readString();
        area = in.readString();
        country = in.readString();
        city = in.readString();
        if (in.readByte() == 0) {
            lat = null;
        } else {
            lat = in.readDouble();
        }
        if (in.readByte() == 0) {
            lng = null;
        } else {
            lng = in.readDouble();
        }
        mood = in.readInt();
        state = in.readInt();
        sex = in.readInt();
        year = in.readInt();
        month = in.readInt();
        day = in.readInt();
        verified = in.readInt();
        pro = in.readInt();
        itemsCount = in.readInt();
        galleryItemsCount = in.readInt();
        likesCount = in.readInt();
        giftsCount = in.readInt();
        friendsCount = in.readInt();
        followingsCount = in.readInt();
        followersCount = in.readInt();
        allowShowLikedVideos = in.readInt();
        allowDownloadVideos = in.readInt();
        allowComments = in.readInt();
        allowMessages = in.readInt();
        lastAuthorize = in.readInt();
        accountType = in.readInt();
        allowShowMyInfo = in.readInt();
        allowShowMyFriends = in.readInt();
        allowShowMyGallery = in.readInt();
        allowShowMyGifts = in.readInt();
        allowGalleryComments = in.readInt();
        allowVideoCalls = in.readInt();
        distance = in.readDouble();
        reaction = in.readInt();
        username = in.readString();
        fullname = in.readString();
        lowPhotoUrl = in.readString();
        bigPhotoUrl = in.readString();
        normalPhotoUrl = in.readString();
        normalCoverUrl = in.readString();
        location = in.readString();
        facebookPage = in.readString();
        instagramPage = in.readString();
        bio = in.readString();
        lastAuthorizeDate = in.readString();
        lastAuthorizeTimeAgo = in.readString();
        byte tmpBlocked = in.readByte();
        blocked = tmpBlocked == 0 ? null : tmpBlocked == 1;
        byte tmpInBlackList = in.readByte();
        inBlackList = tmpInBlackList == 0 ? null : tmpInBlackList == 1;
        byte tmpFollower = in.readByte();
        follower = tmpFollower == 0 ? null : tmpFollower == 1;
        byte tmpFollow = in.readByte();
        follow = tmpFollow == 0 ? null : tmpFollow == 1;
        byte tmpFriend = in.readByte();
        friend = tmpFriend == 0 ? null : tmpFriend == 1;
        byte tmpOnline = in.readByte();
        online = tmpOnline == 0 ? null : tmpOnline == 1;
        profileType = in.readInt();
        companyName = in.readString();
        public_email = in.readString();
        public_phone = in.readString();
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeInt(profile_type);
        dest.writeInt(account_free);
        dest.writeInt(otpVerified);
        dest.writeInt(ghostMode);
        dest.writeInt(balance);
        dest.writeInt(admobMode);
        dest.writeInt(bloggerMode);
        dest.writeInt(musicFanMode);
        dest.writeString(otpPhone);
        dest.writeString(google_id);
        dest.writeString(fb_id);
        dest.writeString(area);
        dest.writeString(country);
        dest.writeString(city);
        if (lat == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(lat);
        }
        if (lng == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(lng);
        }
        dest.writeInt(mood);
        dest.writeInt(state);
        dest.writeInt(sex);
        dest.writeInt(year);
        dest.writeInt(month);
        dest.writeInt(day);
        dest.writeInt(verified);
        dest.writeInt(pro);
        dest.writeInt(itemsCount);
        dest.writeInt(galleryItemsCount);
        dest.writeInt(likesCount);
        dest.writeInt(giftsCount);
        dest.writeInt(friendsCount);
        dest.writeInt(followingsCount);
        dest.writeInt(followersCount);
        dest.writeInt(allowShowLikedVideos);
        dest.writeInt(allowDownloadVideos);
        dest.writeInt(allowComments);
        dest.writeInt(allowMessages);
        dest.writeInt(lastAuthorize);
        dest.writeInt(accountType);
        dest.writeInt(allowShowMyInfo);
        dest.writeInt(allowShowMyFriends);
        dest.writeInt(allowShowMyGallery);
        dest.writeInt(allowShowMyGifts);
        dest.writeInt(allowGalleryComments);
        dest.writeInt(allowVideoCalls);
        dest.writeDouble(distance);
        dest.writeInt(reaction);
        dest.writeString(username);
        dest.writeString(fullname);
        dest.writeString(lowPhotoUrl);
        dest.writeString(bigPhotoUrl);
        dest.writeString(normalPhotoUrl);
        dest.writeString(normalCoverUrl);
        dest.writeString(location);
        dest.writeString(facebookPage);
        dest.writeString(instagramPage);
        dest.writeString(bio);
        dest.writeString(lastAuthorizeDate);
        dest.writeString(lastAuthorizeTimeAgo);
        dest.writeByte((byte) (blocked == null ? 0 : blocked ? 1 : 2));
        dest.writeByte((byte) (inBlackList == null ? 0 : inBlackList ? 1 : 2));
        dest.writeByte((byte) (follower == null ? 0 : follower ? 1 : 2));
        dest.writeByte((byte) (follow == null ? 0 : follow ? 1 : 2));
        dest.writeByte((byte) (friend == null ? 0 : friend ? 1 : 2));
        dest.writeByte((byte) (online == null ? 0 : online ? 1 : 2));
        dest.writeInt(profileType);
        dest.writeString(companyName);
        dest.writeString(public_email);
        dest.writeString(public_phone);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Profile> CREATOR = new Creator<Profile>() {
        @Override
        public Profile createFromParcel(Parcel in) {
            return new Profile(in);
        }

        @Override
        public Profile[] newArray(int size) {
            return new Profile[size];
        }
    };

    public void setDistance(double distance) {

        this.distance = distance;
    }

    public double getDistance() {

        return this.distance;
    }

    public void setId(long profile_id) {

        this.id = profile_id;
    }

    public long getId() {

        return this.id;
    }

    public void setState(int profileState) {

        this.state = profileState;
    }

    public int getState() {

        return this.state;
    }

    public void setType(int accountType) {

        this.accountType = accountType;
    }

    public int getType() {

        return this.accountType;
    }

    public void setSex(int sex) {

        this.sex = sex;
    }

    public int getSex() {

        return this.sex;
    }

    public void setYear(int year) {

        this.year = year;
    }

    public int getYear() {

        return this.year;
    }

    public void setMonth(int month) {

        this.month = month;
    }

    public int getMonth() {

        return this.month;
    }

    public void setDay(int day) {

        this.day = day;
    }

    public int getDay() {

        return this.day;
    }

    public void setProMode(int proMode) {

        this.pro = proMode;
    }

    public int getProMode() {

        return this.pro;
    }

    public Boolean isProMode() {

        if (this.pro > 0) {

            return true;
        }

        return false;
    }

    public void setVerified(int verified) {

        this.verified = verified;
    }

    public int getVerified() {

        return this.verified;
    }

    public Boolean isVerified() {

        if (this.verified > 0) {

            return true;
        }

        return false;
    }

    public void setUsername(String profile_username) {

        this.username = profile_username;
    }

    public String getUsername() {

        return this.username;
    }

    public void setFullname(String profile_fullname) {

        this.fullname = profile_fullname;
    }

    public String getFullname() {

        if (fullname == null) {

            fullname = "";
        }

        return this.fullname;
    }

    public void setLocation(String location) {

        this.location = location;
    }

    public String getLocation() {

        if (this.location == null) {

            this.location = "";
        }

        return this.location;
    }

    public void setFacebookPage(String facebookPage) {

        this.facebookPage = facebookPage;
    }

    public String getFacebookPage() {

        if (facebookPage == null) {

            facebookPage = "";
        }

        return this.facebookPage;
    }

    public void setInstagramPage(String instagramPage) {

        this.instagramPage = instagramPage;
    }

    public String getInstagramPage() {

        if (instagramPage == null) {

            instagramPage = "";
        }

        return this.instagramPage;
    }

    public void setBio(String bio) {

        this.bio = bio;
    }

    public String getBio() {

        if (bio == null) {

            bio = "";
        }

        return this.bio;
    }

    public void setLowPhotoUrl(String lowPhotoUrl) {

        if (API_DOMAIN.equals("http://10.0.2.2/")) {

            this.lowPhotoUrl = lowPhotoUrl.replace("http://localhost/","http://10.0.2.2/");

        } else {

            this.lowPhotoUrl = lowPhotoUrl;
        }
    }

    public String getLowPhotoUrl() {

        if (this.lowPhotoUrl == null) {

            this.lowPhotoUrl = "";
        }

        return this.lowPhotoUrl;
    }

    public void setBigPhotoUrl(String bigPhotoUrl) {

        this.bigPhotoUrl = bigPhotoUrl;
    }

    public String getBigPhotoUrl() {

        return this.bigPhotoUrl;
    }

    public void setNormalPhotoUrl(String normalPhotoUrl) {

        this.normalPhotoUrl = normalPhotoUrl;
    }

    public String getNormalPhotoUrl() {

        return this.normalPhotoUrl;
    }

    public void setNormalCoverUrl(String normalCoverUrl) {

        this.normalCoverUrl = normalCoverUrl;
    }

    public String getNormalCoverUrl() {

        return this.normalCoverUrl;
    }

    public void setFollowersCount(int followersCount) {

        this.followersCount = followersCount;
    }

    public int getFollowersCount() {

        return this.followersCount;
    }

    public void setItemsCount(int itemsCount) {

        this.itemsCount = itemsCount;
    }

    public int getItemsCount() {

        return this.itemsCount;
    }

    public void setGalleryItemsCount(int galleryItemsCount) {

        this.galleryItemsCount = galleryItemsCount;
    }

    public int getGalleryItemsCount() {

        return this.galleryItemsCount;
    }

    public void setLikesCount(int likesCount) {

        this.likesCount = likesCount;
    }

    public int getLikesCount() {

        return this.likesCount;
    }

    public void setGiftsCount(int giftsCount) {

        this.giftsCount = giftsCount;
    }

    public int getGiftsCount() {

        return this.giftsCount;
    }

    public void setFollowingsCount(int followingsCount) {

        this.followingsCount = followingsCount;
    }

    public int getFollowingsCount() {

        return this.followingsCount;
    }

    public void setFriendsCount(int friendsCount) {

        this.friendsCount = friendsCount;
    }

    public int getFriendsCount() {

        return this.friendsCount;
    }

    public void setAllowComments(int allowComments) {

        this.allowComments = allowComments;
    }

    public int getAllowComments() {

        return this.allowComments;
    }

    public void setAllowMessages(int allowMessages) {

        this.allowMessages = allowMessages;
    }

    public int getAllowMessages() {

        return this.allowMessages;
    }

    public void setMood(int mood) {

        this.mood = mood;
    }

    public int getMood() {

        return this.mood;
    }

    public void setLastActive(int lastAuthorize) {

        this.lastAuthorize = lastAuthorize;
    }

    public int getLastActive() {

        return this.lastAuthorize;
    }

    public void setLastActiveDate(String lastAuthorizeDate) {

        this.lastAuthorizeDate = lastAuthorizeDate;
    }

    public String getLastActiveDate() {

        return this.lastAuthorizeDate;
    }

    public void setLastActiveTimeAgo(String lastAuthorizeTimeAgo) {

        this.lastAuthorizeTimeAgo = lastAuthorizeTimeAgo;
    }

    public String getLastActiveTimeAgo() {

        return this.lastAuthorizeTimeAgo;
    }

    public void setBlocked(Boolean blocked) {

        this.blocked = blocked;
    }

    public Boolean isBlocked() {

        return this.blocked;
    }

    public void setFollower(Boolean follower) {

        this.follower = follower;
    }

    public Boolean isFollower() {

        return this.follower;
    }

    public void setFollow(Boolean follow) {

        this.follow = follow;
    }

    public Boolean isFollow() {

        return this.follow;
    }

    public void setFriend(Boolean friend) {

        this.friend = friend;
    }

    public Boolean isFriend() {

        return this.friend;
    }

    public void setOnline(Boolean online) {

        this.online = online;
    }

    public Boolean isOnline() {

        return this.online;
    }

    public void setInBlackList(Boolean inBlackList) {

        this.inBlackList = inBlackList;
    }

    public Boolean isInBlackList() {

        return this.inBlackList;
    }

    // Privacy

    public void setAllowShowMyInfo(int allowShowMyInfo) {

        this.allowShowMyInfo = allowShowMyInfo;
    }

    public int getAllowShowMyInfo() {

        return this.allowShowMyInfo;
    }

    public void setAllowShowMyFriends(int allowShowMyFriends) {

        this.allowShowMyFriends = allowShowMyFriends;
    }

    public int getAllowShowMyFriends() {

        return this.allowShowMyFriends;
    }

    public void setAllowShowMyGallery(int allowShowMyGallery) {

        this.allowShowMyGallery = allowShowMyGallery;
    }

    public int getAllowShowMyGallery() {

        return this.allowShowMyGallery;
    }

    public void setAllowShowMyGifts(int allowShowMyGifts) {

        this.allowShowMyGifts = allowShowMyGifts;
    }

    public int getAllowShowMyGifts() {

        return this.allowShowMyGifts;
    }

    public int getAllowGalleryComments() {

        return this.allowGalleryComments;
    }

    public void setAllowGalleryComments(int allowGalleryComments) {

        this.allowGalleryComments = allowGalleryComments;
    }

    public int getAllowVideoCalls() {

        return this.allowVideoCalls;
    }

    public void setAllowVideoCalls(int allowVideoCalls) {

        this.allowVideoCalls = allowVideoCalls;
    }

    public void setReaction(int reaction) {

        this.reaction = reaction;
    }

    public int getReaction() {

        return this.reaction;
    }

    public void setCompanyName(String companyName) {

        this.companyName = companyName;
    }

    public String getCompanyName() {

        return this.companyName;
    }

    public void setPublicPhone(String phone) {

        this.public_phone = phone;
    }

    public String getPublicPhone() {

        return this.public_phone;
    }

    public void setPublicEmail(String email) {

        this.public_email = email;
    }

    public String getPublicEmail() {

        return this.public_email;
    }

    public void setAllowShowLikedVideos(int allowShowLikedVideos) {

        this.allowShowLikedVideos = allowShowLikedVideos;
    }

    public int getAllowShowLikedVideos() {

        return this.allowShowLikedVideos;
    }

    public void setAllowDownloadVideos(int allowDownloadVideos) {

        this.allowDownloadVideos = allowDownloadVideos;
    }

    public int getAllowDownloadVideos() {

        return this.allowDownloadVideos;
    }

    //

    public void setFacebookId(String fb_id) {

        this.fb_id = fb_id;
    }

    public String getFacebookId() {

        if (this.fb_id == null) {

            this.fb_id = "";
        }

        return this.fb_id;
    }

    public void setGoogleId(String google_id) {

        this.google_id = google_id;
    }

    public String getGoogleId() {

        if (this.google_id == null) {

            this.google_id = "";
        }

        return this.google_id;
    }

    public void setAccountFree(int account_free) {

        this.account_free = account_free;
    }

    public int getAccountFree() {

        return this.account_free;
    }

    public void setProfileType(int profile_type) {

        this.profile_type = profile_type;
    }

    public int getProfileType() {

        return this.profile_type;
    }

    public void setGhostMode(int ghost) {

        this.ghostMode = ghostMode;
    }

    public int getGhostMode() {

        return this.ghostMode;
    }

    public void setBloggerMode(int blogger) {

        this.bloggerMode = blogger;
    }

    public int getBloggerMode() {

        return this.bloggerMode;
    }

    public void setMusicFanMode(int musicFanMode) {

        this.musicFanMode = musicFanMode;
    }

    public int getMusicFanMode() {

        return this.musicFanMode;
    }

    public void setBalance(int balance) {

        this.balance = balance;
    }

    public int getBalance() {

        return this.balance;
    }

    public void setAdmobMode(int admobMode) {

        this.admobMode = admobMode;
    }

    public int getAdmobMode() {

        return this.admobMode;
    }

    public void setOtpVerified(int otpVerified) {

        this.otpVerified = otpVerified;
    }

    public int getOtpVerified() {

        return this.otpVerified;
    }

    public void setOtpPhone(String otpPhone) {

        this.otpPhone = otpPhone;
    }

    public String getOtpPhone() {

        if (this.otpPhone == null) {

            this.otpPhone = "";
        }

        return this.otpPhone;
    }

    public void setCountry(String country) {

        this.country = country;
    }

    public String getCountry() {

        if (this.country == null) {

            this.setCountry("");
        }

        return this.country;
    }

    public void setCity(String city) {

        this.city = city;
    }

    public String getCity() {

        if (this.city == null) {

            this.setCity("");
        }

        return this.city;
    }

    public void setArea(String area) {

        this.area = area;
    }

    public String getArea() {

        if (this.area == null) {

            this.setArea("");
        }

        return this.area;
    }

    public void setLat(Double lat) {

        this.lat = lat;
    }

    public Double getLat() {

        if (this.lat == null) {

            this.lat = 0.000000;
        }

        return this.lat;
    }

    public void setLng(Double lng) {

        this.lng = lng;
    }

    public Double getLng() {

        if (this.lng == null) {

            this.lng = 0.000000;
        }

        return this.lng;
    }
}
