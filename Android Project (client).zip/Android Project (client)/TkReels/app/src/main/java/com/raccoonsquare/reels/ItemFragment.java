package com.raccoonsquare.reels;

import static android.content.Context.RECEIVER_NOT_EXPORTED;

import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Html;
import android.text.method.LinkMovementMethod;
import android.util.Log;
import android.util.TypedValue;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.fragment.app.Fragment;
import androidx.viewpager2.widget.ViewPager2;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.bumptech.glide.Glide;
import com.google.android.exoplayer2.ExoPlayer;
import com.google.android.exoplayer2.ui.DefaultTimeBar;
import com.google.android.exoplayer2.ui.TimeBar;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Item;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.util.Helper;
import com.raccoonsquare.reels.util.OnSwipeTouchListener;
import com.raccoonsquare.reels.util.TagClick;
import com.raccoonsquare.reels.util.TagSelectingTextview;

import com.google.android.exoplayer2.DefaultLoadControl;
import com.google.android.exoplayer2.LoadControl;
import com.google.android.exoplayer2.MediaItem;
import com.google.android.exoplayer2.Player;
import com.google.android.exoplayer2.source.MediaSource;
import com.google.android.exoplayer2.source.ProgressiveMediaSource;
import com.google.android.exoplayer2.trackselection.DefaultTrackSelector;
import com.google.android.exoplayer2.ui.PlayerView;
import com.google.android.exoplayer2.upstream.DataSource;
import com.google.android.exoplayer2.upstream.DefaultAllocator;
import com.google.android.exoplayer2.upstream.DefaultDataSourceFactory;
import com.mikhaellopez.circularimageview.CircularImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class ItemFragment extends Fragment implements Constants, TagClick {

    private static final String STATE_LIST = "State Adapter Data";

    TagSelectingTextview mTagSelectingTextview;

    public static int hashTagHyperLinkDisabled = 0;

    ImageLoader imageLoader = App.getInstance().getImageLoader();

    private LinearLayout mSideMenu, mLikeLayout, mCommentLayout, mShareLayout, mItemActionsLayout, mBottomLayout;

    private RelativeLayout mProfileLayout, mExoControllers;
    private LinearLayout mExoControllersTime, mSoundLayout;

    private LinearLayout mFollowLayout;
    private TextView mFollowLabel;

    private DefaultTimeBar mExoProgress;

    private ImageView mPreviewImage, mLikeImage, mPlayImage;

    private CircularImageView mProfileImage, mVerifiedImage;

    private PlayerView mPlayerView;

    private TextView mFullname, mDescription, mSoundName, mViewsCount, mCommentsCount, mLikesCount;

    private ProgressBar mProgressBar;

    private ViewPager2 mMenuPager;

    private Item item;

    public ExoPlayer exoplayer;

    private Context mContext;

    private Boolean isVisibleToUser, isMainPage = false, isUpdateViews = false;

    public ItemFragment(Item item, ViewPager2 mMenuPager, Boolean isMainPage) {

        this.item = item;
        this.mMenuPager = mMenuPager;
        this.isMainPage = isMainPage;

        if (imageLoader == null) {

            imageLoader = App.getInstance().getImageLoader();
        }
    }

    public ItemFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_item, container, false);

        mContext = rootView.getContext();

        //

        mPlayerView = rootView.findViewById(R.id.player_view);

        mPreviewImage = rootView.findViewById(R.id.preview_image);
        mPreviewImage.setVisibility(View.GONE);

        mPlayImage = rootView.findViewById(R.id.play_image);
        mPlayImage.setVisibility(View.GONE);
        mPlayImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mPlayImage.setVisibility(View.GONE);

                exoplayer.setPlayWhenReady(true);
            }
        });

        mProgressBar = rootView.findViewById(R.id.progress_bar);

        //

        mBottomLayout = rootView.findViewById(R.id.bottom_layout);
        mExoControllers = rootView.findViewById(R.id.exo_controllers);

        mExoControllersTime = rootView.findViewById(R.id.exo_controllers_time);
        mExoControllersTime.setVisibility(View.GONE);

        mExoProgress = rootView.findViewById(R.id.exo_progress);

        mExoProgress.addListener(new TimeBar.OnScrubListener() {

            @Override
            public void onScrubStart(TimeBar timeBar, long position) {

                mExoControllersTime.setVisibility(View.VISIBLE);
                mSideMenu.setVisibility(View.GONE);
                mBottomLayout.setVisibility(View.GONE);
            }

            @Override
            public void onScrubMove(TimeBar timeBar, long position) {

            }

            @Override
            public void onScrubStop(TimeBar timeBar, long position, boolean canceled) {

                if (exoplayer != null) {

                    mExoControllersTime.setVisibility(View.GONE);
                    mSideMenu.setVisibility(View.VISIBLE);
                    mBottomLayout.setVisibility(View.VISIBLE);
                }
            }
        });

        // Side menu

        mSideMenu = rootView.findViewById(R.id.side_menu);

        mProfileLayout = rootView.findViewById(R.id.profile_layout);
        mLikeLayout = rootView.findViewById(R.id.like_layout);
        mCommentLayout = rootView.findViewById(R.id.comment_layout);
        mShareLayout = rootView.findViewById(R.id.share_layout);
        mItemActionsLayout = rootView.findViewById(R.id.item_actions_layout);

        mProfileImage = rootView.findViewById(R.id.profile_image);
        mVerifiedImage = rootView.findViewById(R.id.verified_image);

        mLikeImage = rootView.findViewById(R.id.like_image);

        mLikesCount = rootView.findViewById(R.id.like_count);
        mCommentsCount = rootView.findViewById(R.id.comment_count);
        mViewsCount = rootView.findViewById(R.id.views_count);

        //

        mTagSelectingTextview = new TagSelectingTextview();

        //

        mCommentLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(TAG_ITEM_ACTION_BOTTOM_SHEET);
                intent.putExtra("message", "comments");
                getContext().sendBroadcast(intent);

                if (exoplayer != null) {

                    mPlayImage.setVisibility(View.VISIBLE);

                    exoplayer.pause();
                }
            }
        });

        mShareLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(TAG_ITEM_ACTION_BOTTOM_SHEET);
                intent.putExtra("message", "share");
                getContext().sendBroadcast(intent);
            }
        });

        mItemActionsLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(TAG_ITEM_ACTION_BOTTOM_SHEET);
                intent.putExtra("message", "actions");
                getContext().sendBroadcast(intent);
            }
        });

        mProfileLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(getActivity(), ProfileActivity.class);
                intent.putExtra("profileId", item.getFromUserId());
                startActivity(intent);
            }
        });

        mLikeLayout.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (App.getInstance().getId() == 0) {

                    Intent intent = new Intent(TAG_ITEM_ACTION_BOTTOM_SHEET);
                    intent.putExtra("message", "auth");
                    getContext().sendBroadcast(intent);

                } else {

                    if (item.isMyLike()) {

                        item.setMyLike(false);
                        item.setLikesCount(item.getLikesCount() - 1);

                    } else {

                        item.setMyLike(true);
                        item.setLikesCount(item.getLikesCount() + 1);
                    }

                    makeLike(item.getId(), 0);
                    updateView();
                }
            }
        });

        //

        mFullname = rootView.findViewById(R.id.fullname_text);
        mDescription = rootView.findViewById(R.id.desc_text);
        mSoundName = rootView.findViewById(R.id.sound_name_text);

        initPlayer();

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
            @Override
            public void run() {

                updateView();
            }

        },200);

        //

        mFollowLayout = rootView.findViewById(R.id.follow_layout);
        mFollowLayout.setVisibility(View.GONE);
        mFollowLabel = rootView.findViewById(R.id.follow_label);

        mFollowLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (App.getInstance().getId() == 0) {

                    Intent intent = new Intent(TAG_ITEM_ACTION_BOTTOM_SHEET);
                    intent.putExtra("message", "auth");
                    getContext().sendBroadcast(intent);

                } else {

                    if (item.getIsFollow()) {

                        item.setIsFollow(false);

                    } else {

                        item.setIsFollow(true);
                    }

                    follow();
                    updateView();
                }
            }
        });

        //

        mSoundLayout = rootView.findViewById(R.id.sound_layout);
        mSoundLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (item.getSoundId() != 0) {

                    Intent i = new Intent(getActivity(), SoundsActivity.class);
                    i.putExtra("soundId", item.getSoundId());
                    i.putExtra("soundTitle", item.getSound().getTitle());
                    i.putExtra("soundDesc", item.getSound().getDesc());
                    i.putExtra("soundUrl", item.getSound().getMp3Url());
                    i.putExtra("soundImgUrl", item.getSound().getImgUrl());
                    getActivity().startActivity(i);
                }
            }
        });

        return rootView;
    }

    public void updateView() {

        if (isAdded()) {

            mVerifiedImage.setVisibility(View.GONE);

            if (item.getFromUserVerify() == 1) {

                mVerifiedImage.setVisibility(View.VISIBLE);
            }

            if (item.getFromUserPhotoUrl() != null && item.getFromUserPhotoUrl().length() != 0) {

                imageLoader.get(item.getFromUserPhotoUrl(), ImageLoader.getImageListener(mProfileImage, R.drawable.profile_default_photo, R.drawable.profile_default_photo));
            }

            mFullname.setText(item.getFromUserFullname());

            if (item.getSoundId() == 0) {

                mSoundName.setText("Original sound - " + item.getFromUserUsername());

            } else {

                mSoundName.setText(item.getSound().getTitle());
            }

            mSoundName.setSelected(true);

            //mDescription.setText(item.getPost());
            mDescription.setMovementMethod(LinkMovementMethod.getInstance());

            String textHtml = item.getPost();

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.N) {

                mDescription.setText(mTagSelectingTextview.addClickablePart(Html.fromHtml(textHtml, Html.FROM_HTML_MODE_LEGACY).toString(), this, hashTagHyperLinkDisabled, getResources().getString(R.color.colorHashtag)), TextView.BufferType.SPANNABLE);

            } else {

                mDescription.setText(mTagSelectingTextview.addClickablePart(Html.fromHtml(textHtml).toString(), this, hashTagHyperLinkDisabled, getResources().getString(R.color.colorHashtag)), TextView.BufferType.SPANNABLE);
            }

            mViewsCount.setText(Helper.prettyCount(item.getViewsCount() + 1));
            mCommentsCount.setText(Integer.toString(item.getCommentsCount()));
            mLikesCount.setText(Long.toString(item.getLikesCount()));

            if (item.isMyLike()) {

                mLikeImage.setColorFilter(getActivity().getResources().getColor(R.color.active_like), android.graphics.PorterDuff.Mode.SRC_IN);

            } else {

                mLikeImage.setColorFilter(getActivity().getResources().getColor(R.color.white), android.graphics.PorterDuff.Mode.SRC_IN);
            }

            //

            if (item.getFromUserId() != App.getInstance().getAccount().getId()) {

                mFollowLayout.setVisibility(View.VISIBLE);

                if (item.getIsFollow()) {

                    mFollowLabel.setText(getString(R.string.label_following));

                } else {

                    mFollowLabel.setText(getString(R.string.action_follow));
                }
            }

            //

            if (isMainPage) {

                int actionBarHeight = 0;

                TypedValue tv = new TypedValue();

                if (getActivity().getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {

                    actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data, getResources().getDisplayMetrics());
                }

                RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                        RelativeLayout.LayoutParams.MATCH_PARENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT
                );

                params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                params.setMargins(0, 0, 110, actionBarHeight - 21);
                mBottomLayout.setLayoutParams(params);

                mBottomLayout.invalidate();

                //

                FrameLayout.LayoutParams params2 = new FrameLayout.LayoutParams(
                        RelativeLayout.LayoutParams.MATCH_PARENT,
                        RelativeLayout.LayoutParams.WRAP_CONTENT
                );

                //params2.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
                params2.setMargins(0, 0, 0, actionBarHeight - 22);
                mExoControllers.setLayoutParams(params2);

                mExoControllers.invalidate();
            }
        }
    }

    @Override
    public void clickedTag(CharSequence tag) {

        Intent i = new Intent(getActivity(), FinderActivity.class);
        i.putExtra("tab_position", 2);
        i.putExtra("query", tag);
        startActivity(i);
    }

    private void initPlayer() {

        if (exoplayer == null && item != null) {

//            ExecutorService executorService = Executors.newSingleThreadExecutor();
//            executorService.execute(new Runnable() {
//                @Override
//                public void run() {
//
//
//
//                }
//            });

            LoadControl loadControl = new DefaultLoadControl.Builder()
                    .setAllocator(new DefaultAllocator(true, 16))
                    .setBufferDurationsMs(1 * 1024, 1 * 1024, 500, 1024)
                    .setTargetBufferBytes(-1)
                    .setPrioritizeTimeOverSizeThresholds(true)
                    .build();

            DefaultTrackSelector trackSelector = new DefaultTrackSelector(mContext);

            try {

                //exoplayer = new ExoPlayer.Builder(mContext).build();

                exoplayer = new ExoPlayer.Builder(mContext)
                        .setLooper(Looper.getMainLooper())
                        .setTrackSelector(trackSelector)
                        .setLoadControl(loadControl)
                        .build();

                DataSource.Factory dataSourceFactory = new DefaultDataSourceFactory(mContext, mContext.getString(R.string.app_name));
                MediaSource videoSource = new ProgressiveMediaSource.Factory(dataSourceFactory).createMediaSource(MediaItem.fromUri(item.getVideoUrl()));
                //exoplayer.setThrowsWhenUsingWrongThread(false);

                //MediaItem mediaItem = MediaItem.fromUri(Uri.parse(item.getVideoUrl()));
                //exoplayer.addMediaItem(mediaItem);
                exoplayer.addMediaSource(videoSource);
                exoplayer.prepare();
                exoplayer.setRepeatMode(Player.REPEAT_MODE_ALL);

                exoplayer.addListener(new Player.Listener() {

                    @Override
                    public void onPlaybackStateChanged(@Player.State int state) {

                        if (state == Player.STATE_BUFFERING) {

                            Log.e("ItemFragment", "STATE_BUFFERING");

                            mProgressBar.setVisibility(View.VISIBLE);
                            mExoProgress.setVisibility(View.GONE);

                        } else if (state == Player.STATE_READY) {

                            Log.e("ItemFragment", "STATE_READY");

                            mPreviewImage.setVisibility(View.GONE);
                            //mExoControllersTime.setVisibility(View.GONE);

                            mProgressBar.setVisibility(View.GONE);
                            mExoProgress.setVisibility(View.VISIBLE);
                        }

                        Log.e("ItemFragment", Integer.toString(state));
                    }
                });

//                AudioAttributes audioAttributes = new AudioAttributes.Builder()
//                        .setUsage(C.USAGE_MEDIA)
//                        .setContentType(C.CONTENT_TYPE_MOVIE)
//                        .build();
//
//                exoplayer.setAudioAttributes(audioAttributes, true);

            }  catch (Exception e) {

                Log.d("ItemFragment","Exception audio focus : "+e);
            }

            getActivity().runOnUiThread(new Runnable() {

                @Override
                public void run() {

                    mPlayerView.setVisibility(View.VISIBLE);

                    if (exoplayer != null) {

                        mPlayerView.setPlayer(exoplayer);
                    }
                }
            });
        }
    }

    public void setPlayer(boolean isVisibleToUser) {

        if (exoplayer != null) {

            if (isVisibleToUser) {

                if (!isUpdateViews) {

                    isUpdateViews = true;
                    updateViews();
                }

                mPlayImage.setVisibility(View.GONE);
                //mExoControllersTime.setVisibility(View.GONE);

                exoplayer.setPlayWhenReady(true);

            } else {

                mPlayImage.setVisibility(View.VISIBLE);
                //mExoControllersTime.setVisibility(View.VISIBLE);

                exoplayer.setPlayWhenReady(false);
                mPlayerView.setAlpha(1);
            }

            // Controller

            mPlayerView.setUseController(true);

            mPlayerView.setControllerShowTimeoutMs(0);
            mPlayerView.setControllerHideOnTouch(false);
            mPlayerView.showController();

            //

            mPlayerView.setOnTouchListener(new OnSwipeTouchListener(mContext) {

                public void onSwipeLeft() {

                    //openProfile(item, true);
                }

                @Override
                public void onLongClick() {

                    if (isVisibleToUser) {

                        //showVideoOption(item);
                    }
                }

                @Override
                public void onSingleClick() {

                    if (!exoplayer.getPlayWhenReady()) {

                        exoplayer.setPlayWhenReady(true);
                        //mPlayerView.setAlpha(0);
                        mPlayImage.setVisibility(View.GONE);
                        //mExoControllersTime.setVisibility(View.GONE);

                    } else {

                        mPlayImage.setVisibility(View.VISIBLE);
                        //mExoControllersTime.setVisibility(View.VISIBLE);

                        exoplayer.setPlayWhenReady(false);
                        mPlayerView.setAlpha(1);
                    }
                }

                @Override
                public void onDoubleClick(MotionEvent e) {

                    if (!exoplayer.getPlayWhenReady()) {

                        exoplayer.setPlayWhenReady(true);
                        mPlayImage.setVisibility(View.GONE);
                        //mExoControllersTime.setVisibility(View.GONE);
                    }

                    //likeVideo(item);
                }
            });
        }
    }

    public void releasePlayer() {

        if (exoplayer != null) {

            exoplayer.release();
            exoplayer = null;
        }
    }

    public void mainMenuVisibility(boolean isvisible) {

        if (exoplayer != null && isvisible) {

            exoplayer.setPlayWhenReady(true);

        } else if (exoplayer != null && !isvisible) {

            exoplayer.setPlayWhenReady(false);
            mPlayerView.setAlpha(1);
        }
    }

    @Override
    public void setMenuVisibility(final boolean visible) {

        isVisibleToUser = visible;

        Log.e("ItemFragment", "setMenuVisibility");

        new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {

            @Override
            public void run() {

                if (exoplayer != null && visible) {

                    Log.e("ItemFragment", "Looper.getMainLooper() run()");

                    setPlayer(isVisibleToUser);
                }
            }

        },200);

        if (visible) {

//            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//
//                @Override
//                public void run() {
//
//                    if (view != null && getActivity()!= null) {
//
//                        getActivity().runOnUiThread(new Runnable() {
//                            @Override
//                            public void run() {
//
//                                if (item!=null && item.getId()!= null)
//                                {
//                                    setLikeData();
//
//                                }
//
//                            }
//                        });
//                    }
//                }
//            },200);
        }
    }

    @Override
    public void onResume() {

        super.onResume();

        Log.e("Dimon", " onResume Comments cnt");

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            getActivity().registerReceiver(mItemFragmentReceiver, new IntentFilter(TAG_UPDATE_VIDEO_ITEM), RECEIVER_NOT_EXPORTED);

        } else {

            getActivity().registerReceiver(mItemFragmentReceiver, new IntentFilter(TAG_UPDATE_VIDEO_ITEM));
        }
    }

    @Override
    public void onPause() {

        super.onPause();

        getActivity().unregisterReceiver(mItemFragmentReceiver);

        if (exoplayer != null) {

            mPlayImage.setVisibility(View.VISIBLE);
            //mExoControllersTime.setVisibility(View.VISIBLE);

            exoplayer.setPlayWhenReady(false);
            mPlayerView.setAlpha(1);
        }
    }


    @Override
    public void onStop() {

        super.onStop();

        if (exoplayer != null) {

            mPlayImage.setVisibility(View.VISIBLE);
            //mExoControllersTime.setVisibility(View.VISIBLE);

            exoplayer.setPlayWhenReady(false);
            mPlayerView.setAlpha(1);
        }
    }

    private BroadcastReceiver mItemFragmentReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            // Extract data included in the Intent
            String message = intent.getStringExtra("message");

            long itemId = intent.getLongExtra("itemId", 0);
            int commentsCnt = intent.getIntExtra("comments_cnt", 0);

            if (itemId == item.getId()) {

                if (isAdded()) {

                    item.setCommentsCount(commentsCnt);
                    mCommentsCount.setText(Integer.toString(item.getCommentsCount()));
                }
            }

        }
    };

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onDestroy() {

        releasePlayer();
        super.onDestroy();
    }

    @Override
    public void onAttach(Activity activity) {

        super.onAttach(activity);
    }

    @Override
    public void onDetach() {

        super.onDetach();
    }

    public void updateViews() {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ITEMS_VIEW, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        Log.e("updateViews", response.toString());
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "ItemFragment Not Added to Activity");

                    return;
                }
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());

                params.put("itemId", Long.toString(item.getId()));
                params.put("language", "en");

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    private void makeLike(final long itemId, final int reaction) {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_REACTIONS_MAKE, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {

//                                p.setLikesCount(response.getInt("likesCount"));
//                                p.setMyLike(response.getBoolean("myLike"));
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("Item.Reaction", response.toString());

                            // Interstitial ad

                            if (App.getInstance().getInterstitialAdSettings().getInterstitialAdAfterNewLike() != 0 && App.getInstance().getAccount().getAdmobMode() == ADMOB_DISABLED) {

                                App.getInstance().getInterstitialAdSettings().setCurrentInterstitialAdAfterNewLike(App.getInstance().getInterstitialAdSettings().getCurrentInterstitialAdAfterNewLike() + 1);

                                if (App.getInstance().getInterstitialAdSettings().getCurrentInterstitialAdAfterNewLike() >= App.getInstance().getInterstitialAdSettings().getInterstitialAdAfterNewLike()) {

                                    App.getInstance().getInterstitialAdSettings().setCurrentInterstitialAdAfterNewLike(0);

                                    App.getInstance().showInterstitialAd(null);
                                }

                                App.getInstance().saveData();
                            }

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.e("Item.Reaction", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("reaction", Integer.toString(reaction));
                params.put("itemId", Long.toString(itemId));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void follow() {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_PROFILE_FOLLOW, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {


                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("Item.Follow", response.toString());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.e("Item.Follow", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("profileId", Long.toString(item.getFromUserId()));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }
}