package com.raccoonsquare.reels.videotrimmer.utils;

public enum TrimType {
    DEFAULT, FIXED_DURATION, MIN_DURATION, MIN_MAX_DURATION
}
