package com.raccoonsquare.reels.model;

import android.app.Application;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import com.raccoonsquare.reels.constants.Constants;

import org.json.JSONObject;


public class Sound extends Application implements Constants, Parcelable {

    private long id;
    private String title = "", duration = "", desc = "", imgUrl = "", mp3Url = "";

    private int groupId = 0;

    private Boolean is_bookmark = false, isPlaying = false;

    public Sound() {

    }

    public Sound(JSONObject jsonData) {

        try {

            if (!jsonData.getBoolean("error")) {

                this.setId(jsonData.getLong("id"));

                if (jsonData.has("groupId")) {

                    this.setGroupId(jsonData.getInt("groupId"));
                }

                this.setImgUrl(jsonData.getString("img_url"));
                this.setTitle(jsonData.getString("title"));
                this.setMp3Url(jsonData.getString("mp3_url"));
                this.setDuration(jsonData.getString("duration"));
                this.setDesc(jsonData.getString("description"));

                this.setIsBookmark(jsonData.getBoolean("is_bookmark"));
            }

        } catch (Throwable t) {

            Log.e("Sound", "Could not parse malformed JSON: \"" + jsonData.toString() + "\"");

        } finally {

            Log.d("Sound", jsonData.toString());
        }
    }


    protected Sound(Parcel in) {
        id = in.readLong();
        title = in.readString();
        duration = in.readString();
        desc = in.readString();
        imgUrl = in.readString();
        mp3Url = in.readString();
        groupId = in.readInt();
        byte tmpIs_bookmark = in.readByte();
        is_bookmark = tmpIs_bookmark == 0 ? null : tmpIs_bookmark == 1;
        byte tmpIsPlaying = in.readByte();
        isPlaying = tmpIsPlaying == 0 ? null : tmpIsPlaying == 1;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeString(title);
        dest.writeString(duration);
        dest.writeString(desc);
        dest.writeString(imgUrl);
        dest.writeString(mp3Url);
        dest.writeInt(groupId);
        dest.writeByte((byte) (is_bookmark == null ? 0 : is_bookmark ? 1 : 2));
        dest.writeByte((byte) (isPlaying == null ? 0 : isPlaying ? 1 : 2));
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Sound> CREATOR = new Creator<Sound>() {
        @Override
        public Sound createFromParcel(Parcel in) {
            return new Sound(in);
        }

        @Override
        public Sound[] newArray(int size) {
            return new Sound[size];
        }
    };

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public int getGroupId() {

        return groupId;
    }

    public void setGroupId(int groupId) {

        this.groupId = groupId;
    }


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }


    public String getImgUrl() {

        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {

        this.imgUrl = imgUrl;
    }

    public String getMp3Url() {

        return mp3Url;
    }

    public void setMp3Url(String mp3Url) {

        this.mp3Url = mp3Url;
    }

    public String getDesc() {

        if (desc == null) {

            desc = "";
        }

        return desc;
    }

    public void setDesc(String desc) {

        this.desc = desc;
    }

    public String getDuration() {

        return duration;
    }

    public void setDuration(String duration) {

        this.duration = duration;
    }

    public void setIsBookmark(Boolean is_bookmark) {

        this.is_bookmark = is_bookmark;
    }

    public Boolean isBookmark() {

        return is_bookmark;
    }

    public void setIsPlaying(Boolean isPlaying) {

        this.isPlaying = isPlaying;
    }

    public Boolean isPlaying() {

        return isPlaying;
    }
}
