package com.raccoonsquare.reels;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.raccoonsquare.reels.adapter.SectionsPagerAdapter;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.common.ActivityBase;
import com.google.android.material.tabs.TabLayout;

public class SoundContentActivity extends ActivityBase {

    Toolbar mToolbar;

    ViewPager mViewPager;
    TabLayout mTabLayout;

    SectionsPagerAdapter adapter;

    private Boolean restore = false;

    private long profileId = 0;
    private int pageId = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sound_content);

        if (savedInstanceState != null) {

            restore = savedInstanceState.getBoolean("restore");
            pageId = savedInstanceState.getInt("pageId");
            profileId = savedInstanceState.getLong("profileId");

        } else {

            restore = false;
            pageId = 0;
            profileId = App.getInstance().getId();
        }

        //

        setTitle(getString(R.string.title_activity_select_sound));

        //

        Intent i = getIntent();

        pageId = i.getIntExtra("pageId", 0);

        profileId = i.getLongExtra("profileId", 0);
        if (profileId == 0) profileId = App.getInstance().getId();

        //

        // Toolbar

        mToolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        // ViewPager

        mViewPager = (ViewPager) findViewById(R.id.view_pager);

        adapter = new SectionsPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new SoundDiscoverFragment(), getString(R.string.tab_free_sound));
        adapter.addFragment(new SoundDiscoverFragment(true, true), getString(R.string.tab_music_fan));
        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(pageId);

        // TabLayout

        mTabLayout = (TabLayout) findViewById(R.id.tab_layout);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("restore", true);
        outState.putLong("profileId", profileId);
        outState.putInt("pageId", pageId);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {

            case android.R.id.home: {

                finish();

                return true;
            }

            default: {

                return super.onOptionsItemSelected(item);
            }
        }
    }

    @Override
    public void onResume() {

        super.onResume();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            registerReceiver(mSelectSoundReceiver, new IntentFilter(TAG_SELECT_SOUND_ITEM), RECEIVER_NOT_EXPORTED);

        } else {

            registerReceiver(mSelectSoundReceiver, new IntentFilter(TAG_SELECT_SOUND_ITEM));
        }
    }

    @Override
    public void onPause() {

        super.onPause();

        unregisterReceiver(mSelectSoundReceiver);
    }

    private void selectMp3(long soundId, String soundTitle, String soundUrl) {

        Intent i = new Intent();
        i.putExtra("soundId", soundId);
        i.putExtra("soundTitle", soundTitle);
        i.putExtra("soundUrl", soundUrl);

        setResult(100, i);

        finish();
    }

    private BroadcastReceiver mSelectSoundReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            long soundId = intent.getLongExtra("soundId", 0);
            String soundTitle = intent.getStringExtra("soundTitle");
            String soundUrl = intent.getStringExtra("soundUrl");

            selectMp3(soundId, soundTitle, soundUrl);
        }
    };

}
