package com.raccoonsquare.reels.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.recyclerview.widget.RecyclerView;

import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.model.Sound;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;


public class SoundListAdapter extends RecyclerView.Adapter<SoundListAdapter.MyViewHolder> {

    private List<Sound> items;
    private Context ctx;

    private Boolean isSelectable = true;

    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {

        void onItemClick(View view, Sound obj, int position, int action);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {

        this.mOnItemClickListener = mItemClickListener;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder {

        public ConstraintLayout mParent;
        public ImageView mSoundImage, mStatusImage;
        public TextView mTitle, mDesc, mDuration;

        public ImageButton mBookmarkButton, mSelectButton;

        public ProgressBar mProgressBar;

        public MyViewHolder(View view) {

            super(view);

            mParent = view.findViewById(R.id.parent);

            mTitle = (TextView) view.findViewById(R.id.sound_title_txt);
            mDesc = (TextView) view.findViewById(R.id.sound_desc_txt);
            mDuration = (TextView) view.findViewById(R.id.duration_time_txt);

            mSoundImage = (ImageView) view.findViewById(R.id.sound_image);
            mStatusImage = (ImageView) view.findViewById(R.id.status_image);

            mBookmarkButton = (ImageButton) view.findViewById(R.id.bookmark_btn);
            mSelectButton = (ImageButton) view.findViewById(R.id.select_btn);

            mProgressBar = (ProgressBar) view.findViewById(R.id.progress_bar);
        }
    }


    public SoundListAdapter(Context context, List<Sound> items, Boolean isSelectable) {

        this.ctx = context;
        this.items = items;
        this.isSelectable = isSelectable;
    }

    @Override
    public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_sound_layout, parent, false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(MyViewHolder holder, final int position) {

        final Sound item = items.get(position);

        holder.mTitle.setText(item.getTitle());
        holder.mDesc.setText(item.getDesc());
        holder.mDuration.setText(item.getDuration());

        holder.mSelectButton.setVisibility(View.GONE);

        //

        if (item.isBookmark()) {

            holder.mBookmarkButton.setImageResource(R.drawable.ic_bookmark);

        } else {

            holder.mBookmarkButton.setImageResource(R.drawable.ic_bookmark_2);
        }

        holder.mBookmarkButton.setVisibility(View.GONE);

        //

        if (item.isPlaying()) {

            if (isSelectable) {

                holder.mSelectButton.setVisibility(View.VISIBLE);
            }

            holder.mStatusImage.setImageResource(R.drawable.ic_pause);

        } else {

            if (isSelectable) {

                holder.mSelectButton.setVisibility(View.GONE);
            }

            holder.mStatusImage.setImageResource(R.drawable.ic_play_2);
        }

        // Image

        if (item.getImgUrl() != null && item.getImgUrl().length() > 0) {

            final ImageView img = holder.mSoundImage;
            final ProgressBar progressView = holder.mProgressBar;

            Picasso.with(ctx)
                    .load(item.getImgUrl())
                    .into(holder.mSoundImage, new Callback() {

                        @Override
                        public void onSuccess() {

                            progressView.setVisibility(View.GONE);
                            img.setVisibility(View.VISIBLE);
                        }

                        @Override
                        public void onError() {

                            progressView.setVisibility(View.GONE);
                            img.setVisibility(View.VISIBLE);
                            img.setImageResource(R.drawable.def_photo);
                        }
                    });

        } else {

            holder.mProgressBar.setVisibility(View.GONE);
            holder.mSoundImage.setVisibility(View.VISIBLE);

            holder.mSoundImage.setImageResource(R.drawable.def_photo);
        }

        //

        holder.mBookmarkButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mOnItemClickListener.onItemClick(view, item, position, 2);
            }
        });

        holder.mSelectButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mOnItemClickListener.onItemClick(view, item, position, 1);
            }
        });

        holder.mParent.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mOnItemClickListener.onItemClick(view, item, position, 0);
            }
        });
    }

    @Override
    public int getItemCount() {

        return items.size();
    }
}