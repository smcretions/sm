package com.raccoonsquare.reels;

import android.app.Activity;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.Toolbar;

import com.android.billingclient.api.BillingClient;
import com.android.billingclient.api.BillingClientStateListener;
import com.android.billingclient.api.BillingFlowParams;
import com.android.billingclient.api.BillingResult;
import com.android.billingclient.api.ConsumeParams;
import com.android.billingclient.api.ConsumeResponseListener;
import com.android.billingclient.api.Purchase;
import com.android.billingclient.api.PurchasesUpdatedListener;
import com.android.billingclient.api.SkuDetails;
import com.android.billingclient.api.SkuDetailsParams;
import com.android.billingclient.api.SkuDetailsResponseListener;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.rewarded.RewardedAd;
import com.google.android.gms.ads.rewarded.RewardedAdLoadCallback;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.common.ActivityBase;
import com.raccoonsquare.reels.util.CustomRequest;
import com.stripe.android.PaymentConfiguration;
import com.stripe.android.paymentsheet.PaymentSheet;
import com.stripe.android.paymentsheet.PaymentSheetResult;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import co.paystack.android.Paystack;
import co.paystack.android.PaystackSdk;
import co.paystack.android.Transaction;
import co.paystack.android.model.Card;
import co.paystack.android.model.Charge;


public class BalanceActivity extends ActivityBase {

    Toolbar mToolbar;

    // For Google Play

    private static final String TAG = "ifsoft.inappbilling";            // Here you can write anything you like! For example: obama.white.house.billing
    private static final String TOKEN = "ifsoft.inappbilling";          // Here you can write anything you like! For example: obama.white.house.billing

    static final int ITEM_SKU_1_AMOUNT = 100;          // in usd cents | 1 usd = 100 cents
    static final int ITEM_SKU_2_AMOUNT = 200;          // in usd cents | 2 usd = 200 cents
    static final int ITEM_SKU_3_AMOUNT = 300;          // in usd cents | 3 usd = 300 cents

    Button mBuy1Button, mBuy2Button, mBuy3Button, mBuy4Button;
    TextView mLabelCredits;

    Button mRewardedAdButton;
    Button mStripeButton, mPaystackButton;

    private RewardedAd mRewardedAd;

    private Boolean loading = false;

    private BillingClient mBillingClient;
    private Map<String, SkuDetails> mSkuDetailsMap = new HashMap<>();

    // Stripe

    private PaymentSheet paymentSheet;
    private String paymentClientSecret;
    PaymentSheet.CustomerConfiguration customerConfig;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_balance);

        if (savedInstanceState != null) {

            loading = savedInstanceState.getBoolean("loading");

        } else {

            loading = false;
        }

        mToolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        if (loading) {

            showpDialog();
        }

        mLabelCredits = (TextView) findViewById(R.id.labelCredits);

        mBuy1Button = (Button) findViewById(R.id.iap1_google_btn);
        mBuy2Button = (Button) findViewById(R.id.iap2_google_btn);
        mBuy3Button = (Button) findViewById(R.id.iap3_google_btn);
        mBuy4Button = (Button) findViewById(R.id.iap4_google_btn);      // For test Google Pay Button

        mRewardedAdButton = (Button) findViewById(R.id.rewarded_ad_btn);

        if (!App.getInstance().getAppSettings().getGooglePayTestButton()) {

            mBuy4Button.setVisibility(View.GONE);
        }

        mBuy1Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                launchBilling(ITEM_SKU_1);
            }
        });

        mBuy2Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                launchBilling(ITEM_SKU_2);
            }
        });

        mBuy3Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                launchBilling(ITEM_SKU_3);
            }
        });

        mBuy4Button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                launchBilling(ITEM_SKU_4);
            }
        });

        mRewardedAdButton.setVisibility(View.GONE);
        mRewardedAdButton.setEnabled(false);

        if (App.getInstance().getAppSettings().getRewardedAdsFeature() && App.getInstance().isMobileAdsInitializeCalled.get()) {

            mRewardedAdButton.setVisibility(View.VISIBLE);
            loadRewardedVideoAd();
        }

        mRewardedAdButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (mRewardedAd != null) {

                    Activity activityContext = BalanceActivity.this;

                    mRewardedAd.show(activityContext, rewardItem -> {

                        // Handle the reward.
                        Log.d("TAG", "The user earned the reward.");

                        int rewardAmount = rewardItem.getAmount();
                        String rewardType = rewardItem.getType();

                        Log.d("Rewarded Video", "onRewarded");

                        Toast.makeText(BalanceActivity.this, getString(R.string.msg_success_rewarded), Toast.LENGTH_SHORT).show();

                        mRewardedAdButton.setEnabled(false);

                        App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() + App.getInstance().getAppSettings().getRewardedAdsBonus());
                        payment(rewardItem.getAmount(), 0, PT_ADMOB_REWARDED_ADS,false);
                    });

                } else {

                    Log.d("TAG", "The rewarded ad wasn't ready yet.");
                }
            }
        });

        // Payments

        mStripeButton = (Button) findViewById(R.id.stripe_btn);
        mPaystackButton = (Button) findViewById(R.id.paystack_btn);

        mStripeButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                loading = true;

                showpDialog();

                CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_PAYMENTS_STRIPE, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {

                                try {

                                    if (response.has("customer")) {

                                        customerConfig = new PaymentSheet.CustomerConfiguration(
                                                response.getString("customer"),
                                                response.getString("ephemeralKey")
                                        );
                                    }

                                    if (response.has("paymentIntent")) {

                                        paymentClientSecret = response.getString("paymentIntent");
                                        PaymentConfiguration.init(getApplicationContext(), response.getString("publishableKey"));
                                    }

                                } catch (JSONException e) {

                                    e.printStackTrace();

                                } finally {

                                    loading = false;

                                    hidepDialog();

                                    presentPaymentSheet();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        loading = false;

                        hidepDialog();

                        //
                    }
                }) {

                    @Override
                    protected Map<String, String> getParams() {

                        Map<String, String> params = new HashMap<String, String>();
                        params.put("clientId", CLIENT_ID);
                        params.put("accountId", Long.toString(App.getInstance().getId()));
                        params.put("accessToken", App.getInstance().getAccessToken());

                        return params;
                    }
                };

                App.getInstance().addToRequestQueue(jsonReq);
            }
        });

        mPaystackButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                getPayStackDialog();
            }
        });

        mStripeButton.setText(String.format(getString(R.string.label_payments_string_format), App.getInstance().getPaymentsSettings().getStripeCount(), App.getInstance().getPaymentsSettings().getStripeCurrency(), App.getInstance().getPaymentsSettings().getStripePrice() / 100, getString(R.string.label_stripe)));
        mPaystackButton.setText(String.format(getString(R.string.label_payments_string_format), App.getInstance().getPaymentsSettings().getPaystackCount(), App.getInstance().getPaymentsSettings().getPaystackCurrency(), App.getInstance().getPaymentsSettings().getPaystackPrice() / 100, getString(R.string.label_paystack)));

        if (App.getInstance().getPaymentsSettings().getStripeEnabled() == 0) {

            mStripeButton.setVisibility(View.GONE);

        } else {

            paymentSheet = new PaymentSheet(this, this::onPaymentSheetResult);
        }

        if (App.getInstance().getPaymentsSettings().getPaystackEnabled() == 0) {

            mPaystackButton.setVisibility(View.GONE);
        }

        //

        update();

        setupBilling();
    }

    private void presentPaymentSheet() {

        final PaymentSheet.Configuration configuration = new PaymentSheet.Configuration.Builder(getString(R.string.app_name)).customer(customerConfig)
                // Set `allowsDelayedPaymentMethods` to true if your business handles payment methods
                // delayed notification payment methods like US bank accounts.
                .allowsDelayedPaymentMethods(false)
                .build();

        paymentSheet.presentWithPaymentIntent(paymentClientSecret, configuration);
    }

    private void onPaymentSheetResult(final PaymentSheetResult paymentSheetResult) {

        if (paymentSheetResult instanceof PaymentSheetResult.Canceled) {

            Log.d(TAG, "Canceled");

        } else if (paymentSheetResult instanceof PaymentSheetResult.Failed) {

            Log.e(TAG, "Got error: ", ((PaymentSheetResult.Failed) paymentSheetResult).getError());

        } else if (paymentSheetResult instanceof PaymentSheetResult.Completed) {

            // Display for example, an order confirmation screen

            Log.d(TAG, "Completed");

            App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() + App.getInstance().getPaymentsSettings().getStripeCount());
            payment(App.getInstance().getPaymentsSettings().getStripeCount(), App.getInstance().getPaymentsSettings().getStripePrice() / 100, PT_STRIPE,true);
        }
    }

    public void getPayStackDialog() {

        AlertDialog.Builder b = new AlertDialog.Builder(this);
        b.setTitle(getText(R.string.label_paystack));

        LinearLayout view = (LinearLayout) getLayoutInflater().inflate(R.layout.dialog_paystack, null);

        b.setView(view);

        final EditText mCardNumber = view.findViewById(R.id.card_number);
        final EditText mMonth = view.findViewById(R.id.month);
        final EditText mYear = view.findViewById(R.id.year);
        final EditText mCvv = view.findViewById(R.id.cvc);

        final Button mTestButton = view.findViewById(R.id.paystack_test_btn);
        mTestButton.setVisibility(View.GONE);

        mTestButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mCardNumber.setText("4084084084084081");
                mMonth.setText("10");
                mYear.setText("24");
                mCvv.setText("408");
            }
        });

        //mCardNumber.setText(queryText);

        b.setPositiveButton(getText(R.string.label_payments_make_payment), new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {

                int amount = App.getInstance().getPaymentsSettings().getPaystackPrice();

                //

                int expiryMonth = 10; //any month in the future
                int expiryYear = 24; // any year in the future. '2018' would work also!

                String cardNumber = mCardNumber.getText().toString();

                if (!mMonth.getText().toString().isEmpty()) {

                    expiryMonth = Integer.parseInt(mMonth.getText().toString());
                }

                if (!mYear.getText().toString().isEmpty()) {

                    expiryYear = Integer.parseInt(mYear.getText().toString());
                }

                String cvv = mCvv.getText().toString();

                Card card = new Card(cardNumber, expiryMonth, expiryYear, cvv);

                if (card.isValid()) {

                    // charge card

                    dialog.cancel();

                    paystackPay(card, amount);

                } else {

                    //do something

                    Toast.makeText(BalanceActivity.this, getString(R.string.label_payments_card_not_valid), Toast.LENGTH_SHORT).show();
                }
            }
        });

        b.setNegativeButton(getText(R.string.action_cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.cancel();
            }
        });

        AlertDialog d = b.create();

        d.setCanceledOnTouchOutside(false);
        d.setCancelable(false);
        d.show();
    }

    public void paystackPay(Card card, int amount) {

        loading = true;
        showpDialog();

        Charge charge = new Charge();
        charge.setCard(card); //sets the card to charge
        charge.setAmount(amount);
        charge.setEmail(App.getInstance().getAccount().getPublicEmail());

        PaystackSdk.chargeCard(BalanceActivity.this, charge, new Paystack.TransactionCallback() {
            @Override
            public void onSuccess(Transaction transaction) {

                // This is called only after transaction is deemed successful.
                // Retrieve the transaction, and send its reference to your server
                // for verification.

                loading = false;
                hidepDialog();

                int credits = App.getInstance().getPaymentsSettings().getPaystackCount();

                App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() + credits);
                payment(credits, amount / 100, PT_PAYSTACK,true);
            }

            @Override
            public void beforeValidate(Transaction transaction) {
                // This is called only before requesting OTP.
                // Save reference so you may send to server. If
                // error occurs with OTP, you should still verify on server.

                Toast.makeText(getApplicationContext(), "beforeValidate", Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onError(Throwable error, Transaction transaction) {

                //handle error here

                loading = false;
                hidepDialog();

                Toast.makeText(getApplicationContext(), "onError: " + transaction.toString() + " " + error.getMessage(), Toast.LENGTH_SHORT).show();
                Log.e("Dimon", "onError: " + transaction.toString() + " " + error.getMessage());
            }

        });
    }

    private void setupBilling() {

        mBillingClient = BillingClient.newBuilder(this).enablePendingPurchases().setListener(new PurchasesUpdatedListener() {

            @Override
            public void onPurchasesUpdated(BillingResult billingResult, @Nullable List<Purchase> purchases) {

                if (purchases != null) {

                    if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK && purchases != null) {

                        for (Purchase purchase : purchases) {

                            try {

                                JSONObject obj = new JSONObject(purchase.getOriginalJson());

                                consume(purchase.getPurchaseToken(), purchase.getDeveloperPayload(), obj.getString("productId"));

                                Log.e("Billing", obj.toString());

                            } catch (Throwable t) {

                                Log.e("Billing", "Could not parse malformed JSON: \"" + purchase.toString() + "\"");
                            }
                        }

                    } else if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.USER_CANCELED) {

                        // Handle an error caused by a user cancelling the purchase flow.

                    } else {

                        // Handle any other error codes.
                    }
                }
            }
        }).build();

        mBillingClient.startConnection(new BillingClientStateListener() {
            @Override
            public void onBillingSetupFinished(BillingResult billingResult) {

                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {

                    // The BillingClient is ready. You can query purchases here.

                    querySkuDetails();

                    Log.e("onBillingSetupFinished", "WORKS");
                }
            }

            @Override
            public void onBillingServiceDisconnected() {

                // Try to restart the connection on the next request to
                // Google Play by calling the startConnection() method.

                Log.e("onBillingSetupFinished", "NOT WORKS");
            }
        });
    }

    private void consume(String purchaseToken, String payload, String sku) {

        ConsumeParams consumeParams =
                ConsumeParams.newBuilder()
                        .setPurchaseToken(purchaseToken)
                        .build();

        ConsumeResponseListener listener = new ConsumeResponseListener() {
            @Override
            public void onConsumeResponse(BillingResult billingResult, String outToken) {

                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {

                    // Handle the success of the consume operation.
                    // For example, increase the number of coins inside the user's basket.

                    switch (sku) {

                        case ITEM_SKU_1:

                            App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() + 30);
                            payment(30, ITEM_SKU_1_AMOUNT, PT_GOOGLE_PURCHASE,true);

                            break;

                        case ITEM_SKU_2:

                            App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() + 70);
                            payment(70, ITEM_SKU_2_AMOUNT, PT_GOOGLE_PURCHASE,true);

                            break;

                        case ITEM_SKU_3:

                            App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() + 120);
                            payment(120, ITEM_SKU_3_AMOUNT, PT_GOOGLE_PURCHASE,true);

                            break;

                        case ITEM_SKU_4:

                            Log.e("Payment", "Call");

                            App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() + 100);
                            payment(100, 0, PT_GOOGLE_PURCHASE,true);

                            break;

                        default:

                            break;
                    }
                }
            }
        };

        mBillingClient.consumeAsync(consumeParams, listener);
    }

    private void querySkuDetails() {

        SkuDetailsParams.Builder skuDetailsParamsBuilder = SkuDetailsParams.newBuilder();
        List<String> skuList = new ArrayList<>();
        skuList.add(ITEM_SKU_1);
        skuList.add(ITEM_SKU_2);
        skuList.add(ITEM_SKU_3);

        if (App.getInstance().getAppSettings().getGooglePayTestButton()) {

            skuList.add(ITEM_SKU_4);
        }

        skuDetailsParamsBuilder.setSkusList(skuList).setType(BillingClient.SkuType.INAPP);
        mBillingClient.querySkuDetailsAsync(skuDetailsParamsBuilder.build(), new SkuDetailsResponseListener() {
            @Override
            public void onSkuDetailsResponse(BillingResult billingResult, List<SkuDetails> skuDetailsList) {

                if (billingResult.getResponseCode() == BillingClient.BillingResponseCode.OK) {

                    if (skuDetailsList != null) {

                        for (SkuDetails skuDetails : skuDetailsList) {

                            mSkuDetailsMap.put(skuDetails.getSku(), skuDetails);
                        }
                    }
                }
            }
        });
    }

    public void launchBilling(String skuId) {

        BillingFlowParams billingFlowParams = BillingFlowParams.newBuilder()
                .setSkuDetails(mSkuDetailsMap.get(skuId))
                .build();
        mBillingClient.launchBillingFlow(this, billingFlowParams);
    }

//    private List<Purchase> queryPurchases() {
//        Purchase.PurchasesResult purchasesResult = mBillingClient.queryPurchases(BillingClient.SkuType.INAPP);
//        return purchasesResult.getPurchasesList();
//    }

    public void payment(final int cost, final int amount, final int paymentType, final Boolean showSuccess) {

        loading = true;

        showpDialog();

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_PAYMENTS_NEW, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {

                                if (response.has("balance")) {

                                    App.getInstance().getAccount().setBalance(response.getInt("balance"));
                                }

                                if (showSuccess) {

                                    success();
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            loading = false;

                            hidepDialog();

                            update();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                loading = false;

                hidepDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("clientId", CLIENT_ID);
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("credits", Integer.toString(cost));
                params.put("paymentType", Integer.toString(paymentType));
                params.put("amount", Integer.toString(amount));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
    }


    public void update() {

        mLabelCredits.setText(getString(R.string.label_credits) + " (" + Integer.toString(App.getInstance().getAccount().getBalance()) + ")");
    }

    public void success() {

        Toast.makeText(BalanceActivity.this, getString(R.string.msg_success_purchase), Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("loading", loading);
    }

    @Override
    protected void onStart() {

        super.onStart();

        if (!mBillingClient.isReady()) {

            setupBilling();
        }
    }

    @Override
    protected void onPause() {

        super.onPause();
    }

    @Override
    protected void onDestroy() {

        super.onDestroy();

        hidepDialog();

        mBillingClient.endConnection();
    }

    @Override protected void onResume() {

        super.onResume();

        update();
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.menu_deactivate, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {

            case android.R.id.home: {

                finish();
                return true;
            }

            default: {

                return super.onOptionsItemSelected(item);
            }
        }
    }



    private void loadRewardedVideoAd() {

        mRewardedAdButton.setText(getString(R.string.msg_loading));

        AdRequest adRequest = new AdRequest.Builder().build();

        RewardedAd.load(this, App.getInstance().getAdmobSettings().getRewardedAdUnitId(), adRequest, new RewardedAdLoadCallback() {

            @Override
            public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                // Handle the error.

                Log.d("Rewarded Ad", loadAdError.getMessage());

                mRewardedAd = null;
            }

            @Override
            public void onAdLoaded(@NonNull RewardedAd rewardedAd) {

                mRewardedAd = rewardedAd;

                mRewardedAd.setFullScreenContentCallback(new FullScreenContentCallback() {

                    @Override
                    public void onAdShowedFullScreenContent() {

                        // Called when ad is shown.

                        Log.d("Rewarded Ad", "onAdShowedFullScreenContent");

                        mRewardedAdButton.setEnabled(false);

                        mRewardedAd = null;
                    }

                    @Override
                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                        // Called when ad fails to show.

                        Log.d("Rewarded Ad", "onAdFailedToShowFullScreenContent");

                        mRewardedAdButton.setEnabled(false);

                        loadRewardedVideoAd();
                    }

                    @Override
                    public void onAdDismissedFullScreenContent() {

                        // Called when ad is dismissed.
                        // Don't forget to set the ad reference to null so you
                        // don't show the ad a second time.

                        Log.d("Rewarded Ad", "onAdDismissedFullScreenContent");

                        mRewardedAdButton.setEnabled(false);

                        loadRewardedVideoAd();
                    }
                });

                mRewardedAdButton.setText(getString(R.string.action_view_rewarded_video_ad));
                mRewardedAdButton.setEnabled(true);

                Log.d("Rewarded Ad", "onAdLoaded");
            }
        });
    }
}
