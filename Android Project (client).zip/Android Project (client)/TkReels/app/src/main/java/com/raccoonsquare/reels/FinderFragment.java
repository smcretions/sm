package com.raccoonsquare.reels;

import static android.content.Context.INPUT_METHOD_SERVICE;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.widget.Toolbar;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.google.android.material.tabs.TabLayout;
import com.raccoonsquare.reels.adapter.AdvancedItemListAdapter;
import com.raccoonsquare.reels.adapter.MarketListAdapter;
import com.raccoonsquare.reels.adapter.UsersListAdapter;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Item;
import com.raccoonsquare.reels.model.MarketItem;
import com.raccoonsquare.reels.model.Profile;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.view.LineItemDecoration;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class FinderFragment extends Fragment implements Constants, SwipeRefreshLayout.OnRefreshListener {

    private static final String STATE_LIST = "State Adapter Data";
    private static final String STATE_LIST_2 = "State Adapter Data 2";
    private static final String STATE_LIST_3 = "State Adapter Data 3";

    Toolbar mToolbar;

    private ProgressBar mProgressBar;
    private EditText mSearchBox;
    private RecyclerView mRecyclerView;
    private NestedScrollView mNestedView;
    private ImageButton mClearButton;
    private SwipeRefreshLayout mSwipeRefresh;

    private TabLayout mTabLayout;

    private TextView mStatusMessage;
    private ImageView mStatusImage;

    private ArrayList<Item> itemsList;
    private AdvancedItemListAdapter itemsAdapter;

    private ArrayList<MarketItem> marketList;
    private MarketListAdapter marketAdapter;

    private ArrayList<Profile> usersList;
    private UsersListAdapter usersAdapter;

    private int itemId = 0, itemsCount = 0;
    private int arrayLength = 0;
    private Boolean loadingMore = false;
    private Boolean viewMore = false;
    private Boolean restore = false;

    private String query = "";
    private int tab_position = 0;

    private Boolean inActivity = true;

    public FinderFragment() {

        // Required empty public constructor
    }

    public FinderFragment newInstance(Boolean inActivity) {

        FinderFragment myFragment = new FinderFragment();

        Bundle args = new Bundle();
        args.putBoolean("inActivity", inActivity);
        myFragment.setArguments(args);

        return myFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        //

        setHasOptionsMenu(false);

        //

        if (savedInstanceState != null) {

            itemsList = savedInstanceState.getParcelableArrayList(STATE_LIST);
            itemsAdapter = new AdvancedItemListAdapter(getActivity(), itemsList);

            usersList = savedInstanceState.getParcelableArrayList(STATE_LIST_2);
            usersAdapter = new UsersListAdapter(getActivity(), usersList);

            marketList = savedInstanceState.getParcelableArrayList(STATE_LIST_3);
            marketAdapter = new MarketListAdapter(getActivity(), marketList);

            tab_position = savedInstanceState.getInt("tab_position");
            restore = savedInstanceState.getBoolean("restore");
            itemId = savedInstanceState.getInt("itemId");
            itemsCount = savedInstanceState.getInt("itemsCount");
            query = savedInstanceState.getString("query");

            viewMore = savedInstanceState.getBoolean("viewMore");

        } else {

            itemsList = new ArrayList<>();
            itemsAdapter = new AdvancedItemListAdapter(getActivity(), itemsList);

            usersList = new ArrayList<>();
            usersAdapter = new UsersListAdapter(getActivity(), usersList);

            marketList = new ArrayList<>();
            marketAdapter = new MarketListAdapter(getActivity(), marketList);

            tab_position = 0;
            restore = false;
            itemId = 0;
            itemsCount = 0;
            query = "";

            Intent i = getActivity().getIntent();
            tab_position = i.getIntExtra("tab_position", 0);
            query = i.getStringExtra("query");
        }

        //

        if (query == null) {

            query = "";

        } else {

            query = query.replace("#", "");
        }

        if (getArguments() != null) {

            inActivity = getArguments().getBoolean("inActivity", true);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_finder, container, false);

        //

        mToolbar = (Toolbar) rootView.findViewById(R.id.toolbar);

        if (inActivity) {

            ((FinderActivity) getActivity()).setSupportActionBar(mToolbar);
            ((FinderActivity) getActivity()).getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            ((FinderActivity) getActivity()).getSupportActionBar().setDisplayShowHomeEnabled(true);
        }

        //

        mSwipeRefresh = (SwipeRefreshLayout) rootView.findViewById(R.id.refresh_layout);
        mSwipeRefresh.setOnRefreshListener(this);

        // Progress Bar

        mProgressBar = (ProgressBar) rootView.findViewById(R.id.progressBar);

        // Search Box

        mSearchBox = (EditText) rootView.findViewById(R.id.search_box);

        if (query != null && query.length() != 0) {

            mSearchBox.setText(query);
        }

        // RecyclerView

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);
        mNestedView = (NestedScrollView) rootView.findViewById(R.id.nested_view);

        // Clear Button

        mClearButton = (ImageButton) rootView.findViewById(R.id.button_clear);
        mClearButton.setVisibility(View.GONE);

        updateClearButton(query);

        // Tabs

        mTabLayout = (TabLayout) rootView.findViewById(R.id.tab_layout);

        //

        mStatusImage = (ImageView) rootView.findViewById(R.id.search_status_img);
        mStatusMessage = (TextView) rootView.findViewById(R.id.search_status_message);

        initComponent();
        updateView();

        if (!restore) {

            startSearch();
        }

        return rootView;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("viewMore", viewMore);

        outState.putInt("tab_position", tab_position);
        outState.putBoolean("restore", true);
        outState.putInt("itemId", itemId);
        outState.putInt("itemsCount", itemsCount);
        outState.putString("query", query);

        outState.putParcelableArrayList(STATE_LIST, itemsList);
        outState.putParcelableArrayList(STATE_LIST_2, usersList);
        outState.putParcelableArrayList(STATE_LIST_3, marketList);
    }

    @Override
    public void onRefresh() {

        if (App.getInstance().isConnected()) {

            itemId = 0;
            startSearch();

        } else {

            mSwipeRefresh.setRefreshing(false);
        }
    }

    private void updateView() {

        //
    }

    private void initComponent() {

        //mSearchBox.setText(query);
        mSearchBox.addTextChangedListener(textWatcher);
        mSearchBox.setImeOptions(EditorInfo.IME_FLAG_NO_EXTRACT_UI | EditorInfo.IME_ACTION_SEARCH);
        hideKeyboard();

        mSearchBox.setOnFocusChangeListener(new View.OnFocusChangeListener() {

            @Override
            public void onFocusChange(View v, boolean hasFocus) {

                if (hasFocus) {

                    //got focus

                    mSearchBox.setCursorVisible(true);

                } else {

                    hideKeyboard();
                }
            }
        });

        // Tabs

        mTabLayout.addTab(mTabLayout.newTab().setText(getString(R.string.finder_tab_videos)));
        mTabLayout.addTab(mTabLayout.newTab().setText(getString(R.string.finder_tab_users)));
        mTabLayout.addTab(mTabLayout.newTab().setText(getString(R.string.finder_tab_hashtag)));

        if (App.getInstance().getAppSettings().getMarketFeature()) {

            mTabLayout.addTab(mTabLayout.newTab().setText(getString(R.string.finder_tab_market)));
        }

        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                tab_position = tab.getPosition();

                final Handler handler = new Handler();
                handler.postDelayed(new Runnable() {
                    @Override
                    public void run() {

                        startSearch();
                    }
                }, 300);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

                //updateInactiveTab(tab.getPosition());
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

                // animateTab(tab.getPosition());
            }
        });

        mTabLayout.selectTab(mTabLayout.getTabAt(tab_position));

        // Recycler View

        mRecyclerView.setNestedScrollingEnabled(false);

        mNestedView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {

            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY < oldScrollY) { // up


                }

                if (scrollY > oldScrollY) { // down


                }

                if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {

                    if (!loadingMore && (viewMore) && !(mSwipeRefresh.isRefreshing())) {

                        mSwipeRefresh.setRefreshing(true);

                        loadingMore = true;

                        startSearch();
                    }
                }
            }
        });

        marketAdapter.setOnItemClickListener(new MarketListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, MarketItem item, int position) {

                Intent intent = new Intent(getActivity(), MarketViewItemActivity.class);
                intent.putExtra("itemId", item.getId());
                intent.putExtra("itemObj", (Parcelable) item);
                startActivity(intent);
            }
        });

        usersAdapter.setOnItemClickListener(new UsersListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, Profile item, int position) {

                Intent intent = new Intent(getActivity(), ProfileActivity.class);
                intent.putExtra("profileId", item.getId());
                startActivity(intent);
            }
        });

        itemsAdapter.setOnItemClickListener(new AdvancedItemListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, Item obj, int position) {

                App.getInstance().getHomeItemsList().clear();
                App.getInstance().setHomeItemsList((ArrayList<Item>)itemsList.clone());

                Intent intent = new Intent(getActivity(), HomeActivity.class);
                intent.putExtra("position", position);
                startActivity(intent);
            }
        });

        mClearButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mSearchBox.setText("");

                updateClearButton("");

                startSearch();
            }
        });

        mSearchBox.setOnEditorActionListener(new TextView.OnEditorActionListener() {

            public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {

                if (actionId == EditorInfo.IME_ACTION_SEARCH) {

                    startSearch();

                    hideKeyboard();

                    return true;
                }
                return false;
            }
        });
    }

    private void startSearch() {

        query = mSearchBox.getText().toString().trim();

        if (!query.equals("")) {

            query = query.replace("#", "");
        }

        if (!loadingMore) {

            // Delete all separators

            while (mRecyclerView.getItemDecorationCount() > 0) {

                mRecyclerView.removeItemDecorationAt(0);
            }

            //

            itemsCount = 0;
            itemId = 0;

            showStatusLoadingMessage();
        }

        switch (tab_position) {

            case 0: {

                // Videos

                if (!loadingMore) {

                    mRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
                    mRecyclerView.setItemAnimator(new DefaultItemAnimator());
                    mRecyclerView.setAdapter(itemsAdapter);
                }

                findVideos();

                break;
            }

            case 1: {

                // Users

                if (!loadingMore) {

                    mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
                    mRecyclerView.addItemDecoration(new LineItemDecoration(getActivity(), LinearLayout.VERTICAL));
                    mRecyclerView.setItemAnimator(new DefaultItemAnimator());
                    mRecyclerView.setAdapter(usersAdapter);
                }

                findUsers();

                break;
            }

            case 2: {

                // Hashtags

                if (!loadingMore) {

                    mRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
                    mRecyclerView.setItemAnimator(new DefaultItemAnimator());
                    mRecyclerView.setAdapter(itemsAdapter);
                }

                findHashtags();

                break;
            }

            default: {

                // Market

                if (!loadingMore) {

                    mRecyclerView.setLayoutManager(new GridLayoutManager(getActivity(), 2));
                    mRecyclerView.setItemAnimator(new DefaultItemAnimator());
                    mRecyclerView.setAdapter(marketAdapter);
                }

                findMarket();

                break;
            }
        }
    }

    public void findVideos() {

        mSwipeRefresh.setRefreshing(true);

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ITEMS_SEARCH, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "FinderFragment Not Added to Activity");

                            return;
                        }

                        if (!loadingMore) {

                            itemsList.clear();
                            itemsAdapter.notifyDataSetChanged();
                        }

                        try {

                            arrayLength = 0;

                            if (!response.getBoolean("error")) {

                                itemId = response.getInt("itemId");

                                if (response.has("items")) {

                                    JSONArray itemsArray = response.getJSONArray("items");

                                    arrayLength = itemsArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < itemsArray.length(); i++) {

                                            JSONObject itemObj = (JSONObject) itemsArray.get(i);
                                            Item item = new Item(itemObj);
                                            itemsList.add(item);

                                            itemsAdapter.notifyItemChanged(itemsList.size());
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            loadingComplete();

                            Log.d("findVideos success", response.toString());
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "FinderFragment Not Added to Activity");

                    return;
                }

                loadingComplete();

                Log.e("STREAM error", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());

                params.put("itemId", Integer.toString(itemId));
                params.put("language", App.getInstance().getLanguage());

                params.put("sortType", Integer.toString(0));
                params.put("itemType", Integer.toString(0));

                params.put("keyword", query);

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void findHashtags() {

        mSwipeRefresh.setRefreshing(true);

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_HASHTAGS_GET, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "FinderFragment Not Added to Activity");

                            return;
                        }

                        if (!loadingMore) {

                            itemsList.clear();
                            itemsAdapter.notifyDataSetChanged();
                        }

                        try {

                            arrayLength = 0;

                            if (!response.getBoolean("error")) {

                                itemId = response.getInt("itemId");
                                query = response.getString("query");

                                if (response.has("items")) {

                                    JSONArray itemsArray = response.getJSONArray("items");

                                    arrayLength = itemsArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < itemsArray.length(); i++) {

                                            JSONObject itemObj = (JSONObject) itemsArray.get(i);

                                            Item item = new Item(itemObj);
                                            item.setAd(0);
                                            itemsList.add(item);

                                            itemsAdapter.notifyItemChanged(itemsList.size());
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "FinderFragment Not Added to Activity");

                    return;
                }

                loadingComplete();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("itemId", Long.toString(itemId));
                params.put("language", "en");
                params.put("hashtag", query);

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void findUsers() {

        mSwipeRefresh.setRefreshing(true);

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_USERS_SEARCH, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "FinderFragment Not Added to Activity");

                            return;
                        }

                        try {

                            if (!loadingMore) {

                                usersList.clear();
                                usersAdapter.notifyDataSetChanged();
                            }

                            arrayLength = 0;

                            if (!response.getBoolean("error")) {

                                itemsCount = response.getInt("itemCount");
                                itemId = response.getInt("itemId");

                                if (response.has("items")) {

                                    JSONArray usersArray = response.getJSONArray("items");

                                    arrayLength = usersArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < usersArray.length(); i++) {

                                            JSONObject profileObj = (JSONObject) usersArray.get(i);
                                            Profile profile = new Profile(profileObj);
                                            usersList.add(profile);

                                            usersAdapter.notifyItemChanged(usersList.size());
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "FinderFragment Not Added to Activity");

                    return;
                }

                loadingComplete();

                Log.e("FinderFragment findUsers()", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("query", query);
                params.put("userId", Integer.toString(itemId));
                params.put("gender", Integer.toString(-1));
                params.put("online", Integer.toString(-1));
                params.put("photo", Integer.toString(-1));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void findMarket() {

        mSwipeRefresh.setRefreshing(true);

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_MARKET_SEARCH, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "FinderFragment Not Added to Activity");

                            return;
                        }

                        try {

                            if (!loadingMore) {

                                marketList.clear();
                                marketAdapter.notifyDataSetChanged();
                            }

                            arrayLength = 0;

                            if (!response.getBoolean("error")) {

                                itemsCount = response.getInt("itemCount");
                                itemId = response.getInt("itemId");

                                if (response.has("items")) {

                                    JSONArray marketItemsArray = response.getJSONArray("items");

                                    arrayLength = marketItemsArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < marketItemsArray.length(); i++) {

                                            JSONObject marketItemObj = (JSONObject) marketItemsArray.get(i);
                                            MarketItem mMarketItem = new MarketItem(marketItemObj);
                                            marketList.add(mMarketItem);

                                            marketAdapter.notifyItemChanged(marketList.size());
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "FinderFragment Not Added to Activity");

                    return;
                }

                loadingComplete();
                Toast.makeText(getActivity(), getString(R.string.error_data_loading), Toast.LENGTH_LONG).show();

                Log.e("FinderFragment findMarket()", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("query", query);
                params.put("itemId", Integer.toString(itemId));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void loadingComplete() {

        if (arrayLength == LIST_ITEMS) {

            viewMore = true;

        } else {

            viewMore = false;
        }

        loadingMore = false;

        mSwipeRefresh.setRefreshing(false);

        if (mRecyclerView.getAdapter().getItemCount() == 0) {

            showStatusNoResultsMessage();
            itemsCount = 0;

        } else {

            hideKeyboard();
            hideStatusSearchMessage();
        }

        updateView();
    }

    private void updateClearButton(String s) {

        if (s.trim().length() == 0) {

            mClearButton.setVisibility(View.GONE);

        } else {

            mClearButton.setVisibility(View.VISIBLE);
        }
    }

    private void hideKeyboard() {

        InputMethodManager imm = (InputMethodManager) getActivity().getSystemService(INPUT_METHOD_SERVICE);
        imm.hideSoftInputFromWindow(mSearchBox.getWindowToken(), 0);

        mSearchBox.setCursorVisible(false);
        mSearchBox.clearFocus();
    }

    private void hideStatusSearchMessage() {

        mStatusImage.setVisibility(View.GONE);
        mStatusMessage.setVisibility(View.GONE);
        mProgressBar.setVisibility(View.GONE);
    }

    private void showStatusNoResultsMessage() {

        mStatusImage.setImageResource(R.drawable.ic_search);

        if (query != null && query.length() != 0) {

            mStatusMessage.setText(R.string.finder_noresults_message);

        } else {

            mStatusMessage.setText(R.string.finder_search_message);
        }


        mStatusImage.setVisibility(View.VISIBLE);
        mStatusMessage.setVisibility(View.VISIBLE);

        mProgressBar.setVisibility(View.GONE);
    }

    private void showStatusLoadingMessage() {

        mStatusImage.setVisibility(View.GONE);
        mStatusMessage.setVisibility(View.GONE);

        mProgressBar.setVisibility(View.VISIBLE);
    }

    TextWatcher textWatcher = new TextWatcher() {

        @Override
        public void onTextChanged(CharSequence c, int i, int i1, int i2) {

            updateClearButton(c.toString());
        }

        @Override
        public void beforeTextChanged(CharSequence c, int i, int i1, int i2) {
        }

        @Override
        public void afterTextChanged(Editable editable) {
        }
    };

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}