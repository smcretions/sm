package com.raccoonsquare.reels.app;

import android.app.Activity;
import android.app.Application;
import android.content.Context;
import android.content.ContextWrapper;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Configuration;
import android.content.res.Resources;
import android.location.Address;
import android.location.Geocoder;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;

import androidx.annotation.NonNull;

import com.aghajari.emojiview.AXEmojiManager;
import com.aghajari.emojiview.googleprovider.AXGoogleEmojiProvider;
import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.android.volley.toolbox.Volley;
import com.raccoonsquare.reels.model.Item;
import com.facebook.FacebookSdk;
import com.google.android.gms.ads.AdError;
import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.FullScreenContentCallback;
import com.google.android.gms.ads.LoadAdError;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.interstitial.InterstitialAd;
import com.google.android.gms.ads.interstitial.InterstitialAdLoadCallback;
import com.google.android.gms.security.ProviderInstaller;
import com.google.firebase.FirebaseApp;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.concurrent.atomic.AtomicBoolean;

import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.model.BaseGift;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Feeling;
import com.raccoonsquare.reels.model.Profile;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.util.DBManager;
import com.raccoonsquare.reels.util.LruBitmapCache;

import co.paystack.android.PaystackSdk;

public class App extends Application implements Constants {

	public static final String TAG = App.class.getSimpleName();

    private DBManager dbManager;

    private PaymentsSettings mPaymentsSettings;
    private AgoraSettings mAgoraSettings;
    private AppSettings mAppSettings;
    private AdmobAdSettings mAdmobSettings;
    private InterstitialAdSettings mInterstitialAdSettings;
    private Tooltips mTooltips;

	private RequestQueue mRequestQueue;
	private ImageLoader mImageLoader;

	private static App mInstance;

    private ArrayList<Feeling> feelingsList;
    private ArrayList<BaseGift> giftsList;

    private List<Map<String, String>> languages = new ArrayList<>();;

    private SharedPreferences sharedPref;

    private String language = "en";

    private Profile account;

    private long id = 0;
    private String accessToken = "", fcmToken = "";
    private int allowLikesGCM, allowCommentsGCM, allowFollowersGCM, allowGiftsGCM, allowMessagesGCM, allowCommentReplyGCM, errorCode, currentChatId = 0, notificationsCount = 0, messagesCount = 0, guestsCount = 0, newFriendsCount = 0;
    private int nightMode = 0;
    private int feedMode = 0;
    private long hidden_item_id = 0;

    private File directory;

    private InterstitialAd mInterstitialAd;

    private String selectedVideoPath = "";
    private long soundId = 0;
    private String soundUrl = "";

    // Home
    private ArrayList<Item> homeItemsList;
    private long home_current_item_id = 0;
    private int home_current_item_comments_cnt = 0;

    //

    public final AtomicBoolean isMobileAdsInitializeCalled = new AtomicBoolean(false);

    //

	@Override
	public void onCreate() {

		super.onCreate();
        mInstance = this;

        // Emoji

        AXEmojiManager.install(this, new AXGoogleEmojiProvider(this));

        //

        FirebaseApp.initializeApp(this);

        //

//        MobileAds.initialize(this, initializationStatus -> { });

//        RequestConfiguration configuration = new RequestConfiguration.Builder().setTestDeviceIds(Arrays.asList("C65CE9666ADE6113321CF9B5456E9A72", "1BEFC162BE2C7E726B683C534016BF79")).build();
//        MobileAds.setRequestConfiguration(configuration);

        // Facebook

        //FacebookSdk.setApplicationId(getString(R.string.facebook_app_id));
        //FacebookSdk.setClientToken(getString(R.string.facebook_client_token));

        //FacebookSdk.fullyInitialize();


        //

        ContextWrapper contextWrapper = new ContextWrapper(getApplicationContext());
        this.setDirectory(contextWrapper.getDir(getFilesDir().getName(), Context.MODE_PRIVATE));

        // Delete files from tmp folder

//        if (this.getDirectory().exists() && this.getDirectory().isDirectory()) {
//
//            String[] children = this.getDirectory().list();
//
//            for (String child : children) {
//
//                new File(this.getDirectory(), child).delete();
//            }
//        }

        //

        sharedPref = this.getSharedPreferences(getString(R.string.settings_file), Context.MODE_PRIVATE);

        // Database

        this.dbManager = new DBManager(this);
        this.dbManager.open();

        // App Global Settings from server

        mAppSettings = new AppSettings();

        // Ads

        mInterstitialAdSettings = new InterstitialAdSettings();
        mAdmobSettings = new AdmobAdSettings();

        // Payments

        mPaymentsSettings = new PaymentsSettings();

        // Agora

        mAgoraSettings = new AgoraSettings();

        // Get Tooltips settings

        mTooltips = new Tooltips();
        this.readTooltipsSettings();

        // New account model

        this.account = new Profile();

        // Read account data

        this.readData();

        //

        homeItemsList = new ArrayList<Item>();

        //

        this.getSettings();

        // Get app languages

        initLanguages();

        // Set App language by locale

        setLocale(getLanguage());

        if (Build.VERSION.SDK_INT <= Build.VERSION_CODES.KITKAT) {


            try {

                ProviderInstaller.installIfNeeded(this);

            } catch (Exception e) {

                e.getMessage();
            }
        }
	}

    public void initializeMobileAdsSdk() {

        Log.e(TAG, "initializeMobileAdsSdk");

        if (isMobileAdsInitializeCalled.get()) {

            return;
        }

        isMobileAdsInitializeCalled.set(true);

        Log.e(TAG, "init initializeMobileAdsSdk");

        MobileAds.initialize(this, initializationStatus -> { });
    }

    private void initLanguages() {

        Map<String, String> map = new HashMap<String, String>();

        map.put("lang_id", "en");
        map.put("lang_name", getString(R.string.language_default));

        this.languages.add(map);

        DisplayMetrics metrics = new DisplayMetrics();

        Resources r = getResources();
        Configuration c = r.getConfiguration();
        String[] loc = r.getAssets().getLocales();

        for (String s : loc) {

            String sz_lang_id = "id"; // id and in the same for indonesian language. id must be deleted from list

            c.locale = new Locale(s);
            Resources res = new Resources(getAssets(), metrics, c);
            String s1 = res.getString(R.string.app_lang_code);

            String language = c.locale.getDisplayLanguage();

            c.locale = new Locale("");
            Resources res2 = new Resources(getAssets(), metrics, c);
            String s2 = res2.getString(R.string.app_lang_code);

            if (!s1.equals(s2) && !s.equals(sz_lang_id)) {

                map = new HashMap<String, String>();

                map.put("lang_id", s);
                map.put("lang_name", language);

                this.languages.add(map);
            }
        }
    }

    public List<Map<String, String>> getLanguages() {

        return this.languages;
    }

    public void setLocale(String lang) {

        Locale myLocale;

        if (lang.length() == 0) {

            myLocale = new Locale("");

        } else {

            myLocale = new Locale(lang);
        }

        Resources res = getBaseContext().getResources();
        DisplayMetrics dm = res.getDisplayMetrics();
        Configuration conf = new Configuration();

        conf.setLocale(myLocale);
        conf.setLayoutDirection(myLocale);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {

            getApplicationContext().createConfigurationContext(conf);

        } else {

            res.updateConfiguration(conf, dm);
        }
    }

    public void setLanguage(String language) {

        this.language = language;
    }

    public String getLanguage() {

        if (this.language == null) {

            this.setLanguage("en");
        }

        return this.language;
    }

    public String getLanguageNameByCode(String langCode) {

        String language = getString(R.string.language_default);

        for (int i = 1; i < App.getInstance().getLanguages().size(); i++) {

            if (App.getInstance().getLanguages().get(i).get("lang_id").equals(langCode)) {

                language = App.getInstance().getLanguages().get(i).get("lang_name");
            }
        }

        return language;
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {

        super.onConfigurationChanged(newConfig);

        setLocale(getLanguage());
    }

    public void setLocation() {

        if (App.getInstance().isConnected() && App.getInstance().getId() != 0) {

            CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_SET_GEO_LOCATION, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {

                                if (!response.getBoolean("error")) {

                                    if (response.has("lat")) {

                                        getAccount().setLat(response.getDouble("lat"));
                                    }

                                    if (response.has("lng")) {

                                        getAccount().setLng(response.getDouble("lng"));
                                    }
                                }

                            } catch (JSONException e) {

                                e.printStackTrace();

                            } finally {

                                Log.d("Set GEO Success", response.toString());

                                App.getInstance().saveData();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Log.d("Set GEO Error", error.toString());
                }
            }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("accountId", Long.toString(App.getInstance().getId()));
                    params.put("accessToken", App.getInstance().getAccessToken());
                    params.put("lat", Double.toString(App.getInstance().getAccount().getLat()));
                    params.put("lng", Double.toString(App.getInstance().getAccount().getLng()));

                    return params;
                }
            };

            App.getInstance().addToRequestQueue(jsonReq);
        }
    }

    public void getAddress(Double lat, Double lng) {

        Geocoder geocoder;
        List<Address> addresses;
        geocoder = new Geocoder(getApplicationContext(), Locale.US);

        try {

            addresses = geocoder.getFromLocation(lat, lng, 1);

            if (addresses != null && addresses.size() > 0) {

                App.getInstance().getAccount().setCity(addresses.get(0).getLocality());
                App.getInstance().getAccount().setArea(addresses.get(0).getAdminArea());
                App.getInstance().getAccount().setCountry(addresses.get(0).getCountryName());

                if (App.getInstance().getAccount().getCity().length() == 0) {

                    App.getInstance().getAccount().setCity("Unknown");
                }

                if (App.getInstance().getAccount().getArea().length() == 0) {

                    App.getInstance().getAccount().setArea("Unknown");
                }

                if (App.getInstance().getAccount().getCountry().length() == 0) {

                    App.getInstance().getAccount().setCountry("Unknown");
                }

            } else {

                App.getInstance().getAccount().setCity("Unknown");
                App.getInstance().getAccount().setArea("Unknown");
                App.getInstance().getAccount().setCountry("Unknown");
            }

        } catch (IOException e) {

            e.printStackTrace();
        }
    }

    public void showInterstitialAd(Activity activity) {

        if (!isMobileAdsInitializeCalled.get()) {

            return;
        }

        AdRequest adRequest = new AdRequest.Builder().build();

        InterstitialAd.load(this, App.getInstance().getAdmobSettings().getInterstitialAdUnitId(), adRequest,

                new InterstitialAdLoadCallback() {

                    @Override
                    public void onAdLoaded(@NonNull InterstitialAd interstitialAd) {

                        // The mInterstitialAd reference will be null until
                        // an ad is loaded.
                        mInterstitialAd = interstitialAd;

                        Log.i("admob", "onAdLoaded");

                        if (mInterstitialAd != null) {

                            mInterstitialAd.show(activity);
                        }

                        interstitialAd.setFullScreenContentCallback(
                                new FullScreenContentCallback() {

                                    @Override
                                    public void onAdDismissedFullScreenContent() {

                                        // Called when fullscreen content is dismissed.
                                        // Make sure to set your reference to null so you don't
                                        // show it a second time.

                                        mInterstitialAd = null;

                                        Log.d("admob", "The ad was dismissed.");
                                    }

                                    @Override
                                    public void onAdFailedToShowFullScreenContent(AdError adError) {

                                        // Called when fullscreen content failed to show.
                                        // Make sure to set your reference to null so you don't
                                        // show it a second time.

                                        mInterstitialAd = null;

                                        Log.d("admob", "The ad failed to show.");
                                    }

                                    @Override
                                    public void onAdShowedFullScreenContent() {

                                        // Called when fullscreen content is shown.

                                        Log.d("admob", "The ad was shown.");
                                    }
                                });
                    }

                    @Override
                    public void onAdFailedToLoad(@NonNull LoadAdError loadAdError) {

                        // Handle the error

                        Log.i("admob", loadAdError.getMessage());

                        mInterstitialAd = null;

                        String error = String.format("domain: %s, code: %d, message: %s", loadAdError.getDomain(), loadAdError.getCode(), loadAdError.getMessage());

                        Log.e("admob", "onAdFailedToLoad() with error: " + error);
                    }
                });
    }
    
    public boolean isConnected() {
    	
    	ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
    	
    	NetworkInfo netInfo = cm.getActiveNetworkInfo();

    	if (netInfo != null && netInfo.isConnectedOrConnecting()) {

    		return true;
    	}

    	return false;
    }

    public void logout() {

        if (App.getInstance().isConnected() && App.getInstance().getId() != 0) {

            CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_LOGOUT, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {

                                if (!response.getBoolean("error")) {



                                }

                            } catch (JSONException e) {

                                e.printStackTrace();

                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    App.getInstance().removeData();
                    App.getInstance().readData();
                }
            }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("clientId", CLIENT_ID);
                    params.put("accountId", Long.toString(App.getInstance().getId()));
                    params.put("accessToken", App.getInstance().getAccessToken());

                    return params;
                }
            };

            App.getInstance().addToRequestQueue(jsonReq);

        }

        App.getInstance().removeData();
        App.getInstance().readData();
    }

    public void getSettings() {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_GET_SETTINGS, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {

                                // Read global app settings

                                App.getInstance().getAppSettings().read_from_json(response);

                                // Read Interstitial ads settings

                                App.getInstance().getInterstitialAdSettings().read_from_json(response);

                                // Read Admob ads settings

                                App.getInstance().getAdmobSettings().read_from_json(response);

                                // Read Agora settings

                                App.getInstance().getAgoraSettings().read_from_json(response);

                                // Read Payments settings

                                App.getInstance().getPaymentsSettings().read_from_json(response);

                                //

                                if (response.has("messagesCount")) {

                                    App.getInstance().setMessagesCount(response.getInt("messagesCount"));
                                }

                                if (response.has("notificationsCount")) {

                                    App.getInstance().setNotificationsCount(response.getInt("notificationsCount"));
                                }

                                if (response.has("guestsCount")) {

                                    App.getInstance().setGuestsCount(response.getInt("guestsCount"));
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("App getSettings()", response.toString());

                            App.getInstance().saveData();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.e("App getSettings()", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("clientId", CLIENT_ID);
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("lat", Double.toString(App.getInstance().getAccount().getLat()));
                params.put("lng", Double.toString(App.getInstance().getAccount().getLng()));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void updateGeoLocation() {

        if (App.getInstance().isConnected() && App.getInstance().getId() != 0 && App.getInstance().getAccount().getLat() == 0.000000 && App.getInstance().getAccount().getLat() == 0.000000) {

            CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_SET_GEO_LOCATION, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {

                                if (!response.getBoolean("error")) {

//                                    Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                                }

                            } catch (JSONException e) {

                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Log.e("updateGeoLocation()", error.toString());
                }
            }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("accountId", Long.toString(App.getInstance().getId()));
                    params.put("accessToken", App.getInstance().getAccessToken());
                    params.put("lat", String.format(Locale.ENGLISH, "%f", App.getInstance().getAccount().getLat()));
                    params.put("lng", "");

                    return params;
                }
            };

            App.getInstance().addToRequestQueue(jsonReq);
        }
    }

    public Boolean authorize(JSONObject authObj) {

        try {

            if (authObj.has("error_code")) {

                this.setErrorCode(authObj.getInt("error_code"));
            }

            if (!authObj.has("error")) {

                return false;
            }

            if (authObj.getBoolean("error")) {

                return false;
            }

            if (!authObj.has("account")) {

                return false;
            }

            JSONArray accountArray = authObj.getJSONArray("account");

            if (accountArray.length() > 0) {

                JSONObject accountObj = (JSONObject) accountArray.get(0);

                setAccount(new Profile(accountObj));
            }

            this.setId(authObj.getLong("accountId"));
            this.setAccessToken(authObj.getString("accessToken"));

            this.saveData();

            this.getSettings();

            if (getFcmToken().length() != 0) {

                setFcmToken(getFcmToken());
            }

            return true;

        } catch (JSONException e) {

            e.printStackTrace();
            return false;
        }
    }

    public void setFcmToken(final String fcmToken) {

        if (this.getId() != 0 && this.getAccessToken().length() != 0) {

            CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_SET_GCM_TOKEN, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {

                                if (!response.getBoolean("error")) {

//                                    Toast.makeText(getApplicationContext(), response.toString(), Toast.LENGTH_SHORT).show();
                                }

                            } catch (JSONException e) {

                                e.printStackTrace();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    Log.e("setFcmToken", error.toString());
                }
            }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("accountId", Long.toString(App.getInstance().getId()));
                    params.put("accessToken", App.getInstance().getAccessToken());

                    params.put("fcm_regId", fcmToken);

                    return params;
                }
            };

            int socketTimeout = 0;//0 seconds - change to what you want
            RetryPolicy policy = new DefaultRetryPolicy(socketTimeout, 0, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

            jsonReq.setRetryPolicy(policy);

            App.getInstance().addToRequestQueue(jsonReq);
        }

        this.fcmToken = fcmToken;
    }

    public String getFcmToken() {

        if (this.fcmToken == null) {

            this.fcmToken = "";
        }

        return this.fcmToken;
    }

    public void setNotificationsCount(int notificationsCount) {

        this.notificationsCount = notificationsCount;

        updateMainActivityBadges(this, "");
    }

    public int getNotificationsCount() {

        return this.notificationsCount;
    }

    public void setMessagesCount(int messagesCount) {

        this.messagesCount = messagesCount;

        updateMainActivityBadges(this, "");
    }

    public int getMessagesCount() {

        return this.messagesCount;
    }

    public void setGuestsCount(int guestsCount) {

        this.guestsCount = guestsCount;

        updateMainActivityBadges(this, "");
    }

    public int getGuestsCount() {

        return this.guestsCount;
    }

    public void setNewFriendsCount(int newFriendsCount) {

        this.newFriendsCount = newFriendsCount;
    }

    public int getNewFriendsCount() {

        return this.newFriendsCount;
    }

    public void setAllowMessagesGCM(int allowMessagesGCM) {

        this.allowMessagesGCM = allowMessagesGCM;
    }

    public int getAllowMessagesGCM() {

        return this.allowMessagesGCM;
    }

    public void setAllowCommentReplyGCM(int allowCommentReplyGCM) {

        this.allowCommentReplyGCM = allowCommentReplyGCM;
    }

    public int getAllowCommentReplyGCM() {

        return this.allowCommentReplyGCM;
    }

    public void setAllowFollowersGCM(int allowFollowersGCM) {

        this.allowFollowersGCM = allowFollowersGCM;
    }

    public int getAllowFollowersGCM() {

        return this.allowFollowersGCM;
    }

    public void setAllowGiftsGCM(int allowGiftsGCM) {

        this.allowGiftsGCM = allowGiftsGCM;
    }

    public int getAllowGiftsGCM() {

        return this.allowGiftsGCM;
    }

    public void setAllowCommentsGCM(int allowCommentsGCM) {

        this.allowCommentsGCM = allowCommentsGCM;
    }

    public int getAllowCommentsGCM() {

        return this.allowCommentsGCM;
    }

    public void setAllowLikesGCM(int allowLikesGCM) {

        this.allowLikesGCM = allowLikesGCM;
    }

    public int getAllowLikesGCM() {

        return this.allowLikesGCM;
    }

    public void setCurrentChatId(int currentChatId) {

        this.currentChatId = currentChatId;
    }

    public int getCurrentChatId() {

        return this.currentChatId;
    }

    public void setErrorCode(int errorCode) {

        this.errorCode = errorCode;
    }

    public int getErrorCode() {

        return this.errorCode;
    }

    public ArrayList<Feeling> getFeelingsList() {

	    if (this.feelingsList == null) {

            feelingsList = new ArrayList<Feeling>();
        }

        return this.feelingsList;
    }

    public ArrayList<BaseGift> getGiftsList() {

        if (this.giftsList == null) {

            giftsList = new ArrayList<BaseGift>();
        }

        return this.giftsList;
    }

    public DBManager getDatabaseManager() {

        return this.dbManager;
    }

    public void setInterstitialAdSettings(InterstitialAdSettings interstitialAdSettings) {

        this.mInterstitialAdSettings = interstitialAdSettings;
    }

    public InterstitialAdSettings getInterstitialAdSettings() {

        return this.mInterstitialAdSettings;
    }

    public void setAdmobSettings(AdmobAdSettings admobSettings) {

        this.mAdmobSettings = admobSettings;
    }

    public AdmobAdSettings getAdmobSettings() {

        return this.mAdmobSettings;
    }

    public void setAgoraSettings(AgoraSettings agoraSettings) {

        this.mAgoraSettings = agoraSettings;
    }

    public AgoraSettings getAgoraSettings() {

        return this.mAgoraSettings;
    }

    public void setPaymentsSettings(PaymentsSettings paymentsSettings) {

        this.mPaymentsSettings = paymentsSettings;
    }

    public PaymentsSettings getPaymentsSettings() {

        return this.mPaymentsSettings;
    }

    public void setAppSettings(AppSettings appSettings) {

        this.mAppSettings = appSettings;
    }

    public AppSettings getAppSettings() {

        return this.mAppSettings;
    }

    public Tooltips getTooltipsSettings() {

        return this.mTooltips;
    }

    public void setSelectedVideoPath(String videoPath) {

        this.selectedVideoPath = videoPath;
    }

    public String getSelectedVideoPath() {

        return this.selectedVideoPath;
    }

    public void setSelectedSoundUrl(String soundUrl) {

        this.soundUrl = soundUrl;
    }

    public String getSelectedSoundUrl() {

        return this.soundUrl;
    }

    public void setSelectedSoundId(long soundId) {

        this.soundId = soundId;
    }

    public long getSelectedSoundId() {

        return this.soundId;
    }

    public void readTooltipsSettings() {

        this.mTooltips.setShowOtpTooltip(sharedPref.getBoolean(getString(R.string.settings_account_tooltip_otp_verification), true));
        this.mTooltips.setShowNotificationsPermissionRequst(sharedPref.getBoolean(getString(R.string.settings_account_tooltip_notifications_permission), true));
        this.mTooltips.setShowCaptureVideoTimeTooltip(sharedPref.getBoolean(App.getInstance().getResources().getString(R.string.settings_account_tooltip_capture_video_time), true));
        this.mTooltips.setShowLoginCreateTooltip(sharedPref.getBoolean(getString(R.string.settings_account_tooltip_login_create), true));
    }

    public void saveTooltipsSettings() {

        sharedPref.edit().putBoolean(getString(R.string.settings_account_tooltip_otp_verification), this.mTooltips.isAllowShowOtpTooltip()).apply();
        sharedPref.edit().putBoolean(getString(R.string.settings_account_tooltip_notifications_permission), this.mTooltips.isAllowShowNotificationsPermissionRequest()).apply();
        sharedPref.edit().putBoolean(App.getInstance().getResources().getString(R.string.settings_account_tooltip_capture_video_time), this.mTooltips.isAllowShowCaptureVideoTimeTooltip()).apply();
        sharedPref.edit().putBoolean(App.getInstance().getResources().getString(R.string.settings_account_tooltip_login_create), this.mTooltips.isAllowShowLoginCreateTooltip()).apply();
    }

    public void setDirectory(File directory) {

        this.directory = directory;
    }

    public File getDirectory() {

        return this.directory;
    }

    public void setAccount(Profile account) {

        this.account = account;
    }

    public long getId() {

        return this.id;
    }

    public void setId(long id) {

        this.id = id;
    }

    public String getAccessToken() {

        return this.accessToken;
    }

    public void setAccessToken(String accessToken) {

        this.accessToken = accessToken;
    }

    public Profile getAccount() {

        return this.account;
    }

    public void setNightMode(int nightMode) {

        this.nightMode = nightMode;
    }

    public int getNightMode() {

        return this.nightMode;
    }

    public void setFeedMode(int feedMode) {

        this.feedMode = feedMode;
    }

    public int getFeedMode() {

        return this.feedMode;
    }

    public void setHiddenItemId(long itemId) {

        this.hidden_item_id = itemId;
    }

    public long getHiddenItemId() {

        return this.hidden_item_id;
    }

    public void setHomeItemsList(ArrayList<Item> homeItemsList) {

        this.homeItemsList = homeItemsList;
    }

    public ArrayList<Item> getHomeItemsList() {

        return this.homeItemsList;
    }

    public void setHomeCurrentItemId(long itemId) {

        this.home_current_item_id = itemId;
    }

    public long getHomeCurrentItemId() {

        return this.home_current_item_id;
    }

    public void setHomeCurrentItemCommentsCnt(int cnt) {

        this.home_current_item_comments_cnt = cnt;
    }

    public int getHomeCurrentItemCommentsCnt() {

        return this.home_current_item_comments_cnt;
    }

    public void readData() {

        this.getAccount().setProfileType(sharedPref.getInt(getString(R.string.settings_profile_type), 0));

        this.setNightMode(sharedPref.getInt(getString(R.string.settings_night_mode), 0));
        this.setFeedMode(sharedPref.getInt(getString(R.string.settings_feed_mode), 1));
        this.setHiddenItemId(sharedPref.getLong(getString(R.string.settings_hidden_item_id), 1));

        this.setId(sharedPref.getLong(getString(R.string.settings_account_id), 0));
        this.getAccount().setUsername(sharedPref.getString(getString(R.string.settings_account_username), ""));
        this.setAccessToken(sharedPref.getString(getString(R.string.settings_account_access_token), ""));

        this.setAllowMessagesGCM(sharedPref.getInt(getString(R.string.settings_account_allow_messages_gcm), 1));
        this.setAllowCommentsGCM(sharedPref.getInt(getString(R.string.settings_account_allow_comments_gcm), 1));
        this.setAllowCommentReplyGCM(sharedPref.getInt(getString(R.string.settings_account_allow_comments_reply_gcm), 1));

        this.getAccount().setAllowShowLikedVideos(sharedPref.getInt(getString(R.string.settings_account_allow_show_liked_videos), 1));
        this.getAccount().setAllowDownloadVideos(sharedPref.getInt(getString(R.string.settings_account_allow_download_videos), 1));

        this.getAccount().setBalance(sharedPref.getInt(getString(R.string.settings_balance), 0));
        this.getAccount().setVerified(sharedPref.getInt(getString(R.string.settings_verified_barge), 0));
        this.getAccount().setGhostMode(sharedPref.getInt(getString(R.string.settings_ghost_mode), 0));
        this.getAccount().setAdmobMode(sharedPref.getInt(getString(R.string.settings_ads_mode), 0));

        this.getAccount().setProMode(sharedPref.getInt(getString(R.string.settings_pro_mode), 0));

        this.getAccount().setNormalPhotoUrl(sharedPref.getString(getString(R.string.settings_account_photo_url), ""));
        this.getAccount().setFullname(sharedPref.getString(getString(R.string.settings_account_fullname), ""));

        this.getAccount().setLat(Double.parseDouble(sharedPref.getString(getString(R.string.settings_account_lat), "0.000000")));
        this.getAccount().setLng(Double.parseDouble(sharedPref.getString(getString(R.string.settings_account_lng), "0.000000")));

        this.setAllowGiftsGCM(sharedPref.getInt(getString(R.string.settings_account_allow_gifts_gcm), 1));
        this.setAllowLikesGCM(sharedPref.getInt(getString(R.string.settings_account_allow_likes_gcm), 1));
        this.setAllowFollowersGCM(sharedPref.getInt(getString(R.string.settings_account_allow_friends_requests_gcm), 1));

        this.setLanguage(sharedPref.getString(getString(R.string.settings_language), "en"));

        // Interstitial

        if (this.getInterstitialAdSettings() != null) {

            if (sharedPref.contains(getString(R.string.settings_interstitial_ad_after_new_item))) {

                this.getInterstitialAdSettings().setInterstitialAdAfterNewItem(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_item), 0));
                this.getInterstitialAdSettings().setInterstitialAdAfterNewGalleryItem(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_gallery_item), 0));
                this.getInterstitialAdSettings().setInterstitialAdAfterNewMarketItem(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_market_item), 0));
                this.getInterstitialAdSettings().setInterstitialAdAfterNewLike(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_like), 0));

                this.getInterstitialAdSettings().setCurrentInterstitialAdAfterNewItem(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_item_current_val), 0));
                this.getInterstitialAdSettings().setCurrentInterstitialAdAfterNewGalleryItem(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_gallery_item_current_val), 0));
                this.getInterstitialAdSettings().setCurrentInterstitialAdAfterNewMarketItem(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_market_item_current_val), 0));
                this.getInterstitialAdSettings().setCurrentInterstitialAdAfterNewLike(sharedPref.getInt(getString(R.string.settings_interstitial_ad_after_new_like_current_val), 0));
            }
        }

        // Admob

        if (this.getAdmobSettings() != null) {

            if (sharedPref.contains(getString(R.string.settings_interstitial_ad_after_new_item))) {

                this.getAdmobSettings().setBannerNativeAdUnitId(sharedPref.getString(getString(R.string.settings_android_admob_banner_native_ad_unit_id), "ca-app-pub-3940256099942544/2247696110"));
            }
        }

        sharedPref.edit().putString(getString(R.string.settings_android_admob_banner_native_ad_unit_id), this.getAdmobSettings().getBannerNativeAdUnitId()).apply();

        this.getAccount().setOtpVerified(sharedPref.getInt(getString(R.string.settings_account_otp_verification), 0));
        this.getAccount().setOtpPhone(sharedPref.getString(getString(R.string.settings_account_otp_phone_number), ""));
    }

    public void saveData() {

        sharedPref.edit().putInt(getString(R.string.settings_profile_type), this.getAccount().getProfileType()).apply();

        sharedPref.edit().putInt(getString(R.string.settings_night_mode), this.getNightMode()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_feed_mode), this.getFeedMode()).apply();
        sharedPref.edit().putLong(getString(R.string.settings_hidden_item_id), this.getHiddenItemId()).apply();

        sharedPref.edit().putLong(getString(R.string.settings_account_id), this.getId()).apply();
        sharedPref.edit().putString(getString(R.string.settings_account_username), this.getAccount().getUsername()).apply();
        sharedPref.edit().putString(getString(R.string.settings_account_access_token), this.getAccessToken()).apply();

        sharedPref.edit().putInt(getString(R.string.settings_account_allow_messages_gcm), this.getAllowMessagesGCM()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_account_allow_comments_gcm), this.getAllowCommentsGCM()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_account_allow_comments_reply_gcm), this.getAllowCommentReplyGCM()).apply();

        sharedPref.edit().putInt(getString(R.string.settings_account_allow_show_liked_videos), this.getAccount().getAllowShowLikedVideos()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_account_allow_download_videos), this.getAccount().getAllowDownloadVideos()).apply();

        sharedPref.edit().putInt(getString(R.string.settings_balance), this.getAccount().getBalance()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_verified_barge), this.getAccount().getVerified()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_ghost_mode), this.getAccount().getGhostMode()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_ads_mode), this.getAccount().getAdmobMode()).apply();

        sharedPref.edit().putInt(getString(R.string.settings_pro_mode), this.getAccount().getProMode()).apply();

        sharedPref.edit().putString(getString(R.string.settings_account_photo_url), this.getAccount().getNormalPhotoUrl()).apply();
        sharedPref.edit().putString(getString(R.string.settings_account_fullname), this.getAccount().getFullname()).apply();

        sharedPref.edit().putString(getString(R.string.settings_account_lat), Double.toString(this.getAccount().getLat())).apply();
        sharedPref.edit().putString(getString(R.string.settings_account_lng), Double.toString(this.getAccount().getLng())).apply();

        sharedPref.edit().putInt(getString(R.string.settings_account_allow_gifts_gcm), this.getAllowGiftsGCM()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_account_allow_likes_gcm), this.getAllowLikesGCM()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_account_allow_friends_requests_gcm), this.getAllowFollowersGCM()).apply();

        sharedPref.edit().putString(getString(R.string.settings_language), this.getLanguage()).apply();

        //

        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_item), this.getInterstitialAdSettings().getInterstitialAdAfterNewItem()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_gallery_item), this.getInterstitialAdSettings().getInterstitialAdAfterNewGalleryItem()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_market_item), this.getInterstitialAdSettings().getInterstitialAdAfterNewMarketItem()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_like), this.getInterstitialAdSettings().getInterstitialAdAfterNewLike()).apply();

        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_item_current_val), this.getInterstitialAdSettings().getCurrentInterstitialAdAfterNewItem()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_gallery_item_current_val), this.getInterstitialAdSettings().getCurrentInterstitialAdAfterNewGalleryItem()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_market_item_current_val), this.getInterstitialAdSettings().getCurrentInterstitialAdAfterNewMarketItem()).apply();
        sharedPref.edit().putInt(getString(R.string.settings_interstitial_ad_after_new_like_current_val), this.getInterstitialAdSettings().getCurrentInterstitialAdAfterNewLike()).apply();

        //

        sharedPref.edit().putString(getString(R.string.settings_android_admob_banner_native_ad_unit_id), this.getAdmobSettings().getBannerNativeAdUnitId()).apply();

        //

        sharedPref.edit().putInt(getString(R.string.settings_account_otp_verification), this.getAccount().getOtpVerified()).apply();
        sharedPref.edit().putString(getString(R.string.settings_account_otp_phone_number), this.getAccount().getOtpPhone()).apply();
    }

    public void removeData() {

        setAccount(new Profile());

        sharedPref.edit().putLong(getString(R.string.settings_account_id), 0).apply();
        sharedPref.edit().putString(getString(R.string.settings_account_username), "").apply();
        sharedPref.edit().putString(getString(R.string.settings_account_access_token), "").apply();

        sharedPref.edit().putInt(getString(R.string.settings_balance), 0).apply();
        sharedPref.edit().putInt(getString(R.string.settings_verified_barge), 0).apply();
        sharedPref.edit().putInt(getString(R.string.settings_ghost_mode), 0).apply();
        sharedPref.edit().putInt(getString(R.string.settings_ads_mode), 1).apply();
        sharedPref.edit().putInt(getString(R.string.settings_pro_mode), 0).apply();

        sharedPref.edit().putString(getString(R.string.settings_account_photo_url), "").apply();
        sharedPref.edit().putString(getString(R.string.settings_account_fullname), "").apply();

        sharedPref.edit().putString(getString(R.string.settings_account_lat), "0.000000").apply();
        sharedPref.edit().putString(getString(R.string.settings_account_lng), "0.000000").apply();

        sharedPref.edit().putInt(getString(R.string.settings_account_otp_verification), 0).apply();
        sharedPref.edit().putString(getString(R.string.settings_account_otp_phone_number), "").apply();

        // Restore tooltips settings

        App.getInstance().getTooltipsSettings().setShowOtpTooltip(true);
        App.getInstance().getTooltipsSettings().setShowLoginCreateTooltip(true);
        App.getInstance().saveTooltipsSettings();
    }

    public static void updateMainActivityBadges(Context context, String message) {

        Intent intent = new Intent(TAG_UPDATE_BADGES);
        intent.putExtra("message", message); // if need message
        context.sendBroadcast(intent);
    }

    public static synchronized App getInstance() {
		return mInstance;
	}

	public RequestQueue getRequestQueue() {

		if (mRequestQueue == null) {
			mRequestQueue = Volley.newRequestQueue(getApplicationContext());
		}

		return mRequestQueue;
	}

	public ImageLoader getImageLoader() {
		getRequestQueue();
		if (mImageLoader == null) {
			mImageLoader = new ImageLoader(this.mRequestQueue,
					new LruBitmapCache());
		}
		return this.mImageLoader;
	}

	public <T> void addToRequestQueue(Request<T> req, String tag) {
		// set the default tag if tag is empty
		req.setTag(TextUtils.isEmpty(tag) ? TAG : tag);
		getRequestQueue().add(req);
	}

	public <T> void addToRequestQueue(Request<T> req) {
		req.setTag(TAG);
		getRequestQueue().add(req);
	}

	public void cancelPendingRequests(Object tag) {
		if (mRequestQueue != null) {
			mRequestQueue.cancelAll(tag);
		}
	}
}