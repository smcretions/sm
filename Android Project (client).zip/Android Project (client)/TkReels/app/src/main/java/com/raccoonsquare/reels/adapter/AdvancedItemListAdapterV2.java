package com.raccoonsquare.reels.adapter;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.net.Uri;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.aghajari.emojiview.view.AXEmojiEditText;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.balysv.materialripple.MaterialRippleLayout;
import com.raccoonsquare.reels.LoginActivity;
import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.ReactionsActivity;
import com.raccoonsquare.reels.RegisterActivity;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Comment;
import com.raccoonsquare.reels.model.Item;
import com.raccoonsquare.reels.util.Api;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.util.Helper;
import com.raccoonsquare.reels.util.TagClick;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;


public class AdvancedItemListAdapterV2 extends RecyclerView.Adapter<AdvancedItemListAdapterV2.ViewHolder> implements Constants {

    private List<Item> items = new ArrayList<>();

    private Context context;

    ImageLoader imageLoader = App.getInstance().getImageLoader();

    private OnItemMenuButtonClickListener onItemMenuButtonClickListener;
    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {

        void onItemClick(View view, Item obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {

        this.mOnItemClickListener = mItemClickListener;
    }

    public interface OnItemMenuButtonClickListener {

        void onItemClick(View view, Item obj, int actionId, int position);
    }

    public void setOnMoreButtonClickListener(final OnItemMenuButtonClickListener onItemMenuButtonClickListener) {

        this.onItemMenuButtonClickListener = onItemMenuButtonClickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        public TextView mItemViewsCount;
        public ProgressBar mItemImageProgress;

        public ImageView mItemImg;

        public ViewHolder(View v, int itemType) {

            super(v);

            mItemImageProgress = v.findViewById(R.id.item_image_progress);
            mItemViewsCount = v.findViewById(R.id.views_count);
            mItemImg = v.findViewById(R.id.item_image);
        }

    }

    public AdvancedItemListAdapterV2(Context ctx, List<Item> items) {

        this.context = ctx;
        this.items = items;

        if (imageLoader == null) {

            imageLoader = App.getInstance().getImageLoader();
        }
    }

    public AdvancedItemListAdapterV2(Context ctx, List<Item> items, int pageId) {

        this.context = ctx;
        this.items = items;

        if (imageLoader == null) {

            imageLoader = App.getInstance().getImageLoader();
        }
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_video_layout_2, parent, false);

        return new ViewHolder(v, viewType);
    }

    @Override
    public void onBindViewHolder(ViewHolder holder, final int position) {

        final Item p = items.get(position);

        onBindItem(holder, position);
    }

    public void onBindItem(ViewHolder holder, final int position) {

        final Item p = items.get(position);

        holder.mItemImg.setVisibility(View.GONE);
        holder.mItemImageProgress.setVisibility(View.VISIBLE);

        if (p.getPreviewVideoImgUrl().length() != 0){

            final ProgressBar progressView = holder.mItemImageProgress;
            final ImageView imageView = holder.mItemImg;

            Picasso.with(context)
                    .load(p.getPreviewVideoImgUrl())
                    .into(holder.mItemImg, new Callback() {

                        @Override
                        public void onSuccess() {

                            imageView.setVisibility(View.VISIBLE);
                            progressView.setVisibility(View.GONE);
                        }

                        @Override
                        public void onError() {

                            progressView.setVisibility(View.GONE);
                            imageView.setVisibility(View.VISIBLE);
                            imageView.setImageResource(R.drawable.img_loading_error);
                        }
                    });

        }

        holder.mItemViewsCount.setText(Helper.prettyCount(p.getViewsCount()));

        holder.mItemImg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (mOnItemClickListener != null) {

                    mOnItemClickListener.onItemClick(view, p, position);
                }
            }
        });
    }

    @Override
    public int getItemCount() {

        return items.size();
    }

    @Override
    public long getItemId(int position) {
        return position;
    }

    @Override
    public int getItemViewType(int position) {

        final Item p = items.get(position);

        if (p.getAd() == 0) {

            return 0;

        } else {

            return 1;
        }
    }
}