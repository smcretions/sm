package com.raccoonsquare.reels.adapter;

import android.content.Context;
import androidx.recyclerview.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;
import com.balysv.materialripple.MaterialRippleLayout;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.raccoonsquare.reels.app.App;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;

import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.model.MarketItem;
import com.raccoonsquare.reels.util.Helper;


public class MarketListAdapter extends RecyclerView.Adapter<MarketListAdapter.MyViewHolder> {

	private Context mContext;
	private List<MarketItem> itemList;

    ImageLoader imageLoader = App.getInstance().getImageLoader();

    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {

        void onItemClick(View view, MarketItem obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {

        this.mOnItemClickListener = mItemClickListener;
    }

	public class MyViewHolder extends RecyclerView.ViewHolder {

        public CircularImageView mItemAuthorPhoto;
        public TextView mItemAuthorFullname, mItemDescription, mPriceLabel;
        public LinearLayout mItemLabelLayout;
        public ProgressBar mItemImageProgress;

        public ImageView mItemImg;

		public MyViewHolder(View v) {

			super(v);

            mItemImageProgress = v.findViewById(R.id.item_image_progress);
            mItemAuthorPhoto = (CircularImageView) v.findViewById(R.id.user_image);

            mItemLabelLayout = v.findViewById(R.id.item_label_layout);

            mItemAuthorFullname = v.findViewById(R.id.first_last_name_txt);
            mItemDescription = v.findViewById(R.id.description_txt);
            mPriceLabel = v.findViewById(R.id.price_txt);

            mItemImg = v.findViewById(R.id.item_image);
		}
	}


	public MarketListAdapter(Context mContext, List<MarketItem> itemList) {

		this.mContext = mContext;
		this.itemList = itemList;
	}

	@Override
	public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

		View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_market_layout, parent, false);


		return new MyViewHolder(itemView);
	}

	@Override
	public void onBindViewHolder(final MyViewHolder holder, final int position) {

		final MarketItem p = itemList.get(position);

        holder.mItemLabelLayout.setVisibility(View.GONE);
        holder.mItemAuthorPhoto.setVisibility(View.VISIBLE);

        if (p.getFromUserPhotoUrl().length() != 0) {

            imageLoader.get(p.getFromUserPhotoUrl(), ImageLoader.getImageListener(holder.mItemAuthorPhoto, R.drawable.profile_default_photo, R.drawable.profile_default_photo));

        } else {

            holder.mItemAuthorPhoto.setVisibility(View.VISIBLE);
            holder.mItemAuthorPhoto.setImageResource(R.drawable.profile_default_photo);
        }

        holder.mItemImg.setVisibility(View.GONE);
        holder.mItemImageProgress.setVisibility(View.VISIBLE);

        if (p.getImgUrl() != null && p.getImgUrl().length() > 0) {

            final ImageView img = holder.mItemImg;
            final ProgressBar progressView = holder.mItemImageProgress;

            Picasso.with(mContext)
                    .load(p.getImgUrl())
                    .into(holder.mItemImg, new Callback() {

                        @Override
                        public void onSuccess() {

                            progressView.setVisibility(View.GONE);
                            img.setVisibility(View.VISIBLE);
                        }

                        @Override
                        public void onError() {

                            progressView.setVisibility(View.GONE);
                            img.setVisibility(View.VISIBLE);
                            img.setImageResource(R.drawable.profile_default_photo);
                        }
                    });

        } else {

            holder.mItemImageProgress.setVisibility(View.GONE);
            holder.mItemImg.setVisibility(View.VISIBLE);

			holder.mItemImg.setImageResource(R.drawable.img_loading);
		}

        holder.mItemDescription.setText(p.getTitle());
        holder.mItemAuthorFullname.setText(p.getFromUserFullname());

        Helper helper = new Helper();

        holder.mPriceLabel.setText(mContext.getString(R.string.label_currency) + helper.getFormatedAmount(p.getPrice()));

        holder.mItemImg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (mOnItemClickListener != null) {

                    mOnItemClickListener.onItemClick(view, p, position);
                }
            }
        });
	}

	@Override
	public int getItemCount() {

		return itemList.size();
	}
}