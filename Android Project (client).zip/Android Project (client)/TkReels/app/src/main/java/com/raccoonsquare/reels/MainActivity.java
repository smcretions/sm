package com.raccoonsquare.reels;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Rect;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.balysv.materialripple.MaterialRippleLayout;
import com.raccoonsquare.reels.util.CustomRequest;
import com.google.android.gms.ads.RequestConfiguration;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.appbar.AppBarLayout;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.navigation.NavigationView;
import com.google.android.material.snackbar.Snackbar;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.IdRes;
import androidx.annotation.NonNull;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.content.ContextCompat;
import androidx.core.view.MenuItemCompat;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.appcompat.widget.Toolbar;
import androidx.fragment.app.FragmentTransaction;

import android.provider.Settings;
import android.util.Log;
import android.util.TypedValue;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.MobileAds;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.common.ActivityBase;
import com.raccoonsquare.reels.util.Helper;

import org.json.JSONObject;

public class MainActivity extends ActivityBase {

    private Menu mMainMenu;

    private AppBarLayout mAppBarLayout;

    private LinearLayout mNavBottomView;
    private View mNavBottomViewSeparator;
    private TextView mNotificationsBadge, mMenuBadge;

    private LinearLayout mTabHome, mTabSearch, mTabNew;
    private RelativeLayout mTabNotifications, mTabMenu;

    private CoordinatorLayout mParentView;

    //

    private BottomSheetBehavior mBehavior;
    private BottomSheetDialog mBottomSheetDialog;
    private View mBottomSheet;
    private LinearLayout mBottomSheetInfo;

    //

    Fragment fragment;

    Toolbar mToolbar;

    Boolean action = false;

    private FrameLayout mFrameLayout;

    private int pageId = PAGE_MAIN;

    private View messenger_badge;

    // used to store app title
    private CharSequence mTitle = "";

    private Boolean restore = false;

    private ActivityResultLauncher<String> notificationsPermissionLauncher;
    private ActivityResultLauncher<Intent> captureActivityResultLauncher;

    private ActivityResultLauncher<Intent> videoFromGalleryActivityResultLauncher;
    private ActivityResultLauncher<String[]> storagePermissionLauncher;

    GoogleSignInClient mGoogleSignInClient;
    ActivityResultLauncher<Intent> googleSigninActivityResultLauncher;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        // ge intent

        // Get intent data

        Intent i = getIntent();

        pageId = i.getIntExtra("pageId", PAGE_MAIN);

        // Initialize Google Admob

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(@NonNull InitializationStatus initializationStatus) {
            }
        });

        RequestConfiguration configuration = new RequestConfiguration.Builder().setTestDeviceIds(Arrays.asList("020A01E3A1C7D335ED6DF8E35AE24845")).build();
        MobileAds.setRequestConfiguration(configuration);

        // Location. Send Location data (lat & lng) to server

            App.getInstance().setLocation();

        //

        Log.e("tester", "MainActivity onCreate");

        if (savedInstanceState != null) {

            fragment = getSupportFragmentManager().getFragment(savedInstanceState, "currentFragment");

            restore = savedInstanceState.getBoolean("restore");
            mTitle = savedInstanceState.getString("mTitle");
            pageId = savedInstanceState.getInt("pageId");

        } else {

            fragment = new Fragment();

            restore = false;
            mTitle = getString(R.string.app_name);
            pageId = PAGE_MAIN;
        }

        //

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(this, gso);

        googleSigninActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    // There are no request codes
                    Intent data = result.getData();

                    Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);

                    try {

                        GoogleSignInAccount account = task.getResult(ApiException.class);

                        // Signed in successfully, show authenticated UI.

                        showpDialog();

                        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_OAUTH, null,
                                new Response.Listener<JSONObject>() {
                                    @Override
                                    public void onResponse(JSONObject response) {

                                        if (App.getInstance().authorize(response)) {

                                            if (App.getInstance().getAccount().getState() == ACCOUNT_STATE_ENABLED) {

                                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(intent);

                                            } else {

                                                if (App.getInstance().getAccount().getState() == ACCOUNT_STATE_BLOCKED) {

                                                    App.getInstance().logout();
                                                    Toast.makeText(getApplicationContext(), getText(R.string.msg_account_blocked), Toast.LENGTH_SHORT).show();

                                                } else {

                                                    App.getInstance().updateGeoLocation();

                                                    Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                    startActivity(intent);
                                                }
                                            }

                                        } else {

                                            Toast.makeText(getApplicationContext(), getString(R.string.error_data_loading), Toast.LENGTH_SHORT).show();
                                        }

                                        hidepDialog();
                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Log.e("Google", "signInWithCredential:failure");

                                Toast.makeText(getApplicationContext(), getText(R.string.error_data_loading), Toast.LENGTH_LONG).show();

                                hidepDialog();
                            }
                        }) {

                            @Override
                            protected Map<String, String> getParams() {
                                Map<String, String> params = new HashMap<String, String>();

                                params.put("client_id", CLIENT_ID);

                                params.put("account_id", Long.toString(App.getInstance().getId()));
                                params.put("access_token", App.getInstance().getAccessToken());

                                params.put("app_type", Integer.toString(APP_TYPE_ANDROID));
                                params.put("fcm_regId", App.getInstance().getFcmToken());

                                params.put("action", "");

                                params.put("uid", account.getId());
                                params.put("oauth_type", Integer.toString(OAUTH_TYPE_GOOGLE));
                                params.put("oauth_name", account.getDisplayName());
                                params.put("oauth_email", account.getEmail());
                                params.put("oauth_photo", account.getPhotoUrl().toString());

                                return params;
                            }
                        };

                        App.getInstance().addToRequestQueue(jsonReq);

                    } catch (ApiException e) {

                        // The ApiException status code indicates the detailed failure reason.
                        // Please refer to the GoogleSignInStatusCodes class reference for more information.
                        Log.e("Google", "Google sign in failed", e);
                    }
                }
            }
        });

        //

        notificationsPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {

            App.getInstance().getTooltipsSettings().setShowNotificationsPermissionRequst(false);
            App.getInstance().saveTooltipsSettings();

            if (isGranted) {

                // Permission is granted
                Log.e("Push Permission", "Permission is granted");

            } else {

                // Permission is denied

                Log.e("Push Permission", "denied");

                Snackbar.make(findViewById(android.R.id.content), getString(R.string.label_no_notifications_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(MainActivity.this, getString(R.string.label_grant_notifications_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }
        });

        captureActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == 100) {

//                    Log.e("Dimon", "run new item");
//
//                    Intent i = new Intent(MainActivity.this, NewItemActivity.class);
//                    startActivity(i);
                }
            }
        });

        //

        mFrameLayout = findViewById(R.id.container_body);

        //

        mToolbar = findViewById(R.id.toolbar);

        if (pageId == PAGE_MAIN) {

            setStatusBarColor(R.color.black);
            mToolbar.setVisibility(View.GONE);
        }

        setSupportActionBar(mToolbar);
        // getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        // getSupportActionBar().setHomeButtonEnabled(true);
        getSupportActionBar().setTitle(mTitle);

        //

        mParentView = findViewById(R.id.parent_view);

        //

        mAppBarLayout = findViewById(R.id.appbar_layout);

        // Bottom Navigation

        mNavBottomView = findViewById(R.id.nav_bottom_view);
        mNavBottomViewSeparator = findViewById(R.id.nav_bottom_top_separator);

        // Prepare bottom sheet

        mBottomSheet = findViewById(R.id.bottom_sheet);
        mBehavior = BottomSheetBehavior.from(mBottomSheet);

        mTabHome = findViewById(R.id.nav_menu_1);
        mTabHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                displayFragment(R.id.nav_menu_1, getString(R.string.nav_home));
            }
        });

        mTabSearch = findViewById(R.id.nav_menu_2);
        mTabSearch.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                displayFragment(R.id.nav_menu_2, getString(R.string.action_video_search));
            }
        });

        mTabNew = findViewById(R.id.nav_menu_3);
        mTabNew.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                displayFragment(R.id.nav_menu_3, "");
            }
        });

        mTabNotifications = findViewById(R.id.nav_menu_4);
        mTabNotifications.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                displayFragment(R.id.nav_menu_4, getString(R.string.nav_notifications));
            }
        });

        mTabMenu = findViewById(R.id.nav_menu_5);
        mTabMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                displayFragment(R.id.nav_menu_5, getString(R.string.nav_menu));
            }
        });

        //

        mNotificationsBadge = findViewById(R.id.notifications_badge);
        mNotificationsBadge.setVisibility(View.GONE);

        mMenuBadge = findViewById(R.id.menu_badge);
        mMenuBadge.setVisibility(View.GONE);

        //

        if (!restore) {

            switch (pageId) {

                case PAGE_NOTIFICATIONS: {

                    displayFragment(R.id.nav_menu_4, getString(R.string.nav_notifications));

                    break;
                }

                case PAGE_PROFILE: {

                    displayFragment(R.id.nav_menu_5, getString(R.string.nav_profile));

                    break;
                }

                default: {

                    // Show default section "Home"

                    displayFragment(R.id.nav_menu_1, getString(R.string.nav_home));

                    break;
                }
            }
        }

        // Create a ConsentRequestParameters object.

        Helper helper = new Helper();
        helper.requestConsent(this, App.getInstance().isMobileAdsInitializeCalled.get());
    }

    public void refreshBadges() {

        if (App.getInstance().getNotificationsCount() != 0) {

            mNotificationsBadge.setVisibility(View.VISIBLE);

        } else {

            mNotificationsBadge.setVisibility(View.GONE);
        }

        if (App.getInstance().getGuestsCount() != 0 || App.getInstance().getMessagesCount() != 0) {

            mMenuBadge.setVisibility(View.VISIBLE);

        } else {

            mMenuBadge.setVisibility(View.GONE);
        }
    }

    private void displayFragment(int id, String title) {

        invalidateOptionsMenu();

        action = false;

        switch (id) {

            case R.id.nav_menu_1: {

                pageId = PAGE_MAIN;

                fragment = new HomeFragment().newInstance(true);

                action = true;

                break;
            }

            case R.id.nav_menu_2: {

                pageId = PAGE_SEARCH;

                fragment = new FinderFragment().newInstance(false);

                action = true;

                break;
            }

            case R.id.nav_menu_3: {

                //setStatusBarColor(R.color.colorPrimaryDark);
                //mToolbar.setVisibility(View.VISIBLE);

                if (App.getInstance().getId() != 0) {

                    if (App.getInstance().getAppSettings().getMarketFeature()){

                        showNewItemBottomSheet(BottomSheetBehavior.STATE_EXPANDED);

                    } else {

                        Intent i = new Intent(MainActivity.this, CaptureActivity.class);
                        captureActivityResultLauncher.launch(i);
                    }

                } else {

                    showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);
                }

                break;
            }

            case R.id.nav_menu_4: {

                if (App.getInstance().getId() != 0) {

                    pageId = PAGE_NOTIFICATIONS;

                    fragment = new NotificationsFragment();

                    action = true;

                } else {

                    showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);
                }

                break;
            }

            case R.id.nav_menu_5: {

                if (App.getInstance().getId() != 0) {

                    pageId = PAGE_PROFILE;

                    fragment = new MenuFragment();

                    action = true;

                } else {

                    showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);
                }

                break;
            }

            default: {

                break;
            }
        }

        if (action) {

            int primary = ContextCompat.getColor(this, R.color.colorBottomNavIconTint);
            int active = ContextCompat.getColor(this, R.color.colorBottomNavIconTintActive);

            if (id == R.id.nav_menu_1) {

                primary = ContextCompat.getColor(this, R.color.colorBottomNavIconTintMainPage);
                active = ContextCompat.getColor(this, R.color.colorBottomNavIconTintActiveMainPage);
            }

            ((ImageView) mTabHome.getChildAt(0)).setColorFilter(primary, android.graphics.PorterDuff.Mode.SRC_IN);
            ((TextView) mTabHome.getChildAt(1)).setTextColor(primary);

            ((ImageView) mTabSearch.getChildAt(0)).setColorFilter(primary, android.graphics.PorterDuff.Mode.SRC_IN);
            ((TextView) mTabSearch.getChildAt(1)).setTextColor(primary);

            //

            LinearLayout mTabMenuContent = (LinearLayout) mTabMenu.getChildAt(1);

            ((ImageView) mTabMenuContent.getChildAt(0)).setColorFilter(primary, android.graphics.PorterDuff.Mode.SRC_IN);
            ((TextView) mTabMenuContent.getChildAt(1)).setTextColor(primary);

            //

            LinearLayout mTabNotificationsContent = (LinearLayout) mTabNotifications.getChildAt(1);

            ((ImageView) mTabNotificationsContent.getChildAt(0)).setColorFilter(primary, android.graphics.PorterDuff.Mode.SRC_IN);
            ((TextView) mTabNotificationsContent.getChildAt(1)).setTextColor(primary);

            //

            if (id == R.id.nav_menu_1) {

                ((ImageView) mTabHome.getChildAt(0)).setColorFilter(active, android.graphics.PorterDuff.Mode.SRC_IN);
                ((TextView) mTabHome.getChildAt(1)).setTextColor(active);

                setStatusBarColor(R.color.black);
                mToolbar.setVisibility(View.GONE);
            }

            if (id == R.id.nav_menu_2) {

                ((ImageView) mTabSearch.getChildAt(0)).setColorFilter(active, android.graphics.PorterDuff.Mode.SRC_IN);
                ((TextView) mTabSearch.getChildAt(1)).setTextColor(active);

                setStatusBarColor(R.color.colorPrimaryDark);
                mToolbar.setVisibility(View.GONE);
            }

            if (id == R.id.nav_menu_4) {

                ((ImageView) mTabNotificationsContent.getChildAt(0)).setColorFilter(active, android.graphics.PorterDuff.Mode.SRC_IN);
                ((TextView) mTabNotificationsContent.getChildAt(1)).setTextColor(active);

                setStatusBarColor(R.color.colorPrimaryDark);
                mToolbar.setVisibility(View.VISIBLE);
            }

            if (id == R.id.nav_menu_5) {

                ((ImageView) mTabMenuContent.getChildAt(0)).setColorFilter(active, android.graphics.PorterDuff.Mode.SRC_IN);
                ((TextView) mTabMenuContent.getChildAt(1)).setTextColor(active);

                setStatusBarColor(R.color.colorPrimaryDark);
                mToolbar.setVisibility(View.VISIBLE);
            }

            //

            updateStatusBarText();
            invalidateFrame();
        }

        if (action && fragment != null) {

            getSupportActionBar().setDisplayShowCustomEnabled(false);
            getSupportActionBar().setDisplayShowTitleEnabled(true);
            getSupportActionBar().setTitle(title);

            FragmentManager fragmentManager = getSupportFragmentManager();
            fragmentManager.beginTransaction().replace(R.id.container_body, fragment).commit();
        }
    }

    public void invalidateFrame() {

        int actionBarHeight = 0;

//        ((ImageView) mTabNew.getChildAt(0)).setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_create_video));
//        mNavBottomView.setBackgroundColor(getResources().getColor(R.color.colorBottomNavBackground));
//        mNavBottomViewSeparator.setBackgroundColor(getResources().getColor(R.color.colorBottomNavSeparator));

//        TypedValue tv = new TypedValue();
//
//        if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {
//
//            actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data,getResources().getDisplayMetrics());
//        }

        if (pageId != PAGE_MAIN) {


            ((ImageView) mTabNew.getChildAt(0)).setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_create_video));
            mNavBottomView.setBackgroundColor(getResources().getColor(R.color.colorBottomNavBackground));
            mNavBottomViewSeparator.setBackgroundColor(getResources().getColor(R.color.colorBottomNavSeparator));

            TypedValue tv = new TypedValue();

            if (getTheme().resolveAttribute(android.R.attr.actionBarSize, tv, true)) {

                actionBarHeight = TypedValue.complexToDimensionPixelSize(tv.data,getResources().getDisplayMetrics());
            }

        } else {

            ((ImageView) mTabNew.getChildAt(0)).setImageDrawable(ContextCompat.getDrawable(this, R.drawable.ic_create_video_main_page));
            mNavBottomView.setBackgroundColor(getResources().getColor(R.color.colorBottomNavBackgroundMainPage));
            mNavBottomViewSeparator.setBackgroundColor(getResources().getColor(R.color.colorBottomNavSeparatorMainPage));
        }

        RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(
                RelativeLayout.LayoutParams.MATCH_PARENT,
                RelativeLayout.LayoutParams.MATCH_PARENT
        );

        params.setMargins(0, 0, 0, actionBarHeight);
        mFrameLayout.setLayoutParams(params);

        mFrameLayout.invalidate();
    }

    public void updateStatusBarText() {

        if (pageId == PAGE_MAIN) {

            setLightStatusBarText();

        } else {

            if (App.getInstance().getNightMode() == 1) {

                setLightStatusBarText();

            } else {

                setDarkStatusBarText();
            }
        }
    }

    public void setLightStatusBarText() {

        View decorView = getWindow().getDecorView();
        decorView.setSystemUiVisibility(decorView.getSystemUiVisibility() & ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    public void setDarkStatusBarText() {

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR);
    }

    public void setStatusBarColor(int color) {

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {

            window.setStatusBarColor(getColor(color));

        } else {
            window.setStatusBarColor(getResources().getColor(color));
        }
    }

    private void hideKeyboard() {

        View view = this.getCurrentFocus();

        if (view != null) {

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(view.getWindowToken(), 0);
        }
    }

    private void showAuthorizationBottomSheet(int state) {

        mBehavior.setState(state);

        final View view = getLayoutInflater().inflate(R.layout.bottom_sheet_authorization, null);

        // Close

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        //

        LinearLayout mMainPanel = (LinearLayout) view.findViewById(R.id.main_panel);
        Button mGoogleLoginButton = (Button) view.findViewById(R.id.action_google_login);
        Button mSignupButton = (Button) view.findViewById(R.id.action_signup);
        TextView mLoginButton = (TextView) view.findViewById(R.id.button_login);
        TextView mTermsButton = (TextView) view.findViewById(R.id.button_terms);

        mGoogleLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                googleSigninActivityResultLauncher.launch(signInIntent);
            }
        });

        mTermsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(MainActivity.this, WebViewActivity.class);
                i.putExtra("url", METHOD_APP_TERMS);
                i.putExtra("title", getText(R.string.settings_terms));
                startActivity(i);
            }
        });

        mLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(MainActivity.this, LoginActivity.class);
                startActivity(i);
            }
        });

        mSignupButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();
                //showAuthorizationBottomSheet(BottomSheetBehavior.STATE_HIDDEN);

                Intent i = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(i);
            }
        });

        mBottomSheetDialog = new BottomSheetDialog(this);
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    public void showNewItemBottomSheet(int state) {

        mBehavior.setState(state);

        final View view = getLayoutInflater().inflate(R.layout.choice_new_item_type_sheet_list, null);

        // Close

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        //

        MaterialRippleLayout mMakeVideoButton = view.findViewById(R.id.make_video_button);
        MaterialRippleLayout mChoiceVideoButton = view.findViewById(R.id.choice_video_button);
        MaterialRippleLayout mNewMarketItemButton = view.findViewById(R.id.new_market_item_button);

        // Market Item

        mChoiceVideoButton.setVisibility(View.GONE);
        mNewMarketItemButton.setVisibility(View.GONE);

        if (App.getInstance().getAppSettings().getMarketFeature()){

            mNewMarketItemButton.setVisibility(View.VISIBLE);
        }

        //

        mMakeVideoButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(MainActivity.this, CaptureActivity.class);
                captureActivityResultLauncher.launch(i);
            }
        });

        mChoiceVideoButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();
                //showAuthorizationBottomSheet(BottomSheetBehavior.STATE_HIDDEN);

                Intent i = new Intent(MainActivity.this, RegisterActivity.class);
                startActivity(i);
            }
        });

        mNewMarketItemButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(MainActivity.this, MarketNewItemActivity.class);
                captureActivityResultLauncher.launch(i);
            }
        });

        mBottomSheetDialog = new BottomSheetDialog(this);
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    private static void doKeepDialog(Dialog dialog){

        WindowManager.LayoutParams lp = new  WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);
    }

    private void updateNavItemCounter(NavigationView nav, @IdRes int itemId, int count) {

        TextView view = MenuItemCompat.getActionView(nav.getMenu().findItem(itemId)).findViewById(R.id.counter);
        view.setText(String.valueOf(count));

        if (count <= 0) {

            view.setVisibility(View.GONE);

        } else {

            view.setVisibility(View.VISIBLE);
        }
    }

    @Override public boolean dispatchTouchEvent(MotionEvent event){

        if (event.getAction() == MotionEvent.ACTION_DOWN) {

            if (mBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {

                Rect outRect = new Rect();
                mBottomSheet.getGlobalVisibleRect(outRect);

                if (!outRect.contains((int)event.getRawX(), (int)event.getRawY())) {

                    mBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
                }
            }

            View v = getCurrentFocus();

            if ( v instanceof EditText) {

                Rect outRect = new Rect();
                v.getGlobalVisibleRect(outRect);

                if (!outRect.contains((int)event.getRawX(), (int)event.getRawY())) {

                    v.clearFocus();

                    hideKeyboard();
                }
            }
        }

        return super.dispatchTouchEvent(event);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("restore", true);
        outState.putString("mTitle", getSupportActionBar().getTitle().toString());
        outState.putInt("pageId", pageId);
        getSupportFragmentManager().putFragment(outState, "currentFragment", fragment);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String permissions[], int[] grantResults) {

        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        fragment.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        // If the nav drawer is open, hide action items related to the content view
        return super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        getMenuInflater().inflate(R.menu.menu_main, menu);

        final MenuItem menuItem = menu.findItem(R.id.action_messenger);
        View actionView = MenuItemCompat.getActionView(menuItem);
        messenger_badge = actionView.findViewById(R.id.messenger_badge);

        menu.findItem(R.id.action_settings).setVisible(false);
        menu.findItem(R.id.action_search).setVisible(false);
        menu.findItem(R.id.action_messenger).setVisible(true);

        if (pageId == PAGE_PROFILE) {

            menu.findItem(R.id.action_settings).setVisible(true);
            menu.findItem(R.id.action_search).setVisible(true);
            menu.findItem(R.id.action_messenger).setVisible(false);
        }

        if (messenger_badge != null) {

            if (App.getInstance().getMessagesCount() == 0) {

                messenger_badge.setVisibility(View.GONE);

            } else {

                messenger_badge.setVisibility(View.VISIBLE);

                String count_txt = App.getInstance().getMessagesCount() + "";

                if (App.getInstance().getMessagesCount() > 9) count_txt = "9+";

                ((TextView) messenger_badge.findViewById(R.id.counter)).setText(count_txt);
            }
        }

        actionView.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                onOptionsItemSelected(menuItem);
            }
        });

        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        switch (item.getItemId()) {

            case android.R.id.home: {

                return true;
            }

            case R.id.action_messenger: {

                Intent i = new Intent(MainActivity.this, DialogsActivity.class);
                startActivity(i);

                return true;
            }

            case R.id.action_search: {

                Intent i = new Intent(MainActivity.this, FinderActivity.class);
                i.putExtra("tab_position", 1);
                startActivity(i);

                return true;
            }

            case R.id.action_settings: {

                Intent i = new Intent(MainActivity.this, SettingsActivity.class);
                startActivity(i);

                return true;
            }

            default: {

                return super.onOptionsItemSelected(item);
            }
        }
    }

    @Override
    public void setTitle(CharSequence title) {

        mTitle = title;
        getSupportActionBar().setTitle(mTitle);
    }

    @Override
    public void onBackPressed() {

        super.onBackPressed();
    }

    @Override
    protected void onResume() {

        super.onResume();

        refreshBadges();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            registerReceiver(mMessageReceiver, new IntentFilter(TAG_UPDATE_BADGES), RECEIVER_NOT_EXPORTED);
            registerReceiver(mAuthBottomSheetReceiver, new IntentFilter(TAG_SHOW_AUTH_BOTTOM_SHEET), RECEIVER_NOT_EXPORTED);

        } else {

            registerReceiver(mMessageReceiver, new IntentFilter(TAG_UPDATE_BADGES));
            registerReceiver(mAuthBottomSheetReceiver, new IntentFilter(TAG_SHOW_AUTH_BOTTOM_SHEET));
        }

        //

        Helper helper = new Helper(this);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            if (!helper.checkPermission(Manifest.permission.POST_NOTIFICATIONS)) {

                if (App.getInstance().getTooltipsSettings().isAllowShowNotificationsPermissionRequest()) {

                    notificationsPermissionLauncher.launch(Manifest.permission.POST_NOTIFICATIONS);
                }
            }
        }
    }

    @Override
    public void onPause() {

        super.onPause();

        unregisterReceiver(mMessageReceiver);
        unregisterReceiver(mAuthBottomSheetReceiver);
    }

    @Override
    public void onDestroy() {

        super.onDestroy();

        Log.e("tester", "MainActivity onDestroy");
    }

    @Override
    public void onUserInteraction() {

        super.onUserInteraction();

        if (getCurrentFocus() != null) {

            InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            imm.hideSoftInputFromWindow(getCurrentFocus().getWindowToken(), 0);

            getCurrentFocus().clearFocus();
        }
    }

    //This is the handler that will manager to process the broadcast intent
    private BroadcastReceiver mMessageReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            // Extract data included in the Intent
            // String message = intent.getStringExtra("message");

            refreshBadges();
        }
    };

    private BroadcastReceiver mAuthBottomSheetReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            // Extract data included in the Intent
            // String message = intent.getStringExtra("message");

            showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);
        }
    };
}
