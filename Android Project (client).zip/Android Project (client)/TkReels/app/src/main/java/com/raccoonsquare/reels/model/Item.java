package com.raccoonsquare.reels.model;

import android.app.Application;
import android.os.Parcel;
import android.os.Parcelable;
import android.util.Log;

import org.json.JSONObject;

import java.util.ArrayList;

import com.raccoonsquare.reels.constants.Constants;


public class Item extends Application implements Constants, Parcelable {

    private long id = 0, fromUserId = 0, rePostId = 0, groupId = 0, groupAuthor = 0;

    private long viewsCount = 0;
    private int imagesCount = 0, feeling = 0, createAt, likesCount = 0, commentsCount, rePostsCount, allowComments = 1, groupAllowComments, allowDownloadVideos = 1, accessMode = 0, fromUserVerify = 0, fromUserProfileType = 0;
    private String timeAgo, date, post = "", imgUrl = "", fromUserCompany = "", fromUserUsername, fromUserFullname, fromUserPhotoUrl, area, country = "", city = "", youTubeVideoImg, youTubeVideoCode, youTubeVideoUrl;
    private Double lat = 0.000000, lng = 0.000000;
    private Boolean myLike, myRePost;
    private Integer reaction = 0;

    private String urlPreviewTitle, urlPreviewImage, urlPreviewLink, urlPreviewDescription;

    private String previewVideoImgUrl = "", videoUrl = "";

    private int ad = 0;
    private int admin_account = 0;

    private int itemType = 0;

    private int rating = 0;

    private int restoreAt = 0, removeAt = 0, allowRestore = 0;

    private int pinned = 0;

    private ArrayList<MediaItem> mediaList = new ArrayList<>();

    private int privacyType = 0;
    private long soundId = 0, playlistId = 0;
    private Boolean myBookmark;
    private Boolean isFollow;

    private Sound sound;

    public Item() {

    }

    public Item(JSONObject jsonData) {

        try {

            if (!jsonData.getBoolean("error")) {

                this.setId(jsonData.getLong("id"));
                this.setFromUserId(jsonData.getLong("fromUserId"));
                this.setFromUserVerify(jsonData.getInt("fromUserVerify"));
                this.setFromUserUsername(jsonData.getString("fromUserUsername"));
                this.setFromUserFullname(jsonData.getString("fromUserFullname"));
                this.setFromUserPhotoUrl(jsonData.getString("fromUserPhoto"));

                if (jsonData.has("fromUserProfileType")) {

                    this.setFromUserProfileType(jsonData.getInt("fromUserProfileType"));
                }

                if (jsonData.has("fromUserCompany")) {

                    this.setFromUserCompany(jsonData.getString("fromUserCompany"));
                }

                this.setFromUserVerify(jsonData.getInt("fromUserVerify"));

                this.setPost(jsonData.getString("post"));
                this.setAllowComments(jsonData.getInt("allowComments"));
                this.setCommentsCount(jsonData.getInt("commentsCount"));
                this.setLikesCount(jsonData.getInt("likesCount"));
                this.setMyLike(jsonData.getBoolean("myLike"));
                this.setCreateAt(jsonData.getInt("createAt"));
                this.setDate(jsonData.getString("date"));
                this.setTimeAgo(jsonData.getString("timeAgo"));

                this.setVideoUrl(jsonData.getString("videoUrl"));
                this.setPreviewVideoImgUrl(jsonData.getString("previewVideoImgUrl"));

                if (jsonData.has("myLikeType")) {

                    this.setReaction(jsonData.getInt("myLikeType"));
                }

                if (jsonData.has("itemType")) {

                    this.setItemType(jsonData.getInt("itemType"));
                }

                if (jsonData.has("rating")) {

                    this.setRating(jsonData.getInt("rating"));
                }

                if (jsonData.has("feeling")) {

                    this.setFeeling(jsonData.getInt("feeling"));
                }

                if (jsonData.has("imagesCount")) {

                    this.setImagesCount(jsonData.getInt("imagesCount"));
                }

                if (jsonData.has("restoreAt")) {

                    this.setRestoreAt(jsonData.getInt("restoreAt"));
                }

                if (jsonData.has("removeAt")) {

                    this.setRemoveAt(jsonData.getInt("removeAt"));
                }

                if (jsonData.has("allowRestore")) {

                    this.setAllowRestore(jsonData.getInt("allowRestore"));
                }

                if (jsonData.has("pinned")) {

                    this.setPinned(jsonData.getInt("pinned"));
                }

                if (jsonData.has("viewsCount")) {

                    this.setViewsCount(jsonData.getLong("viewsCount"));
                }

                if (jsonData.has("soundId")) {

                    this.setSoundId(jsonData.getLong("soundId"));

                    if (this.getSoundId() != 0) {

                        if (jsonData.has("sound")) {

                            this.setSound(new Sound(jsonData.getJSONObject("sound")));
                        }
                    }
                }

                if (jsonData.has("playlistId")) {

                    this.setPlayListId(jsonData.getLong("playlistId"));
                }

                if (jsonData.has("privacyType")) {

                    this.setPrivacyType(jsonData.getInt("privacyType"));
                }

                if (jsonData.has("myBookmark")) {

                    this.setMyBookmark(jsonData.getBoolean("myBookmark"));
                }

                if (jsonData.has("isFollow")) {

                    this.setIsFollow(jsonData.getBoolean("isFollow"));
                }

                if (jsonData.has("allowDownloadVideos")) {

                    this.setAllowDownloadVideos(jsonData.getInt("allowDownloadVideos"));
                }
            }

        } catch (Throwable t) {

            Log.e("Item", "Could not parse malformed JSON: \"" + jsonData.toString() + "\"");

        } finally {

            Log.d("Item", jsonData.toString());
        }
    }

    protected Item(Parcel in) {
        id = in.readLong();
        fromUserId = in.readLong();
        rePostId = in.readLong();
        groupId = in.readLong();
        groupAuthor = in.readLong();
        viewsCount = in.readLong();
        imagesCount = in.readInt();
        feeling = in.readInt();
        createAt = in.readInt();
        likesCount = in.readInt();
        commentsCount = in.readInt();
        rePostsCount = in.readInt();
        allowComments = in.readInt();
        groupAllowComments = in.readInt();
        allowDownloadVideos = in.readInt();
        accessMode = in.readInt();
        fromUserVerify = in.readInt();
        fromUserProfileType = in.readInt();
        timeAgo = in.readString();
        date = in.readString();
        post = in.readString();
        imgUrl = in.readString();
        fromUserCompany = in.readString();
        fromUserUsername = in.readString();
        fromUserFullname = in.readString();
        fromUserPhotoUrl = in.readString();
        area = in.readString();
        country = in.readString();
        city = in.readString();
        youTubeVideoImg = in.readString();
        youTubeVideoCode = in.readString();
        youTubeVideoUrl = in.readString();
        if (in.readByte() == 0) {
            lat = null;
        } else {
            lat = in.readDouble();
        }
        if (in.readByte() == 0) {
            lng = null;
        } else {
            lng = in.readDouble();
        }
        byte tmpMyLike = in.readByte();
        myLike = tmpMyLike == 0 ? null : tmpMyLike == 1;
        byte tmpMyRePost = in.readByte();
        myRePost = tmpMyRePost == 0 ? null : tmpMyRePost == 1;
        if (in.readByte() == 0) {
            reaction = null;
        } else {
            reaction = in.readInt();
        }
        urlPreviewTitle = in.readString();
        urlPreviewImage = in.readString();
        urlPreviewLink = in.readString();
        urlPreviewDescription = in.readString();
        previewVideoImgUrl = in.readString();
        videoUrl = in.readString();
        ad = in.readInt();
        admin_account = in.readInt();
        itemType = in.readInt();
        rating = in.readInt();
        restoreAt = in.readInt();
        removeAt = in.readInt();
        allowRestore = in.readInt();
        pinned = in.readInt();
        mediaList = in.createTypedArrayList(MediaItem.CREATOR);
        privacyType = in.readInt();
        soundId = in.readLong();
        playlistId = in.readLong();
        byte tmpMyBookmark = in.readByte();
        myBookmark = tmpMyBookmark == 0 ? null : tmpMyBookmark == 1;
        byte tmpIsFollow = in.readByte();
        isFollow = tmpIsFollow == 0 ? null : tmpIsFollow == 1;
        sound = in.readParcelable(Sound.class.getClassLoader());
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeLong(id);
        dest.writeLong(fromUserId);
        dest.writeLong(rePostId);
        dest.writeLong(groupId);
        dest.writeLong(groupAuthor);
        dest.writeLong(viewsCount);
        dest.writeInt(imagesCount);
        dest.writeInt(feeling);
        dest.writeInt(createAt);
        dest.writeInt(likesCount);
        dest.writeInt(commentsCount);
        dest.writeInt(rePostsCount);
        dest.writeInt(allowComments);
        dest.writeInt(groupAllowComments);
        dest.writeInt(allowDownloadVideos);
        dest.writeInt(accessMode);
        dest.writeInt(fromUserVerify);
        dest.writeInt(fromUserProfileType);
        dest.writeString(timeAgo);
        dest.writeString(date);
        dest.writeString(post);
        dest.writeString(imgUrl);
        dest.writeString(fromUserCompany);
        dest.writeString(fromUserUsername);
        dest.writeString(fromUserFullname);
        dest.writeString(fromUserPhotoUrl);
        dest.writeString(area);
        dest.writeString(country);
        dest.writeString(city);
        dest.writeString(youTubeVideoImg);
        dest.writeString(youTubeVideoCode);
        dest.writeString(youTubeVideoUrl);
        if (lat == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(lat);
        }
        if (lng == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeDouble(lng);
        }
        dest.writeByte((byte) (myLike == null ? 0 : myLike ? 1 : 2));
        dest.writeByte((byte) (myRePost == null ? 0 : myRePost ? 1 : 2));
        if (reaction == null) {
            dest.writeByte((byte) 0);
        } else {
            dest.writeByte((byte) 1);
            dest.writeInt(reaction);
        }
        dest.writeString(urlPreviewTitle);
        dest.writeString(urlPreviewImage);
        dest.writeString(urlPreviewLink);
        dest.writeString(urlPreviewDescription);
        dest.writeString(previewVideoImgUrl);
        dest.writeString(videoUrl);
        dest.writeInt(ad);
        dest.writeInt(admin_account);
        dest.writeInt(itemType);
        dest.writeInt(rating);
        dest.writeInt(restoreAt);
        dest.writeInt(removeAt);
        dest.writeInt(allowRestore);
        dest.writeInt(pinned);
        dest.writeTypedList(mediaList);
        dest.writeInt(privacyType);
        dest.writeLong(soundId);
        dest.writeLong(playlistId);
        dest.writeByte((byte) (myBookmark == null ? 0 : myBookmark ? 1 : 2));
        dest.writeByte((byte) (isFollow == null ? 0 : isFollow ? 1 : 2));
        dest.writeParcelable(sound, flags);
    }

    @Override
    public int describeContents() {
        return 0;
    }

    public static final Creator<Item> CREATOR = new Creator<Item>() {
        @Override
        public Item createFromParcel(Parcel in) {
            return new Item(in);
        }

        @Override
        public Item[] newArray(int size) {
            return new Item[size];
        }
    };

    public int getItemType() {

        return this.itemType;
    }

    public void setItemType(int itemType) {

        this.itemType = itemType;
    }

    public int getRating() {

        return this.rating;
    }

    public void setRating(int rating) {

        this.rating = rating;
    }

    public int getReaction() {

        return this.reaction;
    }

    public void setReaction(int reaction) {

        this.reaction = reaction;
    }

    public int getAd() {

        return this.ad;
    }

    public void setAd(int ad) {

        this.ad = ad;
    }

    public int getAdminAccount() {

        return this.admin_account;
    }

    public void setAdminAccount(int admin_account) {

        this.admin_account = admin_account;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public long getRePostId() {

        return this.rePostId;
    }

    public void setRePostId(long rePostId) {

        this.rePostId = rePostId;
    }

    public long getFromUserId() {

        return fromUserId;
    }

    public void setFromUserId(long fromUserId) {

        this.fromUserId = fromUserId;
    }

    public long getGroupId() {

        return this.groupId;
    }

    public void setGroupId(long groupId) {

        this.groupId = groupId;
    }

    public long getGroupAuthor() {

        return this.groupAuthor;
    }

    public void setGroupAuthor(long groupAuthor) {

        this.groupAuthor = groupAuthor;
    }

    public int getAccessMode() {

        return accessMode;
    }

    public void setAccessMode(int accessMode) {

        this.accessMode = accessMode;
    }

    public int getFromUserVerify() {

        return fromUserVerify;
    }

    public void setFromUserProfileType(int fromUserProfileType) {

        this.fromUserProfileType = fromUserProfileType;
    }

    public int getFromUserProfileType() {

        return fromUserProfileType;
    }

    public void setFromUserVerify(int fromUserVerify) {

        this.fromUserVerify = fromUserVerify;
    }

    public int getAllowComments() {

        return allowComments;
    }

    public void setAllowComments(int allowComments) {
        this.allowComments = allowComments;
    }

    public int getGroupAllowComments() {

        return this.groupAllowComments;
    }

    public void setGroupAllowComments(int groupAllowComments) {
        this.groupAllowComments = groupAllowComments;
    }

    public int getCommentsCount() {

        return commentsCount;
    }

    public void setCommentsCount(int commentsCount) {
        this.commentsCount = commentsCount;
    }

    public int getLikesCount() {

        return this.likesCount;
    }

    public void setLikesCount(int likesCount) {
        this.likesCount = likesCount;
    }

    public long getViewsCount() {

        return this.viewsCount;
    }

    public void setViewsCount(long viewsCount) {
        this.viewsCount = viewsCount;
    }

    public int getRePostsCount() {

        return this.rePostsCount;
    }

    public void setRePostsCount(int rePostsCount) {
        this.rePostsCount = rePostsCount;
    }

    public int getFeeling() {

        return feeling;
    }

    public void setFeeling(int feeling) {

        this.feeling = feeling;
    }

    public int getImagesCount() {

        return this.imagesCount;
    }

    public void setImagesCount(int imagesCount) {

        this.imagesCount = imagesCount;
    }

    public void setCreateAt(int createAt) {

        this.createAt = createAt;
    }

    public int getCreateAt() {

        return createAt;
    }


    public int getRestoreAt() {

        return restoreAt;
    }

    public void setRestoreAt(int restoreAt) {

        this.restoreAt = restoreAt;
    }

    public int getRemoveAt() {

        return removeAt;
    }

    public void setRemoveAt(int removeAt) {

        this.removeAt = removeAt;
    }

    public int getAllowRestore() {

        return allowRestore;
    }

    public void setAllowRestore(int allowRestore) {

        this.allowRestore = allowRestore;
    }

    public int getPinned() {

        return this.pinned;
    }

    public void setPinned(int pinned) {

        this.pinned = pinned;
    }

    public String getTimeAgo() {

        return timeAgo;
    }

    public void setTimeAgo(String timeAgo) {

        this.timeAgo = timeAgo;
    }

    public String getYouTubeVideoImg() {

        if (this.youTubeVideoImg == null) {

            this.youTubeVideoImg = "";
        }

        return this.youTubeVideoImg;
    }

    public void setYouTubeVideoImg(String youTubeVideoImg) {

        this.youTubeVideoImg = youTubeVideoImg;
    }

    public String getYouTubeVideoCode() {

        if (this.youTubeVideoCode == null) {

            this.youTubeVideoCode = "";
        }

        return this.youTubeVideoCode;
    }

    public void setYouTubeVideoCode(String youTubeVideoCode) {

        this.youTubeVideoCode = youTubeVideoCode;
    }

    public String getYouTubeVideoUrl() {

        if (this.youTubeVideoUrl == null) {

            this.youTubeVideoUrl = "";
        }

        return this.youTubeVideoUrl;
    }

    public void setYouTubeVideoUrl(String youTubeVideoUrl) {

        this.youTubeVideoUrl = youTubeVideoUrl;
    }

    public String getVideoUrl() {

        if (this.videoUrl == null) {

            this.videoUrl = "";
        }

        return this.videoUrl;
    }

    public void setVideoUrl(String videoUrl) {

        this.videoUrl = videoUrl;
    }

    public String getPreviewVideoImgUrl() {

        if (this.previewVideoImgUrl == null) {

            this.previewVideoImgUrl = "";
        }

        return this.previewVideoImgUrl;
    }

    public void setPreviewVideoImgUrl(String previewVideoImgUrl) {

        this.previewVideoImgUrl = previewVideoImgUrl;
    }




    public String getUrlPreviewTitle() {

        return urlPreviewTitle;
    }

    public void setUrlPreviewTitle(String urlPreviewTitle) {

        this.urlPreviewTitle = urlPreviewTitle;
    }

    public String getUrlPreviewImage() {

        if (this.urlPreviewImage == null) {

            this.urlPreviewImage = "";
        }

        return this.urlPreviewImage;
    }

    public void setUrlPreviewImage(String urlPreviewImage) {

        this.urlPreviewImage = urlPreviewImage;
    }

    public String getUrlPreviewLink() {

        if (this.urlPreviewLink == null) {

            this.urlPreviewLink = "";
        }

        return this.urlPreviewLink;
    }

    public void setUrlPreviewLink(String urlPreviewLink) {

        this.urlPreviewLink = urlPreviewLink;
    }

    public String getUrlPreviewDescription() {

        if (this.urlPreviewDescription == null) {

            this.urlPreviewDescription = "";
        }

        return this.urlPreviewDescription;
    }

    public void setUrlPreviewDescription(String urlPreviewDescription) {

        this.urlPreviewDescription = urlPreviewDescription;
    }

    public String getPost() {

        if (this.post == null) {

            this.post = "";
        }

        return this.post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getFromUserUsername() {
        return fromUserUsername;
    }

    public void setFromUserUsername(String fromUserUsername) {
        this.fromUserUsername = fromUserUsername;
    }

    public String getFromUserCompany() {
        return fromUserCompany;
    }

    public void setFromUserCompany(String fromUserCompany) {

        this.fromUserCompany = fromUserCompany;
    }

    public String getFromUserFullname() {

        return fromUserFullname;
    }

    public void setFromUserFullname(String fromUserFullname) {
        this.fromUserFullname = fromUserFullname;
    }

    public String getFromUserPhotoUrl() {

        if (fromUserPhotoUrl == null) {

            fromUserPhotoUrl = "";
        }

        return fromUserPhotoUrl;
    }

    public void setFromUserPhotoUrl(String fromUserPhotoUrl) {
        this.fromUserPhotoUrl = fromUserPhotoUrl;
    }

    public Boolean isMyLike() {
        return myLike;
    }

    public void setMyLike(Boolean myLike) {

        this.myLike = myLike;
    }

    public Boolean isMyRePost() {
        return myRePost;
    }

    public void setMyRePost(Boolean myRePost) {

        this.myRePost = myRePost;
    }

    public String getImgUrl() {

        if (this.imgUrl == null) {

            this.imgUrl = "";
        }

        return imgUrl;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public String getDate() {

        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getArea() {

        if (this.area == null) {

            this.area = "";
        }

        return this.area;
    }

    public void setArea(String area) {

        this.area = area;
    }

    public String getCountry() {

        if (this.country == null) {

            this.country = "";
        }

        return this.country;
    }

    public void setCountry(String country) {

        this.country = country;
    }

    public String getCity() {

        if (this.city == null) {

            this.city = "";
        }

        return this.city;
    }

    public void setCity(String city) {

        this.city = city;
    }

    public Double getLat() {

        return this.lat;
    }

    public void setLat(Double lat) {

        this.lat = lat;
    }

    public Double getLng() {

        return this.lng;
    }

    public void setLng(Double lng) {

        this.lng = lng;
    }

    public String getLink() {

        return WEB_SITE + this.getFromUserUsername() + "/post/" + Long.toString(this.getId());
    }

    public ArrayList<MediaItem> getMediaList() {

        return this.mediaList;
    }

    public void setMediaList(ArrayList<MediaItem> mediaList) {

        this.mediaList = mediaList;
    }

    public long getSoundId() {

        return this.soundId;
    }

    public void setSoundId(long soundId) {

        this.soundId = soundId;
    }

    public Sound getSound() {

        return this.sound;
    }

    public void setSound(Sound sound) {

        this.sound = sound;
    }

    public long getPlayListId() {

        return this.playlistId;
    }

    public void setPlayListId(long playlistId) {

        this.playlistId = playlistId;
    }

    public int getPrivacyType() {

        return this.privacyType;
    }

    public void setPrivacyType(int privacyType) {

        this.privacyType = privacyType;
    }

    public Boolean isMyBookmark() {
        return myBookmark;
    }

    public void setMyBookmark(Boolean myBookmark) {

        this.myBookmark = myBookmark;
    }

    public Boolean getIsFollow() {

        return isFollow;
    }

    public void setIsFollow(Boolean isFollow) {

        this.isFollow = isFollow;
    }

    public void setAllowDownloadVideos(int allowDownloadVideos) {

        this.allowDownloadVideos = allowDownloadVideos;
    }

    public int getAllowDownloadVideos() {

        return this.allowDownloadVideos;
    }
}
