package com.raccoonsquare.reels.app;

import android.app.Application;
import android.util.Log;

import com.raccoonsquare.reels.constants.Constants;

import org.json.JSONObject;

import co.paystack.android.PaystackSdk;

public class PaymentsSettings extends Application implements Constants {

	public static final String TAG = PaymentsSettings.class.getSimpleName();

    // Paystack

    private int paystack_enabled = 0;
    private String sk_paystack = "";
    private String pk_paystack = "";
    private String currency_paystack = "NGN";
    private int count_paystack = 30;
    private int price_paystack = 100000;

    // Stripe

    private int stripe_enabled = 0;
    private String sk_stripe = "";
    private String pk_stripe = "";
    private String currency_stripe = "USD";
    private int count_stripe = 30;
    private int price_stripe = 100;

	@Override
	public void onCreate() {

		super.onCreate();
	}

    public void read_from_json(JSONObject jsonData) {

        try {

            // Paystack

            if (jsonData.has("paystack_enabled")) {

                this.setPaystackEnabled(jsonData.getInt("paystack_enabled"));
            }

            if (jsonData.has("pk_paystack")) {

                this.setPkPaystack(jsonData.getString("pk_paystack"));
            }

            if (jsonData.has("currency_paystack")) {

                this.setPaystackCurrency(jsonData.getString("currency_paystack"));
            }

            if (jsonData.has("count_paystack")) {

                this.setPaystackCount(jsonData.getInt("count_paystack"));
            }

            if (jsonData.has("price_paystack")) {

                this.setPaystackPrice(jsonData.getInt("price_paystack"));
            }

            // Stripe

            if (jsonData.has("stripe_enabled")) {

                this.setStripeEnabled(jsonData.getInt("stripe_enabled"));
            }

            if (jsonData.has("currency_stripe")) {

                this.setStripeCurrency(jsonData.getString("currency_stripe"));
            }

            if (jsonData.has("count_stripe")) {

                this.setStripeCount(jsonData.getInt("count_stripe"));
            }

            if (jsonData.has("price_stripe")) {

                this.setStripePrice(jsonData.getInt("price_stripe"));
            }

        } catch (Throwable t) {

            Log.e("PaymentsSettings", "Could not parse malformed JSON: \"" + jsonData.toString() + "\"");

        } finally {

            Log.e("PaymentsSettings", "");

            if (this.getPaystackEnabled() == 1) {

                Log.e("PaymentsSettings", "Paystack Initialize....");

                PaystackSdk.initialize(App.getInstance().getApplicationContext());
                PaystackSdk.setPublicKey(this.getPkPaystack());
            }
        }
    }

    // Paystack

    public void setPaystackEnabled(int value) {

        this.paystack_enabled = value;
    }

    public int getPaystackEnabled() {

        return this.paystack_enabled;
    }

    public void setPkPaystack(String pk_paystack) {

        this.pk_paystack = pk_paystack;
    }

    public String getPkPaystack() {

        return this.pk_paystack;
    }

    public void setPaystackCurrency(String currency_paystack) {

        this.currency_paystack = currency_paystack;
    }

    public String getPaystackCurrency() {

        return this.currency_paystack;
    }

    public void setPaystackCount(int count_paystack) {

        this.count_paystack = count_paystack;
    }

    public int getPaystackCount() {

        return this.count_paystack;
    }

    public void setPaystackPrice(int price_paystack) {

        this.price_paystack = price_paystack;
    }

    public int getPaystackPrice() {

        return this.price_paystack;
    }

    // Stripe

    public void setStripeEnabled(int value) {

        this.stripe_enabled = value;
    }

    public int getStripeEnabled() {

        return this.stripe_enabled;
    }

    public void setStripeCurrency(String currency_stripe) {

        this.currency_stripe = currency_stripe;
    }

    public String getStripeCurrency() {

        return this.currency_stripe;
    }

    public void setStripeCount(int count_stripe) {

        this.count_stripe = count_stripe;
    }

    public int getStripeCount() {

        return this.count_stripe;
    }

    public void setStripePrice(int price_stripe) {

        this.price_stripe = price_stripe;
    }

    public int getStripePrice() {

        return this.price_stripe;
    }
}