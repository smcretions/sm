package com.raccoonsquare.reels;

import android.app.Activity;
import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.drawable.Drawable;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.balysv.materialripple.MaterialRippleLayout;
import com.raccoonsquare.reels.adapter.AdvancedItemListAdapterV2;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Item;
import com.raccoonsquare.reels.util.Api;
import com.raccoonsquare.reels.util.CustomRequest;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.floatingactionbutton.FloatingActionButton;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class SoundsFragment extends Fragment implements Constants, SwipeRefreshLayout.OnRefreshListener {

    private static final String STATE_LIST = "State Adapter Data";

    private RecyclerView mRecyclerView;
    private NestedScrollView mNestedView;

    private SwipeRefreshLayout mItemsContainer;

    private BottomSheetBehavior mBehavior;
    private BottomSheetDialog mBottomSheetDialog;
    private View mBottomSheet;

    private TextView mMessage;
    private ImageView mSplash;

    private FloatingActionButton mFabButton;

    //

    LinearLayout mInfoHeader;
    ImageView mInfoHeaderImage, mInfoHeaderStatusImage;
    TextView mInfoHeaderTitle, mInfoHeaderDesc, mInfoHeaderCounter;

    //

    private ArrayList<Item> itemsList;
    private AdvancedItemListAdapterV2 itemsAdapter;

    private int itemId = 0;
    private int arrayLength = 0;
    private Boolean loadingMore = false;
    private Boolean viewMore = false;
    private Boolean restore = false;

    private long soundId = 0;
    private String soundTitle = "", soundDesc = "", soundUrl = "", soundImgUrl = "";

    private MediaPlayer mediaPlayer;

    ImageLoader imageLoader = App.getInstance().getImageLoader();

    private ActivityResultLauncher<Intent> captureActivityResultLauncher;

    public SoundsFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        if (imageLoader == null) {

            imageLoader = App.getInstance().getImageLoader();
        }

        setHasOptionsMenu(false);

        if (savedInstanceState != null) {

            itemsList = savedInstanceState.getParcelableArrayList(STATE_LIST);
            itemsAdapter = new AdvancedItemListAdapterV2(getActivity(), itemsList);

            restore = savedInstanceState.getBoolean("restore");
            itemId = savedInstanceState.getInt("itemId");
            soundId = savedInstanceState.getLong("soundId");
            soundTitle = savedInstanceState.getString("soundTitle");
            soundDesc = savedInstanceState.getString("soundDesc");
            soundUrl = savedInstanceState.getString("soundUrl");

        } else {

            itemsList = new ArrayList<Item>();
            itemsAdapter = new AdvancedItemListAdapterV2(getActivity(), itemsList);

            restore = false;
            itemId = 0;
            soundId = 0;

            Intent i = getActivity().getIntent();

            soundId = i.getLongExtra("soundId", 0);
            soundTitle = i.getStringExtra("soundTitle");
            soundDesc = i.getStringExtra("soundDesc");
            soundUrl = i.getStringExtra("soundUrl");
            soundImgUrl = i.getStringExtra("soundImgUrl");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_sounds, container, false);

        //

        captureActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == 100) {

                    Log.e("Dimon", "run new item");

                    Intent i = new Intent(getActivity(), NewItemActivity.class);
                    startActivity(i);
                }
            }
        });

        //

        mItemsContainer = (SwipeRefreshLayout) rootView.findViewById(R.id.container_items);
        mItemsContainer.setOnRefreshListener(this);

        //

        mMessage = (TextView) rootView.findViewById(R.id.message);
        mSplash = (ImageView) rootView.findViewById(R.id.splash);

        // Prepare bottom sheet

        mBottomSheet = rootView.findViewById(R.id.bottom_sheet);
        mBehavior = BottomSheetBehavior.from(mBottomSheet);

        //

        mFabButton = (FloatingActionButton) rootView.findViewById(R.id.fab_button);
        mFabButton.setImageResource(R.drawable.ic_capture_start);
        mFabButton.setVisibility(View.GONE);

        if (App.getInstance().getId() != 0) {

            mFabButton.setVisibility(View.VISIBLE);
        }

        mFabButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), CaptureActivity.class);
                i.putExtra("soundId", soundId);
                i.putExtra("soundTitle", soundTitle);
                i.putExtra("soundUrl", soundUrl);
                captureActivityResultLauncher.launch(i);
            }
        });

        //

        mInfoHeader = rootView.findViewById(R.id.info_header);
        mInfoHeader.setVisibility(View.GONE);

        mInfoHeaderStatusImage = rootView.findViewById(R.id.info_header_status_image);
        mInfoHeaderImage = rootView.findViewById(R.id.info_header_image);
        mInfoHeaderImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (mediaPlayer != null) {

                    stopMp3();

                } else {

                    playMp3(soundUrl);
                }
            }
        });

        mInfoHeaderTitle = rootView.findViewById(R.id.info_header_title);
        mInfoHeaderCounter = rootView.findViewById(R.id.info_header_counter);
        mInfoHeaderDesc = rootView.findViewById(R.id.info_header_desc);
        mInfoHeaderDesc.setVisibility(View.GONE);

        //

        mNestedView = (NestedScrollView) rootView.findViewById(R.id.nested_view);

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);

        itemsAdapter.setOnItemClickListener(new AdvancedItemListAdapterV2.OnItemClickListener() {

            @Override
            public void onItemClick(View view, Item obj, int position) {

                App.getInstance().getHomeItemsList().clear();
                App.getInstance().setHomeItemsList((ArrayList<Item>)itemsList.clone());

                Intent intent = new Intent(getActivity(), HomeActivity.class);
                intent.putExtra("position", position);
                startActivity(intent);
            }
        });

        final GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 3);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(itemsAdapter);

        mRecyclerView.setNestedScrollingEnabled(false);

        mNestedView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {

            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY < oldScrollY) { // up


                }

                if (scrollY > oldScrollY) { // down


                }

                if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {

                    if (!loadingMore && (viewMore) && !(mItemsContainer.isRefreshing())) {

                        mItemsContainer.setRefreshing(true);

                        loadingMore = true;

                        getItems();
                    }
                }
            }
        });

        if (itemsAdapter.getItemCount() == 0) {

            showMessage(getText(R.string.label_empty_list).toString());

        } else {

            hideMessage();
        }

        if (soundTitle != null) {

            getActivity().setTitle(soundTitle);
        }

        if (!restore) {

            showMessage(getText(R.string.msg_loading_2).toString());

            getItems();
        }

        return rootView;
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("restore", true);
        outState.putInt("itemId", itemId);
        outState.putLong("soundId", soundId);
        outState.putString("soundTitle", soundTitle);
        outState.putString("soundDesc", soundDesc);
        outState.putString("soundUrl", soundUrl);
        outState.putParcelableArrayList(STATE_LIST, itemsList);
    }

    @Override
    public void onRefresh() {

        if (App.getInstance().isConnected()) {

            itemId = 0;
            getItems();

        } else {

            mItemsContainer.setRefreshing(false);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ITEM_EDIT && resultCode == getActivity().RESULT_OK) {

            int position = data.getIntExtra("position", 0);

            if (data.getExtras() != null) {

                Item item = (Item) data.getExtras().getParcelable("item");

                itemsList.set(position, item);
            }

            itemsAdapter.notifyDataSetChanged();

        } else if (requestCode == ITEM_REPOST && resultCode == getActivity().RESULT_OK) {

            int position = data.getIntExtra("position", 0);

            Item item = itemsList.get(position);

            item.setMyRePost(true);
            item.setRePostsCount(item.getRePostsCount() + 1);

            itemsAdapter.notifyDataSetChanged();
        }
    }

    public void getItems() {

        mItemsContainer.setRefreshing(true);

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_SOUND_GET_VIDEOS, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "SoundsFragment Not Added to Activity");

                            return;
                        }

                        if (!loadingMore) {

                            itemsList.clear();
                        }

                        try {

                            arrayLength = 0;

                            if (!response.getBoolean("error")) {

                                itemId = response.getInt("itemId");

                                if (response.has("items")) {

                                    JSONArray itemsArray = response.getJSONArray("items");

                                    arrayLength = itemsArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < itemsArray.length(); i++) {

                                            JSONObject itemObj = (JSONObject) itemsArray.get(i);
                                            Item item = new Item(itemObj);
                                            item.setAd(0);

                                            itemsList.add(item);

                                            itemsAdapter.notifyItemChanged(itemsList.size());
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "SoundsFragment Not Added to Activity");

                    return;
                }

                loadingComplete();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("itemId", Long.toString(itemId));
                params.put("language", "en");
                params.put("soundId", Long.toString(soundId));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void loadingComplete() {

        if (arrayLength == LIST_ITEMS) {

            viewMore = true;

        } else {

            viewMore = false;
        }

        if (itemsAdapter.getItemCount() == 0) {

            if (isAdded()) {

                showMessage(getText(R.string.label_empty_list).toString());
            }

        } else {

            hideMessage();
        }

        loadingMore = false;
        mItemsContainer.setRefreshing(false);

        getActivity().invalidateOptionsMenu();

        mInfoHeaderTitle.setText(soundTitle);
        mInfoHeaderCounter.setText(Integer.toString(itemsAdapter.getItemCount()) + " " + getString(R.string.label_videos));

        if (soundDesc.length() != 0) {

            mInfoHeaderDesc.setText(soundDesc);
            mInfoHeaderDesc.setVisibility(View.VISIBLE);
        }

        imageLoader.get(soundImgUrl, ImageLoader.getImageListener(mInfoHeaderImage, R.drawable.def_photo, R.drawable.def_photo));

        mInfoHeader.setVisibility(View.VISIBLE);
    }

    //

    private void playMp3(String url) {

        stopMp3();

        if (mediaPlayer == null) {

            mInfoHeaderStatusImage.setImageResource(R.drawable.ic_capture_stop_3);

            mediaPlayer = MediaPlayer.create(getActivity(), Uri.parse(url));
            mediaPlayer.start();

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer mp) {

                    if (mediaPlayer != null) {

                        try {

                            stopMp3();

                        } catch (Exception e) {

                            e.printStackTrace();
                        }
                    }
                }
            });
        }
    }

    private void stopMp3() {

        Log.e("stopMp3", "stopMp3");

        mInfoHeaderStatusImage.setImageResource(R.drawable.ic_play_2);

        if (mediaPlayer != null) {

            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {

        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            default: {

                return super.onOptionsItemSelected(item);
            }
        }
    }

    //

    public void showMessage(String message) {

        mMessage.setText(message);
        mMessage.setVisibility(View.VISIBLE);

        mSplash.setVisibility(View.VISIBLE);
    }

    public void hideMessage() {

        mMessage.setVisibility(View.GONE);

        mSplash.setVisibility(View.GONE);
    }

    @Override
    public void onStart() {

        super.onStart();

        getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onStop() {

        super.onStop();

        stopMp3();

        getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}