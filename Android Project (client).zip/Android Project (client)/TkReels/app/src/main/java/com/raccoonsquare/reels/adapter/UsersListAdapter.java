package com.raccoonsquare.reels.adapter;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.bumptech.glide.Glide;
import com.bumptech.glide.load.DataSource;
import com.bumptech.glide.load.engine.GlideException;
import com.bumptech.glide.request.RequestListener;
import com.bumptech.glide.request.target.Target;

import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Profile;
import com.raccoonsquare.reels.util.CustomRequest;
import com.mikhaellopez.circularimageview.CircularImageView;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class UsersListAdapter extends RecyclerView.Adapter<UsersListAdapter.ViewHolder> implements Constants {

    private Context ctx;
    private List<Profile> items;
    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {

        void onItemClick(View view, Profile item, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {

        this.mOnItemClickListener = mItemClickListener;
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView fullname, username, nearby;
        public CircularImageView image, online, verified;
        public Button button;
        public LinearLayout parent;

        public ViewHolder(View view) {

            super(view);

            fullname = (TextView) view.findViewById(R.id.fullname);
            username = (TextView) view.findViewById(R.id.username);
            nearby = (TextView) view.findViewById(R.id.nearby);
            image = (CircularImageView) view.findViewById(R.id.image);
            parent = (LinearLayout) view.findViewById(R.id.parent);

            button = (Button) view.findViewById(R.id.action_button);

            online = (CircularImageView) view.findViewById(R.id.online);
            verified = (CircularImageView) view.findViewById(R.id.verified);
        }
    }

    public UsersListAdapter(Context mContext, List<Profile> items) {

        this.ctx = mContext;
        this.items = items;
    }

    @Override
    public ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

        View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_user_list_row, parent, false);

        return new ViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(final ViewHolder holder, final int position) {

        final Profile item = items.get(position);

        holder.online.setVisibility(View.GONE);
        holder.verified.setVisibility(View.GONE);

        if (item.getNormalPhotoUrl() != null && item.getNormalPhotoUrl().length() > 0) {

            final ImageView img = holder.image;

            try {

                Glide.with(ctx)
                        .load(item.getNormalPhotoUrl())
                        .listener(new RequestListener<Drawable>() {
                            @Override
                            public boolean onLoadFailed(@Nullable GlideException e, Object model, Target<Drawable> target, boolean isFirstResource) {

                                img.setImageResource(R.drawable.profile_default_photo);
                                img.setVisibility(View.VISIBLE);
                                return false;
                            }

                            @Override
                            public boolean onResourceReady(Drawable resource, Object model, Target<Drawable> target, DataSource dataSource, boolean isFirstResource) {

                                img.setVisibility(View.VISIBLE);
                                return false;
                            }
                        })
                        .into(holder.image);

            } catch (Exception e) {

                Log.e("ListAdapter", e.toString());
            }

        } else {

            holder.image.setImageResource(R.drawable.profile_default_photo);
        }

        holder.nearby.setVisibility(View.GONE);

        if (item.getDistance() != 0) {

            holder.nearby.setVisibility(View.VISIBLE);
            holder.nearby.setText(Double.toString(item.getDistance()) + "km");
        }

        holder.verified.setVisibility(View.GONE);

        if (item.getVerified() == 1) {

            holder.verified.setVisibility(View.VISIBLE);
        }

        holder.online.setVisibility(View.GONE);

        if (item.isOnline()) {

            holder.online.setVisibility(View.VISIBLE);
        }

        holder.button.setVisibility(View.GONE);

        if (item.getId() != App.getInstance().getId()) {

            holder.button.setVisibility(View.VISIBLE);

            if (item.isFollow()) {

                holder.button.setTextColor(ctx.getResources().getColor(R.color.colorWhiteButtonText));
                holder.button.setBackgroundResource(R.drawable.button_white_rounded);
                holder.button.setText(ctx.getString(R.string.action_unfollow));

            } else {

                holder.button.setTextColor(ctx.getResources().getColor(R.color.colorPrimaryButtonText));
                holder.button.setBackgroundResource(R.drawable.button_primary_rounded);
                holder.button.setText(ctx.getString(R.string.action_follow));
            }

            holder.button.setPadding(16, 16, 16, 16);
        }

        holder.button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (item.isFollow()) {

                    holder.button.setTextColor(ctx.getResources().getColor(R.color.colorPrimaryButtonText));
                    holder.button.setBackgroundResource(R.drawable.button_primary_rounded);
                    holder.button.setText(ctx.getString(R.string.action_follow));

                } else {

                    holder.button.setTextColor(ctx.getResources().getColor(R.color.colorWhiteButtonText));
                    holder.button.setBackgroundResource(R.drawable.button_white_rounded);
                    holder.button.setText(ctx.getString(R.string.action_unfollow));
                }

                holder.button.setPadding(16, 16, 16, 16);

                addFollower(item, position);
            }
        });

        holder.fullname.setText(item.getFullname());
        holder.username.setText("@" + item.getUsername());

        holder.parent.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (mOnItemClickListener != null) {

                    mOnItemClickListener.onItemClick(v, items.get(position), position);
                }
            }
        });
    }

    public Profile getItem(int position) {

        return items.get(position);
    }

    @Override
    public int getItemCount() {

        return items.size();
    }

    public void addFollower(Profile profile, int position) {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_PROFILE_FOLLOW, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {

                                profile.setFollow(response.getBoolean("follow"));
                                profile.setFollowersCount(response.getInt("followersCount"));

                                if (profile.isFollow()) {

                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            notifyItemChanged(position);
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                notifyItemChanged(position);
            }
        }) {

            @Override
            protected Map<String, String> getParams() {

                Map<String, String> params = new HashMap<String, String>();

                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());

                params.put("profileId", Long.toString(profile.getId()));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }
}