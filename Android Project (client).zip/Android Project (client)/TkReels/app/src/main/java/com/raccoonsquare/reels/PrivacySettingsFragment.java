package com.raccoonsquare.reels;

import android.app.ProgressDialog;
import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;

import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreference;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.util.CustomRequest;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class PrivacySettingsFragment extends PreferenceFragmentCompat implements Constants {

    private SwitchPreference mAllowMessages, mAllowVideoCalls, mAllowShowLikedVideos, mAllowDownloadVideos;

    private ProgressDialog pDialog;

    private Boolean loading = false;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {

        initpDialog();

        setPreferencesFromResource(R.xml.privacy_settings, rootKey);

        mAllowMessages = (SwitchPreference) getPreferenceManager().findPreference("allowMessages");

        if (App.getInstance().getAccount().getAllowMessages() == 1) {

            mAllowMessages.setChecked(true);

        } else {

            mAllowMessages.setChecked(false);
        }

        mAllowMessages.setOnPreferenceChangeListener(new androidx.preference.Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(androidx.preference.Preference preference, Object newValue) {

                if (newValue instanceof Boolean) {

                    Boolean value = (Boolean) newValue;

                    if (value) {

                        App.getInstance().getAccount().setAllowMessages(1);

                    } else {

                        App.getInstance().getAccount().setAllowMessages(0);
                    }

                    saveSettings();
                }

                return true;
            }
        });

        mAllowVideoCalls = (SwitchPreference) getPreferenceManager().findPreference("allowVideoCalls");

        if (App.getInstance().getAccount().getAllowVideoCalls() == 1) {

            mAllowVideoCalls.setChecked(true);

        } else {

            mAllowVideoCalls.setChecked(false);
        }

        mAllowVideoCalls.setOnPreferenceChangeListener(new androidx.preference.Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(androidx.preference.Preference preference, Object newValue) {

                if (newValue instanceof Boolean) {

                    Boolean value = (Boolean) newValue;

                    if (value) {

                        App.getInstance().getAccount().setAllowVideoCalls(1);

                    } else {

                        App.getInstance().getAccount().setAllowVideoCalls(0);
                    }

                    saveSettings();
                }

                return true;
            }
        });

        mAllowShowLikedVideos = (SwitchPreference) getPreferenceManager().findPreference("allowShowLikedVideos");

        if (App.getInstance().getAccount().getAllowShowLikedVideos() == 1) {

            mAllowShowLikedVideos.setChecked(true);

        } else {

            mAllowShowLikedVideos.setChecked(false);
        }

        mAllowShowLikedVideos.setOnPreferenceChangeListener(new androidx.preference.Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(androidx.preference.Preference preference, Object newValue) {

                if (newValue instanceof Boolean) {

                    Boolean value = (Boolean) newValue;

                    if (value) {

                        App.getInstance().getAccount().setAllowShowLikedVideos(1);

                    } else {

                        App.getInstance().getAccount().setAllowShowLikedVideos(0);
                    }

                    saveSettings();
                }

                return true;
            }
        });

        mAllowDownloadVideos = (SwitchPreference) getPreferenceManager().findPreference("allowDownloadVideos");

        if (App.getInstance().getAccount().getAllowDownloadVideos() == 1) {

            mAllowDownloadVideos.setChecked(true);

        } else {

            mAllowDownloadVideos.setChecked(false);
        }

        mAllowDownloadVideos.setOnPreferenceChangeListener(new androidx.preference.Preference.OnPreferenceChangeListener() {

            @Override
            public boolean onPreferenceChange(androidx.preference.Preference preference, Object newValue) {

                if (newValue instanceof Boolean) {

                    Boolean value = (Boolean) newValue;

                    if (value) {

                        App.getInstance().getAccount().setAllowDownloadVideos(1);

                    } else {

                        App.getInstance().getAccount().setAllowDownloadVideos(0);
                    }

                    saveSettings();
                }

                return true;
            }
        });

    }

    public void onActivityCreated(Bundle savedInstanceState) {

        super.onActivityCreated(savedInstanceState);

        if (savedInstanceState != null) {

            loading = savedInstanceState.getBoolean("loading");

        } else {

            loading = false;
        }

        if (loading) {

            showpDialog();
        }
    }

    public void saveSettings() {

        if (App.getInstance().isConnected()) {

            loading = true;

            showpDialog();

            CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_PRIVACY, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            try {

                                if (!response.getBoolean("error")) {

                                    App.getInstance().getAccount().setAllowShowMyGallery(response.getInt("allowShowMyGallery"));
                                    App.getInstance().getAccount().setAllowShowMyGifts(response.getInt("allowShowMyGifts"));
                                    App.getInstance().getAccount().setAllowShowMyFriends(response.getInt("allowShowMyFriends"));
                                    App.getInstance().getAccount().setAllowShowMyInfo(response.getInt("allowShowMyInfo"));

                                    App.getInstance().getAccount().setAllowMessages(response.getInt("allowMessages"));
                                    App.getInstance().getAccount().setAllowVideoCalls(response.getInt("allowVideoCalls"));
                                    App.getInstance().getAccount().setAllowShowLikedVideos(response.getInt("allowShowLikedVideos"));
                                    App.getInstance().getAccount().setAllowDownloadVideos(response.getInt("allowDownloadVideos"));
                                }

                            } catch (JSONException e) {

                                e.printStackTrace();

                            } finally {

                                loading = false;

                                hidepDialog();

                                Log.e("Privacy Success", response.toString());
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    loading = false;

                    hidepDialog();

                    Log.d("Privacy Error", error.toString());
                }
            }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();

                    params.put("clientId", CLIENT_ID);
                    params.put("accountId", Long.toString(App.getInstance().getId()));
                    params.put("accessToken", App.getInstance().getAccessToken());

                    params.put("allowShowMyGallery", Integer.toString(App.getInstance().getAccount().getAllowShowMyGallery()));
                    params.put("allowShowMyGifts", Integer.toString(App.getInstance().getAccount().getAllowShowMyGifts()));
                    params.put("allowShowMyFriends", Integer.toString(App.getInstance().getAccount().getAllowShowMyFriends()));
                    params.put("allowShowMyInfo", Integer.toString(App.getInstance().getAccount().getAllowShowMyInfo()));

                    params.put("allowShowLikedVideos", Integer.toString(App.getInstance().getAccount().getAllowShowLikedVideos()));
                    params.put("allowDownloadVideos", Integer.toString(App.getInstance().getAccount().getAllowDownloadVideos()));
                    params.put("allowMessages", Integer.toString(App.getInstance().getAccount().getAllowMessages()));
                    params.put("allowVideoCalls", Integer.toString(App.getInstance().getAccount().getAllowVideoCalls()));

                    return params;
                }
            };

            App.getInstance().addToRequestQueue(jsonReq);

        } else {

            Toast.makeText(getActivity(), getText(R.string.msg_network_error), Toast.LENGTH_SHORT).show();
        }
    }

    public void onDestroyView() {

        super.onDestroyView();

        hidepDialog();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("loading", loading);
    }

    protected void initpDialog() {

        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage(getString(R.string.msg_loading));
        pDialog.setCancelable(false);
    }

    protected void showpDialog() {

        if (!pDialog.isShowing())
            pDialog.show();
    }

    protected void hidepDialog() {

        if (pDialog.isShowing())
            pDialog.dismiss();
    }
}