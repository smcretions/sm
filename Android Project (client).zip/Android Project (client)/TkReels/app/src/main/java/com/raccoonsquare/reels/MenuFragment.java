package com.raccoonsquare.reels;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

import androidx.cardview.widget.CardView;
import androidx.fragment.app.Fragment;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.android.volley.toolbox.ImageLoader;

import com.mikhaellopez.circularimageview.CircularImageView;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.common.FragmentBase;
import com.raccoonsquare.reels.constants.Constants;


public class MenuFragment extends FragmentBase implements Constants {

    ImageLoader imageLoader;

    private ImageView mGuestsCountIcon, mMessagesCountIcon;

    private TextView mNavProfileLabel;
    private CircularImageView mNavProfileIcon, mNavProfileVerificationIcon;

    private ImageView mNavFollowersIcon, mNavGuestsIcon, mNavMarketIcon, mNavNearbyIcon, mNavFavoritesIcon, mNavPopularIcon, mNavUpgradesIcon, mNavSettingsIcon;

    private CardView mNavProfile, mNavMessages, mNavFollowers, mNavMarket, mNavGuests, mNavFavorites, mNavNearby, mNavPopular, mNavUpgrades, mNavSettings;

    public MenuFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        imageLoader = App.getInstance().getImageLoader();

        setHasOptionsMenu(false);

        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_menu, container, false);

        getActivity().setTitle(R.string.nav_menu);

        mNavProfile = (CardView) rootView.findViewById(R.id.nav_profile);
        mNavProfileLabel = rootView.findViewById(R.id.nav_profile_label);
        mNavProfileIcon = rootView.findViewById(R.id.profile_image);
        mNavProfileVerificationIcon = rootView.findViewById(R.id.profile_verification_icon);
        mNavProfileVerificationIcon.setVisibility(View.GONE);

        mNavProfile.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), ProfileActivity.class);
                i.putExtra("profileId", App.getInstance().getId());
                getActivity().startActivity(i);
            }
        });

        //

        mNavMessages = (CardView) rootView.findViewById(R.id.nav_messages);
        mNavFollowers = (CardView) rootView.findViewById(R.id.nav_followers);
        mNavGuests = (CardView) rootView.findViewById(R.id.nav_guests);
        mNavMarket = (CardView) rootView.findViewById(R.id.nav_market);
        mNavNearby = (CardView) rootView.findViewById(R.id.nav_nearby);
        mNavFavorites = (CardView) rootView.findViewById(R.id.nav_favorites);
        mNavPopular = (CardView) rootView.findViewById(R.id.nav_popular);
        mNavUpgrades = (CardView) rootView.findViewById(R.id.nav_upgrades);
        mNavSettings = (CardView) rootView.findViewById(R.id.nav_settings);

        // Counters

        mGuestsCountIcon = (ImageView) rootView.findViewById(R.id.nav_guests_count_icon);
        mMessagesCountIcon = (ImageView) rootView.findViewById(R.id.nav_messages_count_icon);

        // Icons

        mNavFollowersIcon = (ImageView) rootView.findViewById(R.id.nav_followers_icon);
        mNavGuestsIcon = (ImageView) rootView.findViewById(R.id.nav_guests_icon);
        mNavMarketIcon = (ImageView) rootView.findViewById(R.id.nav_market_icon);
        mNavNearbyIcon = (ImageView) rootView.findViewById(R.id.nav_nearby_icon);
        mNavFavoritesIcon = (ImageView) rootView.findViewById(R.id.nav_favorites_icon);
        mNavPopularIcon = (ImageView) rootView.findViewById(R.id.nav_popular_icon);
        mNavUpgradesIcon = (ImageView) rootView.findViewById(R.id.nav_upgrades_icon);
        mNavSettingsIcon = (ImageView) rootView.findViewById(R.id.nav_settings_icon);

        if (!App.getInstance().getAppSettings().getMarketFeature()) {

            mNavMarket.setVisibility(View.GONE);
        }

        if (!App.getInstance().getAppSettings().getUpgradesFeature()) {

            mNavUpgrades.setVisibility(View.GONE);
        }

        mNavMessages.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), DialogsActivity.class);
                startActivity(i);
            }
        });

        mNavFollowers.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), CountersContentActivity.class);
                i.putExtra("pageId", 1);
                i.putExtra("profileId", App.getInstance().getAccount().getId());
                i.putExtra("followingCount", App.getInstance().getAccount().getFollowingsCount());
                i.putExtra("followersCount", App.getInstance().getAccount().getFollowersCount());
                i.putExtra("fullname", App.getInstance().getAccount().getFullname());
                startActivity(i);
            }
        });

        mNavGuests.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), GuestsActivity.class);
                startActivity(i);
            }
        });


        mNavMarket.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), FinderActivity.class);
                i.putExtra("tab_position", 3);
                startActivity(i);
            }
        });

        mNavNearby.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), NearbyActivity.class);
                startActivity(i);
            }
        });

        mNavFavorites.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), FavoritesActivity.class);
                i.putExtra("profileId", App.getInstance().getId());
                startActivity(i);
            }
        });

        mNavPopular.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), PopularActivity.class);
                startActivity(i);
            }
        });

        mNavUpgrades.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), UpgradesActivity.class);
                startActivity(i);
            }
        });

        mNavSettings.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), SettingsActivity.class);
                startActivity(i);
            }
        });

        updateView();

        // Inflate the layout for this fragment
        return rootView;
    }

    public void updateView() {

        //

        mNavProfileLabel.setText(App.getInstance().getAccount().getFullname());

        if (App.getInstance().getAccount().getNormalPhotoUrl().length() > 0) {

            ImageLoader imageLoader = App.getInstance().getImageLoader();

            imageLoader.get(App.getInstance().getAccount().getNormalPhotoUrl(), ImageLoader.getImageListener(mNavProfileIcon, R.drawable.profile_default_photo, R.drawable.profile_default_photo));
        }

        if (App.getInstance().getAccount().getVerified() != 0) {

            mNavProfileVerificationIcon.setVisibility(View.VISIBLE);
        }

        // Counters

        mGuestsCountIcon.setVisibility(View.GONE);

        if (App.getInstance().getGuestsCount() != 0) {

            mGuestsCountIcon.setVisibility(View.VISIBLE);
        }

        mMessagesCountIcon.setVisibility(View.GONE);

        if (App.getInstance().getMessagesCount() != 0) {

            mMessagesCountIcon.setVisibility(View.VISIBLE);
        }
    }

    @Override
    public void onResume() {

        super.onResume();

        updateView();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {

        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }
}