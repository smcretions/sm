package com.raccoonsquare.reels;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;

import androidx.appcompat.widget.Toolbar;
import androidx.viewpager.widget.ViewPager;

import com.raccoonsquare.reels.adapter.SectionsPagerAdapter;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.common.ActivityBase;
import com.google.android.material.tabs.TabLayout;

public class CountersContentActivity extends ActivityBase {

    Toolbar mToolbar;

    ViewPager mViewPager;
    TabLayout mTabLayout;

    SectionsPagerAdapter adapter;

    private Boolean restore = false;

    private long profileId = 0;
    private int pageId = 0;
    private String fullname = "", szFollowing = "", szFollowers = "";

    private int followingCount = 0, followersCount = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_counters_content);

        if (savedInstanceState != null) {

            restore = savedInstanceState.getBoolean("restore");
            pageId = savedInstanceState.getInt("pageId");
            profileId = savedInstanceState.getLong("profileId");

        } else {

            restore = false;
            pageId = 0;
            profileId = App.getInstance().getId();
        }

        //

        Intent i = getIntent();

        pageId = i.getIntExtra("pageId", 0);

        profileId = i.getLongExtra("profileId", 0);
        if (profileId == 0) profileId = App.getInstance().getId();

        fullname = i.getStringExtra("fullname");
        setTitle(fullname);

        //

        followingCount = i.getIntExtra("followingCount", 0);
        szFollowing = getString(R.string.title_activity_followings);

        if (followingCount != 0) {

            szFollowing = szFollowing + " (" + Integer.toString(followingCount) + ")";
        }

        //

        followersCount = i.getIntExtra("followersCount", 0);
        szFollowers = getString(R.string.title_activity_followers);

        if (followersCount != 0) {

            szFollowers = szFollowers + " (" + Integer.toString(followersCount) + ")";
        }

        // Toolbar

        mToolbar = (Toolbar) findViewById(R.id.toolbar);

        setSupportActionBar(mToolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        getSupportActionBar().setHomeButtonEnabled(true);

        // ViewPager

        mViewPager = (ViewPager) findViewById(R.id.view_pager);

        adapter = new SectionsPagerAdapter(getSupportFragmentManager());
        adapter.addFragment(new FollowingFragment().newInstance(true, true, profileId), szFollowing);
        adapter.addFragment(new FollowingFragment().newInstance(true, false, profileId), szFollowers);
        mViewPager.setAdapter(adapter);
        mViewPager.setCurrentItem(pageId);

        // TabLayout

        mTabLayout = (TabLayout) findViewById(R.id.tab_layout);
        mTabLayout.setupWithViewPager(mViewPager);
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("restore", true);
        outState.putLong("profileId", profileId);
        outState.putInt("pageId", pageId);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.

        switch (item.getItemId()) {

            case android.R.id.home: {

                finish();

                return true;
            }

            default: {

                return super.onOptionsItemSelected(item);
            }
        }
    }
}
