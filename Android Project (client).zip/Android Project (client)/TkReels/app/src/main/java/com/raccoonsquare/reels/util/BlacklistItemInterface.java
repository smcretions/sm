package com.raccoonsquare.reels.util;

public interface BlacklistItemInterface {

    public void remove(int position);
}