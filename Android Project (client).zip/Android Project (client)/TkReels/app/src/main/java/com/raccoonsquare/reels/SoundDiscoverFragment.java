package com.raccoonsquare.reels;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;

import com.raccoonsquare.reels.adapter.SoundListAdapter;
import com.raccoonsquare.reels.model.Sound;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;

import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import androidx.core.widget.NestedScrollView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.android.volley.DefaultRetryPolicy;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.util.Helper;
import com.raccoonsquare.reels.view.LineItemDecoration;

public class SoundDiscoverFragment extends Fragment implements Constants, SwipeRefreshLayout.OnRefreshListener {

    private static final String STATE_LIST = "State Adapter Data";

    private ProgressDialog pDialog;

    private BottomSheetBehavior mBehavior;
    private BottomSheetDialog mBottomSheetDialog;
    private View mBottomSheet;

    private RecyclerView mRecyclerView;
    private NestedScrollView mNestedView;

    private TextView mMessage;
    private ImageView mSplash;

    SwipeRefreshLayout mItemsContainer;

    private ArrayList<Sound> itemsList;
    private SoundListAdapter itemsAdapter;

    private int itemId = 0;
    private int arrayLength = 0;
    private Boolean loadingMore = false;
    private Boolean viewMore = false;
    private Boolean restore = false;

    private MediaPlayer mediaPlayer;
    private int current_play_position = -1;
    private int categoryId = 0;

    private Boolean loadingComplete = false, isMusicFanPage = false, isSelectable = true;

    public SoundDiscoverFragment(Boolean isMusicFanPage, Boolean isSelectable) {

        this.isMusicFanPage = isMusicFanPage;
        this.isSelectable = isSelectable;
    }

    public SoundDiscoverFragment() {
        // Required empty public constructor
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setHasOptionsMenu(false);

        initpDialog();

        if (savedInstanceState != null) {

            itemsList = savedInstanceState.getParcelableArrayList(STATE_LIST);
            itemsAdapter = new SoundListAdapter(getActivity(), itemsList, isSelectable);

            restore = savedInstanceState.getBoolean("restore");
            itemId = savedInstanceState.getInt("itemId");
            loadingComplete = savedInstanceState.getBoolean("loadingComplete");

        } else {

            itemsList = new ArrayList<Sound>();
            itemsAdapter = new SoundListAdapter(getActivity(), itemsList, isSelectable);

            restore = false;
            itemId = 0;
            loadingComplete = false;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_sound_discover, container, false);

        mItemsContainer = (SwipeRefreshLayout) rootView.findViewById(R.id.container_items);
        mItemsContainer.setOnRefreshListener(this);

        mMessage = (TextView) rootView.findViewById(R.id.message);
        mSplash = (ImageView) rootView.findViewById(R.id.splash);

        // Prepare bottom sheet

        mBottomSheet = rootView.findViewById(R.id.bottom_sheet);
        mBehavior = BottomSheetBehavior.from(mBottomSheet);

        //

        mNestedView = (NestedScrollView) rootView.findViewById(R.id.nested_view);

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recycler_view);

        mRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        mRecyclerView.addItemDecoration(new LineItemDecoration(getActivity(), LinearLayout.VERTICAL));
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mRecyclerView.setAdapter(itemsAdapter);

        itemsAdapter.setOnItemClickListener(new SoundListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, Sound obj, int position, int action) {

                switch (action) {

                    case 1: {

                        // Select

                        if (categoryId != 0 && App.getInstance().getAccount().getMusicFanMode() == 0) {

                            AlertDialog alertDialog = new AlertDialog.Builder(getActivity()).create();
                            alertDialog.setIcon(R.drawable.ic_music_fan);
                            alertDialog.setTitle(getString(R.string.label_upgrades_music_fan_mode));
                            alertDialog.setMessage("\n" +  getString(R.string.label_tooltip_music_fan_feature) + "\n");

                            alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.action_cancel), new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface dialog, int which) {

                                    dialog.dismiss();
                                }
                            });

                            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.action_open_upgrades_section), new DialogInterface.OnClickListener() {

                                public void onClick(DialogInterface dialog, int which) {

                                    Intent i = new Intent(getActivity(), UpgradesActivity.class);
                                    startActivity(i);

                                    dialog.dismiss();
                                }
                            });

                            alertDialog.show();

                        } else {

                            Intent intent = new Intent(TAG_SELECT_SOUND_ITEM);
                            intent.putExtra("soundId", obj.getId());
                            intent.putExtra("soundTitle", obj.getTitle());
                            intent.putExtra("soundUrl", obj.getMp3Url());
                            getContext().sendBroadcast(intent);

                            Helper helper = new Helper(getContext());
                            helper.downloadSound(obj.getMp3Url(), MP3_SRC_FILE);
                        }

                        break;
                    }

                    default: {

                        if (obj.isPlaying()) {

                            stopMp3();

                        } else {

                            playMp3(obj, position);
                        }

                        break;
                    }
                }
            }
        });

        mRecyclerView.setNestedScrollingEnabled(false);


        mNestedView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {

            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY < oldScrollY) { // up


                }

                if (scrollY > oldScrollY) { // down


                }

                if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {

                    if (!loadingMore && (viewMore) && !(mItemsContainer.isRefreshing())) {

                        mItemsContainer.setRefreshing(true);

                        loadingMore = true;

                        getItems();
                    }
                }
            }
        });

        if (itemsAdapter.getItemCount() == 0) {

            showMessage(getText(R.string.label_empty_list).toString());

        } else {

            hideMessage();
        }

//        if (!restore && isBookmarkPage) {
//
//            showMessage(getText(R.string.msg_loading_2).toString());
//
//            getItems();
//        }

        // Inflate the layout for this fragment
        return rootView;
    }

    private void playMp3(Sound obj, int position) {

        stopMp3();

        if (mediaPlayer == null) {

            current_play_position = position;

            itemsList.get(position).setIsPlaying(true);
            itemsAdapter.notifyDataSetChanged();

            Log.e("Dimon", obj.getMp3Url());

            mediaPlayer = MediaPlayer.create(getActivity(), Uri.parse(obj.getMp3Url()));
            mediaPlayer.start();

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer mp) {

                    if (mediaPlayer != null) {

                        try {

                            stopMp3();

                        } catch (Exception e) {

                            e.printStackTrace();
                        }
                    }
                }
            });
        }
    }

    private void stopMp3() {

        Log.e("stopMp3", "stopMp3");

        if (mediaPlayer != null) {

            for (int i = 0; i < itemsList.size(); i++) {

                itemsList.get(i).setIsPlaying(false);
            }

            itemsAdapter.notifyDataSetChanged();

            current_play_position = -1;

            mediaPlayer.reset();
            mediaPlayer.release();
            mediaPlayer = null;
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {

        super.setUserVisibleHint(isVisibleToUser);

        Log.e("Dimon111", "setUserVisibleHint");

        if (isVisibleToUser) {

            Handler handler = new Handler();

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    if (isAdded()) {

                        if (!loadingComplete) {

                            showMessage(getText(R.string.msg_loading_2).toString());

                            getItems();

                        } else {

                            showMessage(getText(R.string.msg_loading_2).toString());

                            itemId = 0;

                            getItems();
                        }
                    }
                }
            }, 50);

        } else {

            stopMp3();
        }
    }

    @Override
    public void onRefresh() {

        if (App.getInstance().isConnected()) {

            stopMp3();

            itemId = 0;
            getItems();

        } else {

            mItemsContainer.setRefreshing(false);
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putBoolean("loadingComplete", true);
        outState.putBoolean("restore", true);
        outState.putInt("itemId", itemId);
        outState.putParcelableArrayList(STATE_LIST, itemsList);
    }

    public void getItems() {

        mItemsContainer.setRefreshing(true);

        String url = METHOD_SOUND_GET;

        categoryId = 0;

        if (isMusicFanPage) {

            categoryId = 1;
        }

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "SoundDiscoverFragment Not Added to Activity");

                            return;
                        }

                        try {

                            arrayLength = 0;

                            if (!loadingMore) {

                                itemsList.clear();
                                itemsAdapter.notifyDataSetChanged();
                            }

                            if (!response.getBoolean("error")) {

                                App.getInstance().setNotificationsCount(0);

                                itemId = response.getInt("itemId");

                                JSONArray itemsArray = response.getJSONArray("items");

                                arrayLength = itemsArray.length();

                                if (arrayLength > 0) {

                                    for (int i = 0; i < itemsArray.length(); i++) {

                                        JSONObject notifyObj = (JSONObject) itemsArray.get(i);
                                        Sound mp3 = new Sound(notifyObj);
                                        itemsList.add(mp3);

                                        itemsAdapter.notifyItemChanged(itemsList.size());
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("SoundDiscoverFragment resp", response.toString());

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "SoundDiscoverFragment Not Added to Activity");

                    return;
                }

                loadingComplete();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("account_id", Long.toString(App.getInstance().getId()));
                params.put("access_token", App.getInstance().getAccessToken());
                params.put("item_id", Integer.toString(itemId));
                params.put("category_id", Integer.toString(categoryId));

                return params;
            }
        };

        RetryPolicy policy = new DefaultRetryPolicy((int) TimeUnit.SECONDS.toMillis(15), DefaultRetryPolicy.DEFAULT_MAX_RETRIES, DefaultRetryPolicy.DEFAULT_BACKOFF_MULT);

        jsonReq.setRetryPolicy(policy);

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void loadingComplete() {

        if (arrayLength == LIST_ITEMS) {

            viewMore = true;

        } else {

            viewMore = false;
        }

        if (itemsAdapter.getItemCount() == 0) {

            showMessage(getText(R.string.label_empty_list).toString());

        } else {

            hideMessage();
        }

        loadingComplete = true;
        loadingMore = false;
        mItemsContainer.setRefreshing(false);
    }

    public void showMessage(String message) {

        if (itemsList.size() == 0) {

            mMessage.setText(message);
            mMessage.setVisibility(View.VISIBLE);

            mSplash.setVisibility(View.VISIBLE);
        }
    }

    public void hideMessage() {

        mMessage.setVisibility(View.GONE);
        mSplash.setVisibility(View.GONE);
    }

    @Override
    public void onStop() {

        super.onStop();

        stopMp3();
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {

        super.onPrepareOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            default: {

                return super.onOptionsItemSelected(item);
            }
        }
    }

    protected void initpDialog() {

        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage(getString(R.string.msg_loading));
        pDialog.setCancelable(false);
    }

    protected void showpDialog() {

        if (!pDialog.isShowing()) pDialog.show();
    }

    protected void hidepDialog() {

        if (pDialog.isShowing()) pDialog.dismiss();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private void makeBookmark(final long itemId) {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_BOOKMARK_MAKE, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        try {

                            if (!response.getBoolean("error")) {

//                                p.setLikesCount(response.getInt("likesCount"));
//                                p.setMyLike(response.getBoolean("myLike"));
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("Item.Bookmark", response.toString());

                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                Log.e("Item.Bookmark", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("account_id", Long.toString(App.getInstance().getId()));
                params.put("access_token", App.getInstance().getAccessToken());
                params.put("sound_id", Long.toString(itemId));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }
}