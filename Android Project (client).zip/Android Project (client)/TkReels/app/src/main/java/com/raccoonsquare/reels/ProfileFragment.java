package com.raccoonsquare.reels;

import static android.content.Context.RECEIVER_NOT_EXPORTED;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.graphics.drawable.Drawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Parcelable;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.animation.LinearInterpolator;
import android.view.animation.ScaleAnimation;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.widget.AppCompatButton;
import androidx.appcompat.widget.Toolbar;
import androidx.cardview.widget.CardView;
import androidx.core.content.FileProvider;
import androidx.core.widget.NestedScrollView;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.RetryPolicy;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.ImageLoader;
import com.balysv.materialripple.MaterialRippleLayout;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.google.android.material.snackbar.Snackbar;
import com.google.android.material.tabs.TabLayout;
import com.mikhaellopez.circularimageview.CircularImageView;
import com.raccoonsquare.reels.adapter.AdvancedItemListAdapterV2;
import com.raccoonsquare.reels.adapter.FeelingsListAdapter;
import com.raccoonsquare.reels.adapter.FriendsSpotlightListAdapter;
import com.raccoonsquare.reels.adapter.GiftsSelectListAdapter;
import com.raccoonsquare.reels.adapter.MarketListAdapter;
import com.raccoonsquare.reels.adapter.MarketListAdapterV2;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.BaseGift;
import com.raccoonsquare.reels.model.Feeling;
import com.raccoonsquare.reels.model.Item;
import com.raccoonsquare.reels.model.MarketItem;
import com.raccoonsquare.reels.model.Profile;
import com.raccoonsquare.reels.util.Api;
import com.raccoonsquare.reels.util.CountingRequestBody;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.util.Helper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.Interceptor;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;

public class ProfileFragment extends Fragment implements Constants, SwipeRefreshLayout.OnRefreshListener {

    private static final String STATE_LIST = "State Adapter Data";
    private static final String STATE_LIST_2 = "State Adapter Data";
    private static final String STATE_GALLERY_SPOTLIGHT_LIST = "State Adapter Data 2";
    private static final String STATE_FRIENDS_SPOTLIGHT_LIST = "State Adapter Data 3";

    private ProgressDialog pDialog;

    private static final String TAG = ProfileFragment.class.getSimpleName();

    private static final int MODE_PHOTO = 1;
    private static final int MODE_COVER = 2;

    private static final int SELECT_PHOTO = 1;
    private static final int SELECT_COVER = 2;
    private static final int PROFILE_EDIT = 3;
    private static final int PROFILE_NEW_POST = 4;
    private static final int CREATE_PHOTO = 5;
    private static final int CREATE_COVER = 6;
    private static final int PROFILE_FEELINGS = 7;

    String [] names = {};

    Toolbar mToolbar;

    private TabLayout mTabLayout;

    TextView mMessage;

    Button mProfileActionSendMessage, mProfileActionMore, mProfileActionMain, mProfileActionVideoCall;

    Button mSuggestedSpotlightMoreButton;
    TextView mSuggestedSpotlightTitle, mSuggestedSpotlightCount;
    CardView mSuggestedSpotlight;
    RecyclerView mSuggestedSpotlightRecyclerView;

    private ArrayList<Profile> suggestedSpotlightList;
    private FriendsSpotlightListAdapter suggestedSpotlightAdapter;

    LinearLayout mProfileStatusContainer, mProfileFacebookContainer, mProfileSiteContainer, mProfilePhoneContainer, mProfileEmailContainer;

    ImageView profileOnlineIcon, profileIcon;

    TextView profileFullname, mProfileType, profileUsername, mProfileErrorScreenMsg, mProfileDisabledScreenMsg;
    TextView mItemsCount, mLikesCount, mFollowersCount, mFollowingCount, mProfileLocation, mProfileFacebookPage, mProfileInstagramPage, mProfileBio, mProfilePhone, mProfileEmail;

    RelativeLayout mProfileLoadingScreen, mProfileErrorScreen, mProfileDisabledScreen;
    LinearLayout mProfileLocationContainer, mProfileInfoContainer;

    SwipeRefreshLayout mProfileRefreshLayout;
    NestedScrollView mNestedScrollView;
    RecyclerView mRecyclerView;

    ImageView profileCover;
    CircularImageView profilePhoto, mFeelingIcon;

    // Tooltip

    private CardView mLoginCreateTooltip;
    private Button mLoginCreateButton;
    private ImageButton mCloseTooltipButton;

    //

    private BottomSheetBehavior mBehavior;
    private BottomSheetDialog mBottomSheetDialog;
    private View mBottomSheet;

    private RelativeLayout mSetProfilePhotoButton, mSetProfileCoverButton;

    MaterialRippleLayout mProfileItemsBtn, mProfileLikesBtn, mProfileFollowersBtn, mProfileFollowingBtn;

    Profile profile;

    private ArrayList<Item> itemsList;
    private AdvancedItemListAdapterV2 itemsAdapter;

    private ArrayList<MarketItem> marketList;
    private MarketListAdapterV2 marketAdapter;


    private ActivityResultLauncher<String[]> agoraPermissionLauncher;
    private ActivityResultLauncher<String> cameraPermissionLauncher;
    private ActivityResultLauncher<String[]> storagePermissionLauncher;
    private ActivityResultLauncher<Intent> imgFromGalleryActivityResultLauncher;
    private ActivityResultLauncher<Intent> imgFromCameraActivityResultLauncher;

    GoogleSignInClient mGoogleSignInClient;
    ActivityResultLauncher<Intent> googleSigninActivityResultLauncher;

    private int mAccountAction = 0; // 0 = choicePhoto, 1 = choiceCover

    private Boolean loadingComplete = false;
    private Boolean loadingMore = false;
    private Boolean viewMore = false;

    private String profile_mention;
    public long profile_id;
    int itemId = 0;
    int arrayLength = 0;
    int accessMode = 0;

    int sectionId = 0;

    private Boolean loading = false;
    private Boolean restore = false;
    private Boolean preload = false;
    private Boolean pager = false;
    private Boolean loaded = false;

    private Boolean isMainScreen = false;

    private int giftPosition = 0;

    public ProfileFragment() {
        // Required empty public constructor
    }

    public ProfileFragment newInstance(Boolean pager) {

        ProfileFragment myFragment = new ProfileFragment();

        Bundle args = new Bundle();
        args.putBoolean("pager", pager);
        myFragment.setArguments(args);

        return myFragment;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setRetainInstance(true);

        initpDialog();

        Intent i = getActivity().getIntent();

        profile_id = i.getLongExtra("profileId", 0);
        profile_mention = i.getStringExtra("profileMention");

        if (profile_id == 0 && (profile_mention == null || profile_mention.length() == 0)) {

            profile_id = App.getInstance().getId();
            isMainScreen = true;
        }

        if (isMainScreen) {

            setHasOptionsMenu(false);

        } else {

            setHasOptionsMenu(true);
        }

        profile = new Profile();
        profile.setId(profile_id);

        itemsList = new ArrayList<Item>();
        itemsAdapter = new AdvancedItemListAdapterV2(getActivity(), itemsList, PAGE_PROFILE);

        suggestedSpotlightList = new ArrayList<Profile>();
        suggestedSpotlightAdapter = new FriendsSpotlightListAdapter(getActivity(), suggestedSpotlightList);

        if (getArguments() != null) {

            pager = getArguments().getBoolean("pager", false);
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_profile, container, false);

        if (savedInstanceState != null) {

            itemsList = savedInstanceState.getParcelableArrayList(STATE_LIST);
            itemsAdapter = new AdvancedItemListAdapterV2(getActivity(), itemsList, PAGE_PROFILE);

            marketList = savedInstanceState.getParcelableArrayList(STATE_LIST_2);
            marketAdapter = new MarketListAdapterV2(getActivity(), marketList);

            suggestedSpotlightList = savedInstanceState.getParcelableArrayList(STATE_FRIENDS_SPOTLIGHT_LIST);
            suggestedSpotlightAdapter = new FriendsSpotlightListAdapter(getActivity(), suggestedSpotlightList);

            itemId = savedInstanceState.getInt("itemId");

            restore = savedInstanceState.getBoolean("restore");
            loading = savedInstanceState.getBoolean("loading");
            preload = savedInstanceState.getBoolean("preload");
            loaded = savedInstanceState.getBoolean("loaded");
            pager = savedInstanceState.getBoolean("pager");

            profile = savedInstanceState.getParcelable("profileObj");

        } else {

            itemsList = new ArrayList<Item>();
            itemsAdapter = new AdvancedItemListAdapterV2(getActivity(), itemsList, PAGE_PROFILE);

            marketList = new ArrayList<MarketItem>();
            marketAdapter = new MarketListAdapterV2(getActivity(), marketList);

            suggestedSpotlightList = new ArrayList<Profile>();
            suggestedSpotlightAdapter = new FriendsSpotlightListAdapter(getActivity(), suggestedSpotlightList);

            itemId = 0;

            restore = false;
            loading = false;
            preload = false;
            loaded = false;
            pager = false;
        }

        if (loading) {


            showpDialog();
        }

        //

        mMessage = rootView.findViewById(R.id.message_label);
        mMessage.setVisibility(View.GONE);

        //

        mTabLayout = (TabLayout) rootView.findViewById(R.id.tab_layout);

        mTabLayout.addTab(mTabLayout.newTab());
        mTabLayout.addTab(mTabLayout.newTab());
        mTabLayout.addTab(mTabLayout.newTab());
        mTabLayout.addTab(mTabLayout.newTab());


        mTabLayout.getTabAt(0).setIcon(R.drawable.ic_grid);
        mTabLayout.getTabAt(0).getIcon().setColorFilter(getResources().getColor(R.color.tabBarIconTintActive), PorterDuff.Mode.SRC_IN);

        mTabLayout.getTabAt(1).setIcon(R.drawable.ic_heart_2);
        mTabLayout.getTabAt(1).getIcon().setColorFilter(getResources().getColor(R.color.tabBarIconTint), PorterDuff.Mode.SRC_IN);

        mTabLayout.getTabAt(2).setIcon(R.drawable.ic_market_2);
        mTabLayout.getTabAt(2).getIcon().setColorFilter(getResources().getColor(R.color.tabBarIconTint), PorterDuff.Mode.SRC_IN);

        mTabLayout.getTabAt(3).setIcon(R.drawable.ic_lock_2);
        mTabLayout.getTabAt(3).getIcon().setColorFilter(getResources().getColor(R.color.tabBarIconTint), PorterDuff.Mode.SRC_IN);

        for (int i = 0; i < mTabLayout.getTabCount(); i++) {

            TabLayout.Tab tab = mTabLayout.getTabAt(i);
            if (tab != null) tab.setCustomView(R.layout.custom_profile_tab);
        }

        if (!App.getInstance().getAppSettings().getMarketFeature()) {

            ((ViewGroup) mTabLayout.getTabAt(2).view).setVisibility(View.GONE);
        }

        if (profile_id != App.getInstance().getId()) {

            Log.e("Dimon", "setVisibility gone");

            ((ViewGroup) mTabLayout.getTabAt(3).view).setVisibility(View.GONE);
        }

        mTabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {

            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                if (tab.getPosition() == 0) {

                    sectionId = 0;
                    itemId = 0;
                    loadingMore = false;

                    itemsList.clear();
                    itemsAdapter.notifyDataSetChanged();

                    getItems();
                }

                if (tab.getPosition() == 1) {

                    sectionId = 1;

                    itemId = 0;
                    loadingMore = false;

                    itemsList.clear();
                    itemsAdapter.notifyDataSetChanged();

                    getItems();
                }

                if (tab.getPosition() == 2) {

                    // Market

                    sectionId = 2;
                    itemId = 0;
                    loadingMore = false;

                    marketList.clear();
                    marketAdapter.notifyDataSetChanged();

                    getItems();
                }

                if (tab.getPosition() == 3) {

                    sectionId = 3;

                    itemId = 0;
                    loadingMore = false;

                    itemsList.clear();
                    itemsAdapter.notifyDataSetChanged();

                    getItems();
                }

                //getSupportActionBar().setTitle(viewPagerAdapter.getTitle(tab.getPosition()));
                tab.getIcon().setColorFilter(getResources().getColor(R.color.tabBarIconTintActive), PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

                tab.getIcon().setColorFilter(getResources().getColor(R.color.tabBarIconTint), PorterDuff.Mode.SRC_IN);
            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

        // Create Login Tooltip

        mLoginCreateTooltip = (CardView) rootView.findViewById(R.id.login_create_tooltip);
        mLoginCreateButton = (Button) rootView.findViewById(R.id.login_create_button);
        mCloseTooltipButton = (ImageButton) rootView.findViewById(R.id.close_tooltip_button);

        mLoginCreateTooltip.setVisibility(View.GONE);

        mCloseTooltipButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                App.getInstance().getTooltipsSettings().setShowLoginCreateTooltip(false);
                App.getInstance().saveTooltipsSettings();

                mLoginCreateTooltip.setVisibility(View.GONE);
            }
        });

        mLoginCreateButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mLoginCreateTooltip.setVisibility(View.GONE);

                Intent intent = new Intent(getActivity(), ChangePasswordActivity.class);
                startActivity(intent);
            }
        });

        //

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(getActivity(), gso);

        googleSigninActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    // There are no request codes
                    Intent data = result.getData();

                    Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);

                    try {

                        GoogleSignInAccount account = task.getResult(ApiException.class);

                        // Signed in successfully, show authenticated UI.

                        showpDialog();

                        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_OAUTH, null,
                                new Response.Listener<JSONObject>() {
                                    @Override
                                    public void onResponse(JSONObject response) {

                                        if (App.getInstance().authorize(response)) {

                                            if (App.getInstance().getAccount().getState() == ACCOUNT_STATE_ENABLED) {

                                                Intent intent = new Intent(getActivity(), MainActivity.class);
                                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(intent);

                                            } else {

                                                if (App.getInstance().getAccount().getState() == ACCOUNT_STATE_BLOCKED) {

                                                    App.getInstance().logout();
                                                    Toast.makeText(getActivity(), getText(R.string.msg_account_blocked), Toast.LENGTH_SHORT).show();

                                                } else {

                                                    App.getInstance().updateGeoLocation();

                                                    Intent intent = new Intent(getActivity(), MainActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                    startActivity(intent);
                                                }
                                            }

                                        } else {

                                            Toast.makeText(getActivity(), getString(R.string.error_data_loading), Toast.LENGTH_SHORT).show();
                                        }

                                        hidepDialog();
                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Log.e("Google", "signInWithCredential:failure");

                                Toast.makeText(getActivity(), getText(R.string.error_data_loading), Toast.LENGTH_LONG).show();

                                hidepDialog();
                            }
                        }) {

                            @Override
                            protected Map<String, String> getParams() {
                                Map<String, String> params = new HashMap<String, String>();

                                params.put("client_id", CLIENT_ID);

                                params.put("account_id", Long.toString(App.getInstance().getId()));
                                params.put("access_token", App.getInstance().getAccessToken());

                                params.put("app_type", Integer.toString(APP_TYPE_ANDROID));
                                params.put("fcm_regId", App.getInstance().getFcmToken());

                                params.put("action", "");

                                params.put("uid", account.getId());
                                params.put("oauth_type", Integer.toString(OAUTH_TYPE_GOOGLE));
                                params.put("oauth_name", account.getDisplayName());
                                params.put("oauth_email", account.getEmail());
                                params.put("oauth_photo", account.getPhotoUrl().toString());

                                return params;
                            }
                        };

                        App.getInstance().addToRequestQueue(jsonReq);

                    } catch (ApiException e) {

                        // The ApiException status code indicates the detailed failure reason.
                        // Please refer to the GoogleSignInStatusCodes class reference for more information.
                        Log.e("Google", "Google sign in failed", e);
                    }
                }
            }
        });

        //

        imgFromGalleryActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    // The document selected by the user won't be returned in the intent.
                    // Instead, a URI to that document will be contained in the return intent
                    // provided to this method as a parameter.  Pull that uri using "resultData.getData()"

                    if (result.getData() != null) {

                        Helper helper = new Helper(App.getInstance().getApplicationContext());
                        helper.createImage(result.getData().getData(), IMAGE_FILE);

                        File f = new File(App.getInstance().getDirectory(), IMAGE_FILE);

                        uploadFile(f, mAccountAction);
                    }
                }
            }
        });

        imgFromCameraActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    File f = new File(App.getInstance().getDirectory(), IMAGE_FILE);

                    uploadFile(f, mAccountAction);
                }
            }
        });

        cameraPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {

            if (isGranted) {

                // Permission is granted
                Log.e("Permissions", "Permission is granted");

                choiceImage();

            } else {

                // Permission is denied

                Log.e("Permissions", "denied");

                Snackbar.make(getView(), getString(R.string.label_no_camera_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(getActivity(), getString(R.string.label_grant_camera_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }
        });

        agoraPermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), (Map<String, Boolean> isGranted) -> {

            boolean granted = true;

            for (Map.Entry<String, Boolean> x : isGranted.entrySet())

                if (!x.getValue()) granted = false;

            if (granted) {

                agoraVideoCall();

            } else {

                // Permission is denied

                Log.e("Permissions", "denied");

                Snackbar.make(getView(), getString(R.string.label_no_camera_or_video_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(getActivity(), getString(R.string.label_grant_camera_and_audio_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }
        });

        storagePermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), (Map<String, Boolean> isGranted) -> {

            boolean granted = false;
            String storage_permission = Manifest.permission.READ_EXTERNAL_STORAGE;

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

                storage_permission = Manifest.permission.READ_MEDIA_IMAGES;
            }

            for (Map.Entry<String, Boolean> x : isGranted.entrySet()) {

                if (x.getKey().equals(storage_permission)) {

                    if (x.getValue()) {

                        granted = true;
                    }
                }
            }

            if (granted) {

                Log.e("Permissions", "granted");

                choiceImage();

            } else {

                Log.e("Permissions", "denied");

                Snackbar.make(getView(), getString(R.string.label_no_storage_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(getActivity(), getString(R.string.label_grant_storage_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }

        });

        //

        mProfileRefreshLayout = (SwipeRefreshLayout) rootView.findViewById(R.id.profileRefreshLayout);
        mProfileRefreshLayout.setOnRefreshListener(this);

        mNestedScrollView = (NestedScrollView) rootView.findViewById(R.id.nestedScrollView);

        mProfileLoadingScreen = (RelativeLayout) rootView.findViewById(R.id.profileLoadingScreen);
        mProfileErrorScreen = (RelativeLayout) rootView.findViewById(R.id.profileErrorScreen);
        mProfileDisabledScreen = (RelativeLayout) rootView.findViewById(R.id.profileDisabledScreen);

        mProfileErrorScreenMsg = (TextView) rootView.findViewById(R.id.profileErrorScreenMsg);
        mProfileDisabledScreenMsg = (TextView) rootView.findViewById(R.id.profileDisabledScreenMsg);

        // Prepare bottom sheet

        mBottomSheet = rootView.findViewById(R.id.bottom_sheet);
        mBehavior = BottomSheetBehavior.from(mBottomSheet);

        // Prepare set photo and cover buttons

        mSetProfilePhotoButton = (RelativeLayout) rootView.findViewById(R.id.setProfilePhotoButton);
        mSetProfileCoverButton = (RelativeLayout) rootView.findViewById(R.id.setProfileCoverButton);

        mSetProfilePhotoButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Helper helper = new Helper(App.getInstance().getApplicationContext());

                if (!helper.checkStoragePermission()) {

                    requestStoragePermission();

                } else {

                    mAccountAction = 0;

                    choiceImage();
                }
            }
        });

        mSetProfileCoverButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Helper helper = new Helper(App.getInstance().getApplicationContext());

                if (!helper.checkStoragePermission()) {

                    requestStoragePermission();

                } else {

                    mAccountAction = 1;

                    choiceImage();
                }
            }
        });

        // Start prepare action buttons

        mProfileActionSendMessage = (Button) rootView.findViewById(R.id.profile_action_send_message);
        mProfileActionVideoCall = (Button) rootView.findViewById(R.id.profile_action_video_call);
        mProfileActionMore = (Button) rootView.findViewById(R.id.profile_action_more);
        mProfileActionMain = (Button) rootView.findViewById(R.id.profile_action_main);

        mProfileActionMain.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (profile.getId() == App.getInstance().getId()) {

                    if (App.getInstance().getId() == profile.getId()) {

                        Intent i = new Intent(getActivity(), AccountSettingsActivity.class);
                        i.putExtra("profileId", App.getInstance().getId());
                        i.putExtra("sex", profile.getSex());
                        i.putExtra("year", profile.getYear());
                        i.putExtra("month", profile.getMonth());
                        i.putExtra("day", profile.getDay());
                        i.putExtra("profileType", profile.getProfileType());
                        i.putExtra("companyName", profile.getCompanyName());

                        i.putExtra("public_phone", profile.getPublicPhone());
                        i.putExtra("public_email", profile.getPublicEmail());

                        i.putExtra("fullname", profile.getFullname());
                        i.putExtra("location", profile.getLocation());
                        i.putExtra("facebookPage", profile.getFacebookPage());
                        i.putExtra("instagramPage", profile.getInstagramPage());
                        i.putExtra("bio", profile.getBio());
                        startActivityForResult(i, PROFILE_EDIT);
                    }

                } else {

                    if (App.getInstance().getId() == 0) {

                        Intent intent = new Intent(TAG_SHOW_AUTH_BOTTOM_SHEET);
                        getContext().sendBroadcast(intent);

                    } else {

                        addFollower();
                    }
                }
            }
        });

        mProfileActionSendMessage.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (App.getInstance().getAccount().getId() != 0) {

                    Intent i = new Intent(getActivity(), ChatActivity.class);
                    i.putExtra("chatId", 0);
                    i.putExtra("profileId", profile.getId());
                    i.putExtra("withProfile", profile.getFullname());

                    i.putExtra("with_user_username", profile.getUsername());
                    i.putExtra("with_user_fullname", profile.getFullname());
                    i.putExtra("with_user_photo_url", profile.getNormalPhotoUrl());

                    i.putExtra("with_user_state", profile.getState());
                    i.putExtra("with_user_verified", profile.getVerified());

                    startActivity(i);

                } else {

                    Intent intent = new Intent(TAG_SHOW_AUTH_BOTTOM_SHEET);
                    getContext().sendBroadcast(intent);
                }
            }
        });

        mProfileActionMore.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                showMoreDialog();
            }
        });

        mProfileActionVideoCall.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Helper helper = new Helper(getActivity());

                if (!helper.checkAgoraPermission()) {

                    requestAgoraPermission();

                } else {

                    agoraVideoCall();
                }
            }
        });

        // Start prepare Friends Spotlight

        mSuggestedSpotlightTitle = (TextView) rootView.findViewById(R.id.suggestedSpotlightTitle);
        mSuggestedSpotlightMoreButton = (Button) rootView.findViewById(R.id.suggestedSpotlightMoreBtn);
        mSuggestedSpotlight = (CardView) rootView.findViewById(R.id.suggestedSpotlight);
        mSuggestedSpotlightRecyclerView = (RecyclerView) rootView.findViewById(R.id.suggestedSpotlightRecyclerView);
        mSuggestedSpotlight.setVisibility(View.GONE);

        mSuggestedSpotlightRecyclerView.setLayoutManager(new LinearLayoutManager(getActivity(), LinearLayoutManager.HORIZONTAL, false));
        mSuggestedSpotlightRecyclerView.setAdapter(suggestedSpotlightAdapter);

        suggestedSpotlightAdapter.setOnItemClickListener(new FriendsSpotlightListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, Profile obj, int position) {

                Intent intent = new Intent(getActivity(), ProfileActivity.class);
                intent.putExtra("profileId", obj.getId());
                startActivity(intent);
            }
        });

        mRecyclerView = (RecyclerView) rootView.findViewById(R.id.recyclerView);

        itemsAdapter.setOnItemClickListener(new AdvancedItemListAdapterV2.OnItemClickListener() {

            @Override
            public void onItemClick(View v, Item obj, int position) {

                App.getInstance().getHomeItemsList().clear();
                App.getInstance().setHomeItemsList((ArrayList<Item>)itemsList.clone());

                Intent intent = new Intent(getActivity(), HomeActivity.class);
                intent.putExtra("position", position);
                startActivity(intent);
            }
        });

        marketAdapter.setOnItemClickListener(new MarketListAdapterV2.OnItemClickListener() {

            @Override
            public void onItemClick(View v, MarketItem obj, int position) {

                Intent intent = new Intent(getActivity(), MarketViewItemActivity.class);
                intent.putExtra("itemId", obj.getId());
                intent.putExtra("itemObj", (Parcelable) obj);
                startActivity(intent);
            }
        });

        final GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 3);
        mRecyclerView.setLayoutManager(mLayoutManager);
        mRecyclerView.setItemAnimator(new DefaultItemAnimator());
        mRecyclerView.setAdapter(itemsAdapter);

        mRecyclerView.setNestedScrollingEnabled(false);

        mNestedScrollView.setOnScrollChangeListener(new NestedScrollView.OnScrollChangeListener() {

            @Override
            public void onScrollChange(NestedScrollView v, int scrollX, int scrollY, int oldScrollX, int oldScrollY) {

                if (scrollY == (v.getChildAt(0).getMeasuredHeight() - v.getMeasuredHeight())) {

                    if (!loadingMore && (viewMore) && !(mProfileRefreshLayout.isRefreshing())) {

                        mProfileRefreshLayout.setRefreshing(true);

                        loadingMore = true;

                        getItems();
                    }
                }
            }
        });

        profileFullname = (TextView) rootView.findViewById(R.id.profileFullname);
        profileUsername = (TextView) rootView.findViewById(R.id.profileUsername);

        mProfileType = (TextView) rootView.findViewById(R.id.profileType);
        mProfileType.setVisibility(View.GONE);

        mItemsCount = (TextView) rootView.findViewById(R.id.profileItemsCount);
        mLikesCount = (TextView) rootView.findViewById(R.id.profileLikesCount);
        mFollowersCount = (TextView) rootView.findViewById(R.id.profileFollowersCount);
        mFollowingCount = (TextView) rootView.findViewById(R.id.profileFollowingsCount);

        mProfileItemsBtn = (MaterialRippleLayout) rootView.findViewById(R.id.profileItemsBtn);
        mProfileItemsBtn.setVisibility(View.GONE);
        mProfileLikesBtn = (MaterialRippleLayout) rootView.findViewById(R.id.profileLikesBtn);
        mProfileFollowersBtn = (MaterialRippleLayout) rootView.findViewById(R.id.profileFollowersBtn);
        mProfileFollowingBtn = (MaterialRippleLayout) rootView.findViewById(R.id.profileFollowingsBtn);

        //

        mProfileFollowersBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showCountersContent(1);
            }
        });

        mProfileFollowingBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                showCountersContent(0);
            }
        });

        mProfileLikesBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                //
            }
        });

        //

        mProfileInfoContainer = (LinearLayout) rootView.findViewById(R.id.profileInfoContainer);

        mProfilePhoneContainer = (LinearLayout) rootView.findViewById(R.id.profilePhoneContainer);
        mProfileEmailContainer = (LinearLayout) rootView.findViewById(R.id.profileEmailContainer);

        mProfilePhone = (TextView) rootView.findViewById(R.id.profilePhone);
        mProfileEmail = (TextView) rootView.findViewById(R.id.profileEmail);

        mProfileLocationContainer = (LinearLayout) rootView.findViewById(R.id.profileLocationContainer);
        profileOnlineIcon = (ImageView) rootView.findViewById(R.id.profileOnlineIcon);
        profileIcon = (ImageView) rootView.findViewById(R.id.profileIcon);

        mProfileStatusContainer = (LinearLayout) rootView.findViewById(R.id.profileStatusContainer);
        mProfileFacebookContainer = (LinearLayout) rootView.findViewById(R.id.profileFacebookContainer);
        mProfileSiteContainer = (LinearLayout) rootView.findViewById(R.id.profileSiteContainer);

        mProfileLocation = (TextView) rootView.findViewById(R.id.profileLocation);
        mProfileFacebookPage = (TextView) rootView.findViewById(R.id.profileFacebookUrl);
        mProfileInstagramPage = (TextView) rootView.findViewById(R.id.profileSiteUrl);
        mProfileBio = (TextView) rootView.findViewById(R.id.profileStatus);

        mProfileFacebookPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!profile.getFacebookPage().startsWith("https://") && !profile.getFacebookPage().startsWith("http://")){

                    profile.setFacebookPage("http://" + profile.getFacebookPage());
                }

                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(profile.getFacebookPage()));
                startActivity(i);
            }
        });

        mProfileInstagramPage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (!profile.getInstagramPage().startsWith("https://") && !profile.getInstagramPage().startsWith("http://")){

                    profile.setInstagramPage("http://" + profile.getInstagramPage());
                }

                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(profile.getInstagramPage()));
                startActivity(i);
            }
        });

        mSuggestedSpotlightMoreButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getActivity(), FinderActivity.class);
                i.putExtra("tab_position", 1);
                startActivity(i);
            }
        });

//        mProfileGiftsBtn.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View v) {
//
//                showProfileGifts(profile.getId());
//            }
//        });

        profilePhoto = (CircularImageView) rootView.findViewById(R.id.profilePhoto);
        profileCover = (ImageView) rootView.findViewById(R.id.profileCover);

        profilePhoto.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                if (profile.getNormalPhotoUrl().length() > 0) {

                    Intent i = new Intent(getActivity(), PhotoViewActivity.class);
                    i.putExtra("imgUrl", profile.getNormalPhotoUrl());
                    startActivity(i);
                }
            }
        });

        mFeelingIcon = (CircularImageView) rootView.findViewById(R.id.feelingIcon);
        mFeelingIcon.setVisibility(View.GONE);

        mFeelingIcon.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (App.getInstance().getId() == profile.getId()) {

                    choiceFeelingDialog();
                }
            }
        });

        if (profile.getFullname() == null || profile.getFullname().length() == 0) {

            if (!pager && !loaded) {


                if (App.getInstance().isConnected()) {

                    showLoadingScreen();
                    getData();

                    Log.e("Profile", "OnReload");

                } else {

                    showErrorScreen();
                }
            }

        } else {

            if (App.getInstance().isConnected()) {

                if (profile.getState() == ACCOUNT_STATE_ENABLED) {

                    showContentScreen();

                    loadingComplete();
                    updateProfile();

                } else {

                    showDisabledScreen();
                }

            } else {

                showErrorScreen();
            }
        }

        // Inflate the layout for this fragment
        return rootView;
    }

    private void showCountersContent(int pageId) {

        if (App.getInstance().getId() == 0) {

            Intent intent = new Intent(TAG_SHOW_AUTH_BOTTOM_SHEET);
            getContext().sendBroadcast(intent);

        } else {

            Intent i = new Intent(getActivity(), CountersContentActivity.class);
            i.putExtra("pageId", pageId);
            i.putExtra("profileId", profile.getId());
            i.putExtra("followingCount", profile.getFollowingsCount());
            i.putExtra("followersCount", profile.getFollowersCount());
            i.putExtra("fullname", profile.getFullname());
            startActivity(i);
        }
    }

    @Override
    public void setUserVisibleHint(boolean isVisibleToUser) {

        super.setUserVisibleHint(isVisibleToUser);

        if (isVisibleToUser) {

            Handler handler = new Handler();

            handler.postDelayed(new Runnable() {
                @Override
                public void run() {

                    if (isAdded()) {

                        if (!loaded) {

                            showLoadingScreen();
                            getData();
                        }
                    }
                }
            }, 50);
        }
    }

    public void onDestroyView() {

        super.onDestroyView();

        hidepDialog();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putInt("itemId", itemId);

        outState.putBoolean("restore", restore);
        outState.putBoolean("loading", loading);
        outState.putBoolean("preload", preload);
        outState.putBoolean("loaded", loaded);
        outState.putBoolean("pager", pager);

        outState.putParcelable("profileObj", profile);
        outState.putParcelableArrayList(STATE_LIST, itemsList);
        outState.putParcelableArrayList(STATE_LIST_2, marketList);
        outState.putParcelableArrayList(STATE_FRIENDS_SPOTLIGHT_LIST, suggestedSpotlightList);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PROFILE_EDIT && resultCode == getActivity().RESULT_OK) {

            profile.setProfileType(data.getIntExtra("profileType", 0));
            profile.setCompanyName(data.getStringExtra("companyName"));
            profile.setFullname(data.getStringExtra("fullname"));
            profile.setLocation(data.getStringExtra("location"));
            profile.setFacebookPage(data.getStringExtra("facebookPage"));
            profile.setInstagramPage(data.getStringExtra("instagramPage"));
            profile.setBio(data.getStringExtra("bio"));

            profile.setPublicPhone(data.getStringExtra("public_phone"));
            profile.setPublicEmail(data.getStringExtra("public_email"));

            profile.setSex(data.getIntExtra("sex", 0));

            profile.setYear(data.getIntExtra("year", 0));
            profile.setMonth(data.getIntExtra("month", 0));
            profile.setDay(data.getIntExtra("day", 0));

            updateProfile();

        } else if (requestCode == PROFILE_NEW_POST && resultCode == getActivity().RESULT_OK) {

            getData();

        } else if (requestCode == PROFILE_FEELINGS && resultCode == getActivity().RESULT_OK) {


            profile.setMood(data.getIntExtra("feeling", 0));

            Log.e("Return", Integer.toString(profile.getMood()));

            updateFeeling();

        } else if (requestCode == ITEM_EDIT && resultCode == getActivity().RESULT_OK) {

            int position = data.getIntExtra("position", 0);

            if (data.getExtras() != null) {

                Item item = (Item) data.getExtras().getParcelable("item");

                itemsList.set(position, item);
            }

            itemsAdapter.notifyDataSetChanged();

        } else if (requestCode == ITEM_REPOST && resultCode == getActivity().RESULT_OK) {

            int position = data.getIntExtra("position", 0);

            Item item = itemsList.get(position);

            item.setMyRePost(true);
            item.setRePostsCount(item.getRePostsCount() + 1);

            itemsAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onRefresh() {

        if (App.getInstance().isConnected()) {

            getData();

        } else {

            mProfileRefreshLayout.setRefreshing(false);
        }
    }

    private void agoraVideoCall() {

        Intent intent = new Intent(getActivity(), AgoraVideoCallActivity.class);
        intent.putExtra("to_user_id", profile.getId());
        intent.putExtra("to_user_username", profile.getUsername());
        intent.putExtra("to_user_fullname", profile.getFullname());
        intent.putExtra("to_user_photo_url", profile.getLowPhotoUrl());
        startActivity(intent);
    }

    public void updateFeeling() {

        if (profile.getMood() > 0) {

            mFeelingIcon.setVisibility(View.VISIBLE);

            showFeeling(Constants.WEB_SITE + "feelings/" + Integer.toString(profile.getMood()) + ".png");

        } else {

            if (App.getInstance().getId() == profile.getId()) {

                mFeelingIcon.setVisibility(View.VISIBLE);
                mFeelingIcon.setImageResource(R.drawable.ic_mood);

            } else {

                mFeelingIcon.setVisibility(View.GONE);
            }
        }

        mFeelingIcon.setVisibility(View.GONE);
    }

    public void updateProfile() {

        updateFeeling();

        if (profile.getLastActive() == 0) {

            profileOnlineIcon.setVisibility(View.GONE);

        } else {

            if (profile.isOnline()) {

                profileOnlineIcon.setVisibility(View.VISIBLE);

            } else {

                profileOnlineIcon.setVisibility(View.GONE);
            }
        }

        // Profile Info

        mProfileInfoContainer.setVisibility(View.GONE);

        if (profile.getBio().length() != 0 || profile.getFacebookPage().length() != 0 || profile.getInstagramPage().length() != 0 || profile.getLocation().length() != 0 || profile.getPublicEmail().length() != 0) {

            mProfileInfoContainer.setVisibility(View.VISIBLE);
        }

        profileUsername.setText("@" + profile.getUsername());
        mProfileLocation.setText(profile.getLocation());
        mProfileFacebookPage.setText(profile.getFacebookPage());
        mProfileInstagramPage.setText(profile.getInstagramPage());
        mProfileBio.setText(profile.getBio());
        mProfilePhone.setText(profile.getPublicPhone());
        mProfileEmail.setText(profile.getPublicEmail());

        mProfileActionMore.setVisibility(View.GONE);

        // update action buttons is your profile
        if (profile.getId() == App.getInstance().getId()) {

            mProfileActionSendMessage.setVisibility(View.GONE);

            mSetProfilePhotoButton.setVisibility(View.VISIBLE);
            mSetProfileCoverButton.setVisibility(View.VISIBLE);

            mProfileActionVideoCall.setVisibility(View.GONE);

        } else {

            mProfileActionVideoCall.setVisibility(View.GONE);

            if (App.getInstance().getAgoraSettings().getAppEnabled() == 1 && profile.getAllowVideoCalls() == 1 && !profile.isInBlackList()) {

                mProfileActionVideoCall.setVisibility(View.VISIBLE);
            }

            //

            mSetProfilePhotoButton.setVisibility(View.GONE);
            mSetProfileCoverButton.setVisibility(View.GONE);

            mProfileActionSendMessage.setVisibility(View.GONE);

            if (!profile.isInBlackList()) {

                if ((profile.getAllowMessages() == 1) || (profile.getAllowMessages() == 0 && profile.isFollower())) {

                    mProfileActionSendMessage.setVisibility(View.VISIBLE);
                }
            }
        }

        if (profile.getLocation() != null && profile.getLocation().length() != 0) {

            mProfileLocationContainer.setVisibility(View.VISIBLE);

        } else {

            mProfileLocationContainer.setVisibility(View.GONE);
        }

        if (profile.getFacebookPage() != null && profile.getFacebookPage().length() != 0) {

            mProfileFacebookContainer.setVisibility(View.VISIBLE);

        } else {

            mProfileFacebookContainer.setVisibility(View.GONE);
        }

        //

        if (profile.getPublicPhone() != null && profile.getPublicPhone().length() != 0) {

            mProfilePhoneContainer.setVisibility(View.VISIBLE);

        } else {

            mProfilePhoneContainer.setVisibility(View.GONE);
        }

        mProfilePhoneContainer.setVisibility(View.GONE);

        //

        if (profile.getPublicEmail() != null && profile.getPublicEmail().length() != 0) {

            mProfileEmailContainer.setVisibility(View.VISIBLE);

        } else {

            mProfileEmailContainer.setVisibility(View.GONE);
        }

        //

        if (profile.getInstagramPage() != null && profile.getInstagramPage().length() != 0) {

            mProfileSiteContainer.setVisibility(View.VISIBLE);

        } else {

            mProfileSiteContainer.setVisibility(View.GONE);
        }

        if (profile.getBio() != null && profile.getBio().length() != 0) {

            mProfileStatusContainer.setVisibility(View.VISIBLE);

        } else {

            mProfileStatusContainer.setVisibility(View.GONE);
        }

        updateFullname();
        updateItemsCount();
        updateGiftsCount();
        updateProfileActionMainButton();

        showPhoto(profile.getLowPhotoUrl());

        showCover(profile.getNormalCoverUrl());

        showContentScreen();

        if (this.isVisible()) {

            try {

                getActivity().invalidateOptionsMenu();

            } catch (Exception e) {

                e.printStackTrace();
            }
        }
    }

    private void updateFullname() {

        if (!isMainScreen) getActivity().setTitle(getString(R.string.nav_profile));

        profileUsername.setText("@" + profile.getUsername());

        profileFullname.setText(profile.getFullname());

        if (!profile.isVerified()) {

            profileIcon.setVisibility(View.GONE);

        } else {

            profileIcon.setVisibility(View.VISIBLE);
        }
    }

    private void updateGiftsCount() {

        //mGiftsCount.setText(Integer.toString(profile.getGiftsCount()));
    }

    private void updateItemsCount() {

        mItemsCount.setText(Integer.toString(profile.getItemsCount()));
        mLikesCount.setText(Integer.toString(profile.getLikesCount()));
        mFollowersCount.setText(Integer.toString(profile.getFollowersCount()));
        mFollowingCount.setText(Integer.toString(profile.getFollowingsCount()));
    }

    public void updateProfileActionMainButton() {

        if (profile.getId() == App.getInstance().getId()) {

            mProfileActionMain.setText(R.string.action_profile_edit);

        } else {

            if (profile.isFollow()) {

                mProfileActionMain.setText(R.string.action_unfollow);
                // mAddFriendIcon.setImageResource(R.drawable.ic_friend_cancel);

            } else {

                mProfileActionMain.setText(R.string.action_follow);
                //mAddFriendIcon.setImageResource(R.drawable.ic_friend_add);
            }
        }
    }

    public void getData() {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_PROFILE_GET, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "ProfileFragment Not Added to Activity");

                            return;
                        }

                        try {

                            if (!response.getBoolean("error")) {

                                profile = new Profile(response);

                                changeAccessMode();

//                                if (profile.getItemsCount() > 0) {
//
//                                    getItems();
//                                }

                                getItems();

                                if (profile.getState() == ACCOUNT_STATE_ENABLED) {

                                    showContentScreen();

                                    updateProfile();

                                } else {

                                    showDisabledScreen();
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                            Log.d("Response GetData", response.toString());

                        } finally {

                            getSuggestedSpotlight();

                            loaded = true;
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "ProfileFragment Not Added to Activity");

                    return;
                }

                Log.e("Error GetData", error.toString());

                showErrorScreen();

                loaded = true;
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("profileId", Long.toString(profile_id));

                return params;
            }
        };

        jsonReq.setRetryPolicy(new RetryPolicy() {

            @Override
            public int getCurrentTimeout() {

                return 50000;
            }

            @Override
            public int getCurrentRetryCount() {

                return 50000;
            }

            @Override
            public void retry(VolleyError error) throws VolleyError {

            }
        });

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void getSuggestedSpotlight() {

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_USERS_SEARCH, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "ProfileFragment Not Added to Activity");

                            return;
                        }

                        try {

                            suggestedSpotlightList.clear();

                            if (!response.getBoolean("error")) {

                                if (response.has("items")) {

                                    JSONArray friendsArray = response.getJSONArray("items");

                                    arrayLength = friendsArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < friendsArray.length(); i++) {

                                            JSONObject userObj = (JSONObject) friendsArray.get(i);

                                            Profile item = new Profile(userObj);

                                            suggestedSpotlightList.add(item);

                                            suggestedSpotlightAdapter.notifyItemChanged(suggestedSpotlightList.size());
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.d("getSuggestedSpotlight", response.toString());

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "ProfileFragment Not Added to Activity");

                    return;
                }

                Log.e("getSuggestedSpotlight", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("itemId", Integer.toString(itemId));
                params.put("gender", Integer.toString(-1));
                params.put("online", Integer.toString(-1));
                params.put("photo", Integer.toString(1));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void addFollower() {

        showpDialog();

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_PROFILE_FOLLOW, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "ProfileFragment Not Added to Activity");

                            return;
                        }

                        try {

                            if (!response.getBoolean("error")) {

                                profile.setFollow(response.getBoolean("follow"));
                                profile.setFollowersCount(response.getInt("followersCount"));

                                updateProfileActionMainButton();

                                changeAccessMode();
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            hidepDialog();

                            updateItemsCount();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "ProfileFragment Not Added to Activity");

                    return;
                }

                hidepDialog();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("profileId", Long.toString(profile_id));

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void changeAccessMode() {

        if (App.getInstance().getId() == profile.getId() || profile.isFriend()) {

            accessMode = 1;

        } else {

            accessMode = 0;
        }
    }

    public void showFeeling(String imgUrl) {

        if (imgUrl != null && imgUrl.length() > 0) {

            ImageLoader imageLoader = App.getInstance().getImageLoader();

            imageLoader.get(imgUrl, ImageLoader.getImageListener(mFeelingIcon, R.drawable.mood, R.drawable.mood));
        }
    }

    public void showPhoto(String photoUrl) {

        if (photoUrl.length() > 0) {

            ImageLoader imageLoader = App.getInstance().getImageLoader();

            imageLoader.get(photoUrl, ImageLoader.getImageListener(profilePhoto, R.drawable.profile_default_photo, R.drawable.profile_default_photo));
        }
    }

    public void showCover(String coverUrl) {

        if (coverUrl.length() > 0) {

            ImageLoader imageLoader = App.getInstance().getImageLoader();

            imageLoader.get(coverUrl, ImageLoader.getImageListener(profileCover, R.drawable.profile_default_cover, R.drawable.profile_default_cover));

            if (Build.VERSION.SDK_INT > 15) {

                profileCover.setImageAlpha(200);
            }
        }
    }

    public void getItems() {

        if (loadingMore) {

            mProfileRefreshLayout.setRefreshing(true);

        } else{

            if (sectionId == 2) {

                mRecyclerView.setAdapter(marketAdapter);

            } else {

                mRecyclerView.setAdapter(itemsAdapter);
            }

            itemId = 0;

            mMessage.setText(R.string.msg_loading_2);
            mMessage.setVisibility(View.VISIBLE);
        }

        if (sectionId == 1 && App.getInstance().getId() != profile.getId() && profile.getAllowShowLikedVideos() == 0) {

            mMessage.setText(R.string.label_liked_videos_privacy);
            mMessage.setVisibility(View.VISIBLE);

            return;
        }

        String url = METHOD_WALL_GET;

        switch (sectionId) {

            case 1: {

                url = METHOD_FAVORITES_GET;

                break;
            }

            case 2: {

                url = METHOD_MARKET_GET;

                break;
            }

            case 3: {

                url = METHOD_PRIVATE_ITEMS_GET;

                break;
            }

            case 0: {

                url = METHOD_WALL_GET;

                break;
            }
        }

        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, url, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "ProfileFragment Not Added to Activity");

                            return;
                        }

                        try {

                            if (!loadingMore) {

                                if (sectionId == 2) {

                                    marketList.clear();
                                    marketAdapter.notifyDataSetChanged();

                                } else {

                                    itemsList.clear();
                                    itemsAdapter.notifyDataSetChanged();
                                }
                            }

                            arrayLength = 0;

                            if (!response.getBoolean("error")) {

                                itemId = response.getInt("itemId");

                                if (response.has("items")) {

                                    JSONArray itemsArray = response.getJSONArray("items");

                                    arrayLength = itemsArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < itemsArray.length(); i++) {

                                            JSONObject itemObj = (JSONObject) itemsArray.get(i);

                                            if (sectionId == 2) {

                                                MarketItem item = new MarketItem(itemObj);

                                                marketList.add(item);
                                                marketAdapter.notifyItemChanged(marketList.size());

                                            } else {

                                                Item item = new Item(itemObj);
                                                item.setAd(0);

                                                itemsList.add(item);
                                                itemsAdapter.notifyItemChanged(itemsList.size());
                                            }
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("getItems", response.toString());

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("ERROR", "ProfileFragment Not Added to Activity");

                    return;
                }

                loadingComplete();

                Log.e("Profile getItems Error", error.toString());
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("accountId", Long.toString(App.getInstance().getId()));
                params.put("accessToken", App.getInstance().getAccessToken());
                params.put("profileId", Long.toString(profile.getId()));
                params.put("itemId", Integer.toString(itemId));
                params.put("language", App.getInstance().getLanguage());

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void loadingComplete() {

        if (arrayLength == LIST_ITEMS) {

            viewMore = true;

        } else {

            viewMore = false;
        }

        if (suggestedSpotlightList.size() != 0) {

            mSuggestedSpotlight.setVisibility(View.VISIBLE);
        }

        if (mRecyclerView.getAdapter().getItemCount() == 0) {

            mMessage.setText(R.string.label_empty_list);
            mMessage.setVisibility(View.VISIBLE);

        } else {

            mMessage.setVisibility(View.GONE);
        }

        mProfileRefreshLayout.setRefreshing(false);

        loadingMore = false;
    }

    public void showLoadingScreen() {

        if (!isMainScreen) getActivity().setTitle(getText(R.string.title_activity_profile));

        mProfileRefreshLayout.setVisibility(View.GONE);
        mProfileErrorScreen.setVisibility(View.GONE);
        mProfileDisabledScreen.setVisibility(View.GONE);

        mProfileLoadingScreen.setVisibility(View.VISIBLE);

        loadingComplete = false;
    }

    public void showErrorScreen() {

        if (!isMainScreen) getActivity().setTitle(getText(R.string.title_activity_profile));

        mProfileLoadingScreen.setVisibility(View.GONE);
        mProfileDisabledScreen.setVisibility(View.GONE);
        mProfileRefreshLayout.setVisibility(View.GONE);

        mProfileErrorScreen.setVisibility(View.VISIBLE);

        loadingComplete = false;
    }

    public void showDisabledScreen() {

        if (profile.getState() != ACCOUNT_STATE_ENABLED) {

            mProfileDisabledScreenMsg.setText(getText(R.string.msg_account_blocked));
        }

        getActivity().setTitle(getText(R.string.label_account_disabled));

        mProfileRefreshLayout.setVisibility(View.GONE);
        mProfileLoadingScreen.setVisibility(View.GONE);
        mProfileErrorScreen.setVisibility(View.GONE);

        mProfileDisabledScreen.setVisibility(View.VISIBLE);

        loadingComplete = false;
    }

    public void showContentScreen() {

        if (!isMainScreen) {

            getActivity().setTitle(profile.getFullname());
        }

        if (App.getInstance().getAccount().getAccountFree() != 0 && profile.getId() == App.getInstance().getId()) {

            if (App.getInstance().getTooltipsSettings().isAllowShowLoginCreateTooltip()) {

                mLoginCreateTooltip.setVisibility(View.VISIBLE);
            }
        }

        mProfileDisabledScreen.setVisibility(View.GONE);
        mProfileLoadingScreen.setVisibility(View.GONE);
        mProfileErrorScreen.setVisibility(View.GONE);

        mProfileRefreshLayout.setVisibility(View.VISIBLE);
        mProfileRefreshLayout.setRefreshing(false);

        loadingComplete = true;
        restore = true;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);

        menu.clear();

        inflater.inflate(R.menu.menu_profile, menu);
    }

    @Override
    public void onPrepareOptionsMenu(Menu menu) {

        super.onPrepareOptionsMenu(menu);

        if (loadingComplete) {

            if (profile.getState() != ACCOUNT_STATE_ENABLED) {

                //hide all menu items
                hideMenuItems(menu, false);
            }

            if (App.getInstance().getId() == profile_id) {

                menu.removeItem(R.id.action_menu);

                //hide all menu items
                hideMenuItems(menu, false);

            } else {

                //show all menu items
                hideMenuItems(menu, true);
            }

        } else {

            //hide all menu items
            hideMenuItems(menu, false);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        switch (item.getItemId()) {

            case R.id.action_menu: {

                showMoreDialog();

                return true;
            }

            default: {

                return super.onOptionsItemSelected(item);
            }
        }
    }

    private void hideMenuItems(Menu menu, boolean visible) {

        for (int i = 0; i < menu.size(); i++){

            menu.getItem(i).setVisible(visible);
        }
    }

    protected void initpDialog() {

        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage(getString(R.string.msg_loading));
        pDialog.setCancelable(false);
    }

    protected void showpDialog() {

        if (!pDialog.isShowing()) pDialog.show();
    }

    protected void hidepDialog() {

        if (pDialog.isShowing()) pDialog.dismiss();
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    public void profileReport() {

        String[] profile_report_categories = new String[] {

                getText(R.string.label_profile_report_0).toString(),
                getText(R.string.label_profile_report_1).toString(),
                getText(R.string.label_profile_report_2).toString(),
                getText(R.string.label_profile_report_3).toString(),

        };

        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
        alertDialog.setTitle(getText(R.string.label_post_report_title));

        alertDialog.setSingleChoiceItems(profile_report_categories, 0, null);
        alertDialog.setCancelable(true);

        alertDialog.setNegativeButton(getText(R.string.action_cancel), new DialogInterface.OnClickListener() {

            @Override
            public void onClick(DialogInterface dialog, int which) {

                dialog.cancel();
            }
        });

        alertDialog.setPositiveButton(getText(R.string.action_ok), new DialogInterface.OnClickListener() {

            public void onClick(DialogInterface dialog, int which) {

                AlertDialog alert = (AlertDialog) dialog;
                int reason = alert.getListView().getCheckedItemPosition();

                Api api = new Api(getActivity());

                api.newReport(profile.getId(), REPORT_TYPE_PROFILE, reason);

                Toast.makeText(getActivity(), getText(R.string.label_profile_reported), Toast.LENGTH_SHORT).show();
            }
        });

        alertDialog.show();
    }

    public void profileBlock() {

        if (!profile.isBlocked()) {

            AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
            alertDialog.setTitle(getText(R.string.action_block));

            alertDialog.setMessage("@" + profile.getUsername() + " " + getText(R.string.label_block_msg) + " @" + profile.getUsername() + ".");
            alertDialog.setCancelable(true);

            alertDialog.setNegativeButton(getText(R.string.action_no), new DialogInterface.OnClickListener() {

                @Override
                public void onClick(DialogInterface dialog, int which) {

                    dialog.cancel();
                }
            });

            alertDialog.setPositiveButton(getText(R.string.action_yes), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {

                    loading = true;

                    showpDialog();

                    CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_BLACKLIST_ADD, null,
                            new Response.Listener<JSONObject>() {
                                @Override
                                public void onResponse(JSONObject response) {

                                    if (!isAdded() || getActivity() == null) {

                                        Log.e("ERROR", "ProfileFragment Not Added to Activity");

                                        return;
                                    }

                                    try {

                                        if (!response.getBoolean("error")) {

                                            profile.setBlocked(true);

                                            Toast.makeText(getActivity(), getString(R.string.msg_profile_added_to_blacklist), Toast.LENGTH_SHORT).show();
                                        }

                                    } catch (JSONException e) {

                                        e.printStackTrace();

                                    } finally {

                                        loading = false;

                                        hidepDialog();
                                    }
                                }
                            }, new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {

                            if (!isAdded() || getActivity() == null) {

                                Log.e("ERROR", "ProfileFragment Not Added to Activity");

                                return;
                            }

                            loading = false;

                            hidepDialog();
                        }
                    }) {

                        @Override
                        protected Map<String, String> getParams() {
                            Map<String, String> params = new HashMap<String, String>();
                            params.put("accountId", Long.toString(App.getInstance().getId()));
                            params.put("accessToken", App.getInstance().getAccessToken());
                            params.put("profileId", Long.toString(profile.getId()));
                            params.put("reason", "example");

                            return params;
                        }
                    };

                    App.getInstance().addToRequestQueue(jsonReq);
                }
            });

            alertDialog.show();

        } else {

            loading = true;

            showpDialog();

            CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_BLACKLIST_REMOVE, null,
                    new Response.Listener<JSONObject>() {
                        @Override
                        public void onResponse(JSONObject response) {

                            if (!isAdded() || getActivity() == null) {

                                Log.e("ERROR", "ProfileFragment Not Added to Activity");

                                return;
                            }

                            try {

                                if (!response.getBoolean("error")) {

                                    profile.setBlocked(false);

                                    Toast.makeText(getActivity(), getString(R.string.msg_profile_removed_from_blacklist), Toast.LENGTH_SHORT).show();
                                }

                            } catch (JSONException e) {

                                e.printStackTrace();

                            } finally {

                                loading = false;

                                hidepDialog();
                            }
                        }
                    }, new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {

                    if (!isAdded() || getActivity() == null) {

                        Log.e("ERROR", "ProfileFragment Not Added to Activity");

                        return;
                    }

                    loading = false;

                    hidepDialog();
                }
            }) {

                @Override
                protected Map<String, String> getParams() {
                    Map<String, String> params = new HashMap<String, String>();
                    params.put("accountId", Long.toString(App.getInstance().getId()));
                    params.put("accessToken", App.getInstance().getAccessToken());
                    params.put("profileId", Long.toString(profile.getId()));

                    return params;
                }
            };

            App.getInstance().addToRequestQueue(jsonReq);
        }
    }

    public Boolean uploadFile(File file, final int type) {

        loading = true;

        pDialog.setProgressStyle(ProgressDialog.STYLE_HORIZONTAL);
        pDialog.setProgressNumberFormat(null);
        pDialog.setProgress(0);
        pDialog.setMax(100);

        showpDialog();

        final CountingRequestBody.Listener progressListener = new CountingRequestBody.Listener() {
            @Override
            public void onRequestProgress(long bytesRead, long contentLength) {

                if (bytesRead >= contentLength) {

                    if (isAdded() && getActivity() != null && pDialog != null) {

                        requireActivity().runOnUiThread(new Runnable() {

                            public void run() {
                                //            progressBar.setVisibility(View.GONE);
                            }
                        });
                    }

                } else {

                    if (contentLength > 0) {

                        final int progress = (int) (((double) bytesRead / contentLength) * 100);

                        if (isAdded() && getActivity() != null && pDialog != null) {

                            requireActivity().runOnUiThread(new Runnable() {

                                public void run() {

                                    pDialog.setProgress(progress);
//                                    progressBar.setVisibility(View.VISIBLE);
//                                    progressBar.setProgress(progress);
                                }
                            });
                        }

                        if (progress >= 100) {

                            if (isAdded() && getActivity() != null && pDialog != null) {

                                pDialog.setProgressStyle(ProgressDialog.STYLE_SPINNER);
                            }
                        }

                        Log.e("uploadProgress called", progress+" ");
                    }
                }
            }
        };

        final okhttp3.OkHttpClient client = new okhttp3.OkHttpClient().newBuilder().addNetworkInterceptor(new Interceptor() {

                    @NonNull
                    @Override
                    public okhttp3.Response intercept(@NonNull Chain chain) throws IOException {

                        okhttp3.Request originalRequest = chain.request();

                        if (originalRequest.body() == null) {

                            return chain.proceed(originalRequest);
                        }

                        okhttp3.Request progressRequest = originalRequest.newBuilder()
                                .method(originalRequest.method(),
                                        new CountingRequestBody(originalRequest.body(), progressListener))
                                .build();

                        return chain.proceed(progressRequest);

                    }
                })
                .build();

        Uri uris = Uri.fromFile(file);
        String fileExtension = MimeTypeMap.getFileExtensionFromUrl(uris.toString());
        String mime = MimeTypeMap.getSingleton().getMimeTypeFromExtension(fileExtension.toLowerCase());

        //client.setProtocols(Arrays.asList(Protocol.HTTP_1_1));

        try {

            RequestBody requestBody = new MultipartBody.Builder()
                    .setType(MultipartBody.FORM)
                    .addFormDataPart("uploaded_file", file.getName(), RequestBody.create(file, MediaType.parse(mime)))
                    .addFormDataPart("accountId", Long.toString(App.getInstance().getId()))
                    .addFormDataPart("accessToken", App.getInstance().getAccessToken())
                    .addFormDataPart("imgType", Integer.toString(type))
                    .build();

            okhttp3.Request request = new okhttp3.Request.Builder()
                    .url(METHOD_PROFILE_UPLOAD_IMAGE)
                    .post(requestBody)
                    .build();

            client.newCall(request).enqueue(new Callback() {

                @Override
                public void onFailure(Call call, IOException e) {

                    loading = false;

                    hidepDialog();

                    Log.e("failure", request.toString());
                }

                @Override
                public void onResponse(@NonNull Call call, @NonNull okhttp3.Response response) throws IOException {

                    String jsonData = response.body().string();

                    Log.e("response", jsonData);

                    try {

                        JSONObject result = new JSONObject(jsonData);

                        if (!result.getBoolean("error")) {

                            switch (type) {

                                case 0: {

                                    profile.setLowPhotoUrl(result.getString("lowPhotoUrl"));
                                    profile.setBigPhotoUrl(result.getString("bigPhotoUrl"));
                                    profile.setNormalPhotoUrl(result.getString("normalPhotoUrl"));

                                    App.getInstance().getAccount().setNormalPhotoUrl(result.getString("lowPhotoUrl"));

                                    break;
                                }

                                default: {

                                    profile.setNormalCoverUrl(result.getString("normalCoverUrl"));

                                    App.getInstance().getAccount().setNormalCoverUrl(result.getString("normalCoverUrl"));

                                    break;
                                }
                            }
                        }

                        Log.d("My App", response.toString());

                    } catch (Throwable t) {

                        Log.e("My App", "Could not parse malformed JSON: \"" + response.body().string() + "\"");

                    } finally {

                        loading = false;

                        hidepDialog();

                        getData();
                    }

                }
            });

            return true;

        } catch (Exception ex) {
            // Handle the error

            loading = false;

            hidepDialog();
        }

        return false;
    }

    public void showProfileGifts(long profileId) {

        if (profile.getAllowShowMyGifts() == 0 || App.getInstance().getId() == profile.getId()) {

            Intent intent = new Intent(getActivity(), GiftsActivity.class);
            intent.putExtra("profileId", profileId);
            startActivity(intent);

        } else {

            if (profile.getAllowShowMyGifts() == 1 && profile.isFriend()) {

                Intent intent = new Intent(getActivity(), GiftsActivity.class);
                intent.putExtra("profileId", profileId);
                startActivity(intent);
            }
        }
    }

    private void showMoreDialog() {

        if (mBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {

            mBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }

        final View view = getLayoutInflater().inflate(R.layout.profile_sheet_list, null);

        // Close

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        //

        MaterialRippleLayout mRefreshButton = (MaterialRippleLayout) view.findViewById(R.id.refresh_button);
        MaterialRippleLayout mEditButton = (MaterialRippleLayout) view.findViewById(R.id.edit_button);
        MaterialRippleLayout mGiftButton = (MaterialRippleLayout) view.findViewById(R.id.gift_button);
        MaterialRippleLayout mOpenUrlButton = (MaterialRippleLayout) view.findViewById(R.id.open_url_button);
        MaterialRippleLayout mCopyUrlButton = (MaterialRippleLayout) view.findViewById(R.id.copy_url_button);
        MaterialRippleLayout mReportButton = (MaterialRippleLayout) view.findViewById(R.id.report_button);

        MaterialRippleLayout mBlockButton = (MaterialRippleLayout) view.findViewById(R.id.block_button);
        ImageView mBlockIcon = (ImageView) view.findViewById(R.id.block_icon);
        TextView mBlockTitle = (TextView) view.findViewById(R.id.block_label);

        if (!WEB_SITE_AVAILABLE) {

            mOpenUrlButton.setVisibility(View.GONE);
            mCopyUrlButton.setVisibility(View.GONE);
        }

        if (App.getInstance().getId() == profile.getId()) {

            mBlockButton.setVisibility(View.GONE);
            mReportButton.setVisibility(View.GONE);
            mGiftButton.setVisibility(View.GONE);
            mEditButton.setVisibility(View.VISIBLE);

        } else {

            mBlockButton.setVisibility(View.VISIBLE);
            mReportButton.setVisibility(View.VISIBLE);
            mGiftButton.setVisibility(View.GONE);
            mEditButton.setVisibility(View.GONE);

            if (profile.isBlocked()) {

                mBlockIcon.setImageResource(R.drawable.ic_blacklist_remove);
                mBlockTitle.setText(getString(R.string.action_unblock));

            } else {

                mBlockIcon.setImageResource(R.drawable.ic_blacklist);
                mBlockTitle.setText(getString(R.string.action_block));
            }

            mReportButton.setVisibility(View.VISIBLE);
        }

        if (App.getInstance().getId() == 0) {

            mBlockButton.setVisibility(View.GONE);
        }

        mRefreshButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                mProfileRefreshLayout.setRefreshing(true);
                onRefresh();
            }
        });

        mEditButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                if (App.getInstance().getId() == profile.getId()) {

                    Intent i = new Intent(getActivity(), AccountSettingsActivity.class);
                    i.putExtra("profileId", App.getInstance().getId());
                    i.putExtra("sex", profile.getSex());
                    i.putExtra("year", profile.getYear());
                    i.putExtra("month", profile.getMonth());
                    i.putExtra("day", profile.getDay());
                    i.putExtra("profileType", profile.getProfileType());
                    i.putExtra("companyName", profile.getCompanyName());
                    i.putExtra("fullname", profile.getFullname());
                    i.putExtra("location", profile.getLocation());
                    i.putExtra("facebookPage", profile.getFacebookPage());
                    i.putExtra("instagramPage", profile.getInstagramPage());
                    i.putExtra("bio", profile.getBio());
                    startActivityForResult(i, PROFILE_EDIT);
                }
            }
        });

        mGiftButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                if (!profile.isInBlackList()) {

                    choiceGiftDialog();

                } else {

                    Toast.makeText(getActivity(), getString(R.string.error_action), Toast.LENGTH_SHORT).show();
                }
            }
        });

        mBlockButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                profileBlock();
            }
        });

        mReportButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                profileReport();
            }
        });

        mCopyUrlButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                ClipboardManager clipboard = (ClipboardManager) getActivity().getSystemService(getActivity().CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText(profile.getUsername(), API_DOMAIN + profile.getUsername());
                clipboard.setPrimaryClip(clip);

                Toast.makeText(getActivity(), getText(R.string.msg_profile_link_copied), Toast.LENGTH_SHORT).show();
            }
        });

        mOpenUrlButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setData(Uri.parse(API_DOMAIN + profile.getUsername()));
                startActivity(i);
            }
        });


        mBottomSheetDialog = new BottomSheetDialog(getActivity());
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    private void choiceImage() {

        if (mBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {

            mBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
        }

        final View view = getLayoutInflater().inflate(R.layout.choice_image_sheet_list, null);

        //

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        //

        MaterialRippleLayout mGalleryButton = (MaterialRippleLayout) view.findViewById(R.id.gallery_button);
        MaterialRippleLayout mCameraButton = (MaterialRippleLayout) view.findViewById(R.id.camera_button);

        mGalleryButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                intent.setType("image/jpeg");

                imgFromGalleryActivityResultLauncher.launch(intent);
            }
        });

        mCameraButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Helper helper = new Helper(App.getInstance().getApplicationContext());

                if (helper.checkPermission(Manifest.permission.CAMERA)) {

                    try {

                        Uri selectedImage = FileProvider.getUriForFile(App.getInstance().getApplicationContext(), App.getInstance().getPackageName() + ".provider", new File(App.getInstance().getDirectory(), IMAGE_FILE));

                        Intent cameraIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                        cameraIntent.putExtra(android.provider.MediaStore.EXTRA_OUTPUT, selectedImage);
                        cameraIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        cameraIntent.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
                        imgFromCameraActivityResultLauncher.launch(cameraIntent);

                    } catch (Exception e) {

                        Log.e("Dimon3", e.toString());

                        Toast.makeText(getActivity(), "Error occured. Please try again later.", Toast.LENGTH_SHORT).show();
                    }

                } else {

                    requestCameraPermission();
                }
            }
        });

        mBottomSheetDialog = new BottomSheetDialog(getActivity());
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    private void choiceGiftDialog() {

        final GiftsSelectListAdapter giftsAdapter;

        giftsAdapter = new GiftsSelectListAdapter(getActivity(), App.getInstance().getGiftsList());

        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.dialog_gifts);
        dialog.setCancelable(true);

        LinearLayout mDlgGiftPreviewLayout = (LinearLayout) dialog.findViewById(R.id.gift_preview_layout);
        EditText mDlgGiftMessageEdit = (EditText) dialog.findViewById(R.id.message);
        ImageView mDlgPreviewImage = (ImageView) dialog.findViewById(R.id.image);

        final ProgressBar mProgressBar = (ProgressBar) dialog.findViewById(R.id.progress_bar);
        mProgressBar.setVisibility(View.GONE);

        TextView mDlgTitle = (TextView) dialog.findViewById(R.id.title_label);
        mDlgTitle.setText(R.string.dlg_choice_gift_title);

        TextView mDlgSubtitle = (TextView) dialog.findViewById(R.id.subtitle_label);
        mDlgSubtitle.setText(String.format(Locale.getDefault(), getString(R.string.account_balance_label), App.getInstance().getAccount().getBalance()));

        AppCompatButton mDlgBalanceButton = (AppCompatButton) dialog.findViewById(R.id.balance_button);
        mDlgBalanceButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent i = new Intent(getActivity(), BalanceActivity.class);
                startActivityForResult(i, 1945);

                dialog.dismiss();
            }
        });

        AppCompatButton mDlgCancelButton = (AppCompatButton) dialog.findViewById(R.id.cancel_button);
        mDlgCancelButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });

        AppCompatButton mDlgSendButton = (AppCompatButton) dialog.findViewById(R.id.send_button);
        mDlgSendButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                String messageText = mDlgGiftMessageEdit.getText().toString().trim();

                CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_GIFTS_SEND, null,
                        new Response.Listener<JSONObject>() {
                            @Override
                            public void onResponse(JSONObject response) {

                                try {

                                    if (!response.getBoolean("error")) {

                                        App.getInstance().getAccount().setBalance(App.getInstance().getAccount().getBalance() - App.getInstance().getGiftsList().get(giftPosition).getCost());
                                    }

                                } catch (JSONException e) {

                                    e.printStackTrace();

                                } finally {

                                    Toast.makeText(getActivity(), getText(R.string.msg_gift_sent), Toast.LENGTH_SHORT).show();
                                    profile.setGiftsCount(profile.getGiftsCount() + 1);

                                    updateGiftsCount();
                                }
                            }
                        }, new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {

                        Toast.makeText(getActivity(), getText(R.string.msg_gift_sent), Toast.LENGTH_SHORT).show();
                    }
                }) {

                    @Override
                    protected Map<String, String> getParams() {
                        Map<String, String> params = new HashMap<String, String>();
                        params.put("accountId", Long.toString(App.getInstance().getId()));
                        params.put("accessToken", App.getInstance().getAccessToken());
                        params.put("giftAnonymous", Integer.toString(0));
                        params.put("message", messageText);
                        params.put("giftId", Long.toString(App.getInstance().getGiftsList().get(giftPosition).getId()));
                        params.put("giftTo", Long.toString(profile.getId()));

                        return params;
                    }
                };

                App.getInstance().addToRequestQueue(jsonReq);

                dialog.dismiss();
            }
        });

        mDlgSendButton.setVisibility(View.GONE);
        mDlgGiftPreviewLayout.setVisibility(View.GONE);

        NestedScrollView mDlgNestedView = (NestedScrollView) dialog.findViewById(R.id.nested_view);
        final RecyclerView mDlgRecyclerView = (RecyclerView) dialog.findViewById(R.id.recycler_view);

        final LinearLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), Helper.getStickersGridSpanCount(getActivity()));
        mDlgRecyclerView.setLayoutManager(mLayoutManager);
        mDlgRecyclerView.setHasFixedSize(true);
        mDlgRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mDlgRecyclerView.setAdapter(giftsAdapter);

        mDlgRecyclerView.setNestedScrollingEnabled(true);

        giftsAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {

            @Override
            public void onChanged() {

                super.onChanged();

                if (App.getInstance().getGiftsList().size() != 0) {

                     mDlgRecyclerView.setVisibility(View.VISIBLE);
                     mProgressBar.setVisibility(View.GONE);
                }
            }
        });

        giftsAdapter.setOnItemClickListener(new GiftsSelectListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, BaseGift obj, int position) {

                if (App.getInstance().getAccount().getBalance() >= obj.getCost()) {

                    ImageLoader imageLoader = App.getInstance().getImageLoader();

                    imageLoader.get(obj.getImgUrl(), ImageLoader.getImageListener(mDlgPreviewImage, R.drawable.ic_gift, R.drawable.ic_gift));

                    giftPosition = position;

                    mDlgRecyclerView.setVisibility(View.GONE);
                    mDlgGiftPreviewLayout.setVisibility(View.VISIBLE);
                    mDlgSendButton.setVisibility(View.VISIBLE);

                    //dialog.dismiss();

                } else {

                    Toast.makeText(getActivity(), getString(R.string.error_credits), Toast.LENGTH_SHORT).show();
                }
            }
        });

        if (App.getInstance().getGiftsList().size() == 0) {

            mDlgRecyclerView.setVisibility(View.GONE);
            mProgressBar.setVisibility(View.VISIBLE);

            Api api = new Api(getActivity());
            api.getGifts(giftsAdapter);
        }

        dialog.show();

        doKeepDialog(dialog);
    }

    private void choiceFeelingDialog() {

        final FeelingsListAdapter feelingsAdapter;

        feelingsAdapter = new FeelingsListAdapter(getActivity(), App.getInstance().getFeelingsList());

        final Dialog dialog = new Dialog(getActivity());
        dialog.setContentView(R.layout.dialog_feelings);
        dialog.setCancelable(true);

        final ProgressBar mProgressBar = (ProgressBar) dialog.findViewById(R.id.progress_bar);
        mProgressBar.setVisibility(View.GONE);

        TextView mDlgTitle = (TextView) dialog.findViewById(R.id.title_label);
        mDlgTitle.setText(R.string.dlg_choice_feeling_title);

        AppCompatButton mDlgCancelButton = (AppCompatButton) dialog.findViewById(R.id.cancel_button);
        mDlgCancelButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                dialog.dismiss();
            }
        });

        NestedScrollView mDlgNestedView = (NestedScrollView) dialog.findViewById(R.id.nested_view);
        final RecyclerView mDlgRecyclerView = (RecyclerView) dialog.findViewById(R.id.recycler_view);

        final LinearLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), Helper.getStickersGridSpanCount(getActivity()));
        mDlgRecyclerView.setLayoutManager(mLayoutManager);
        mDlgRecyclerView.setHasFixedSize(true);
        mDlgRecyclerView.setItemAnimator(new DefaultItemAnimator());

        mDlgRecyclerView.setAdapter(feelingsAdapter);

        mDlgRecyclerView.setNestedScrollingEnabled(true);

        feelingsAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {

            @Override
            public void onChanged() {

                super.onChanged();

                if (App.getInstance().getFeelingsList().size() != 0) {

                    mDlgRecyclerView.setVisibility(View.VISIBLE);
                    mProgressBar.setVisibility(View.GONE);
                }
            }
        });

        feelingsAdapter.setOnItemClickListener(new FeelingsListAdapter.OnItemClickListener() {

            @Override
            public void onItemClick(View view, Feeling obj, int position) {

                Api api = new Api(getActivity());
                api.setFelling(position);

                profile.setMood(position);

                updateFeeling();

                dialog.dismiss();
            }
        });

        if (App.getInstance().getFeelingsList().size() == 0) {

            mDlgRecyclerView.setVisibility(View.GONE);
            mProgressBar.setVisibility(View.VISIBLE);

            Api api = new Api(getActivity());
            api.getFeelings(feelingsAdapter);
        }

        dialog.show();

        doKeepDialog(dialog);
    }

    private void showAuthorizationBottomSheet(int state) {

        mBehavior.setState(state);

        final View view = getLayoutInflater().inflate(R.layout.bottom_sheet_authorization, null);

        // Close

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        //

        LinearLayout mMainPanel = (LinearLayout) view.findViewById(R.id.main_panel);
        Button mGoogleLoginButton = (Button) view.findViewById(R.id.action_google_login);
        Button mSignupButton = (Button) view.findViewById(R.id.action_signup);
        TextView mLoginButton = (TextView) view.findViewById(R.id.button_login);
        TextView mTermsButton = (TextView) view.findViewById(R.id.button_terms);

        mGoogleLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                googleSigninActivityResultLauncher.launch(signInIntent);
            }
        });

        mTermsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getActivity(), WebViewActivity.class);
                i.putExtra("url", METHOD_APP_TERMS);
                i.putExtra("title", getText(R.string.settings_terms));
                startActivity(i);
            }
        });

        mLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(getActivity(), LoginActivity.class);
                startActivity(i);
            }
        });

        mSignupButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();
                //showAuthorizationBottomSheet(BottomSheetBehavior.STATE_HIDDEN);

                Intent i = new Intent(getActivity(), RegisterActivity.class);
                startActivity(i);
            }
        });

        mBottomSheetDialog = new BottomSheetDialog(getActivity());
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    // Prevent dialog dismiss when orientation changes
    private static void doKeepDialog(Dialog dialog){

        WindowManager.LayoutParams lp = new WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);
    }

    private void requestStoragePermission() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            storagePermissionLauncher.launch(new String[]{Manifest.permission.READ_MEDIA_IMAGES});

        } else {

            storagePermissionLauncher.launch(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE});
        }
    }

    private void requestCameraPermission() {

        cameraPermissionLauncher.launch(Manifest.permission.CAMERA);
    }

    private void requestAgoraPermission() {

        agoraPermissionLauncher.launch(new String[]{Manifest.permission.CAMERA, Manifest.permission.RECORD_AUDIO});
    }

    @Override
    public void onResume() {

        super.onResume();

        if (!isMainScreen) {

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

                getActivity().registerReceiver(mAuthBottomSheetReceiver, new IntentFilter(TAG_SHOW_AUTH_BOTTOM_SHEET), RECEIVER_NOT_EXPORTED);

            } else {

                getActivity().registerReceiver(mAuthBottomSheetReceiver, new IntentFilter(TAG_SHOW_AUTH_BOTTOM_SHEET));
            }
        }
    }

    @Override
    public void onPause() {

        super.onPause();

        if (!isMainScreen) {

            getActivity().unregisterReceiver(mAuthBottomSheetReceiver);
        }
    }

    private BroadcastReceiver mAuthBottomSheetReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            // Extract data included in the Intent
            // String message = intent.getStringExtra("message");

            showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);
        }
    };
}