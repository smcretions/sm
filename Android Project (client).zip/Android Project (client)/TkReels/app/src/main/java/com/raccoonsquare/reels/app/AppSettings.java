package com.raccoonsquare.reels.app;

import android.app.Application;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.util.Log;

import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.constants.Constants;

import org.json.JSONObject;

public class AppSettings extends Application implements Constants {

	public static final String TAG = AppSettings.class.getSimpleName();

    private Boolean allow_google_auth_feature = false;
    private Boolean allow_facebook_auth_feature = false;
    private Boolean allow_apple_auth_feature = false;
    private Boolean allow_rewarded_ads_feature = true;
    private Boolean allow_market_feature = true;
    private Boolean allow_upgrades_feature = true;
    private Boolean allow_referrals_feature = true;
    private Boolean allow_otp_feature = true;
    private Boolean allow_google_pay_test_button = false;
    private int referral_bonus = 10; // Virtual currency
    private int otp_bonus = 100; // Virtual currency
    private int rewarded_ads_bonus = 10; // Virtual currency
    private int short_capture_time = 15000; // MILLISECONDS
    private int medium_capture_time = 30000; // MILLISECONDS
    private int normal_capture_time = 60000; // MILLISECONDS
    private int long_capture_time = 90000; // MILLISECONDS
    private int videoBitrate = 6000000;

    private int ghost_mode_cost = 120;
    private int disable_ads_cost = 200;
    private int video_blogger_cost = 170;
    private int music_fan_cost = 170;

	@Override
	public void onCreate() {

		super.onCreate();
	}

    public void read_from_json(JSONObject jsonData) {

        try {

            if (jsonData.has("short_capture_time")) {

                this.setShortCaptureTime(jsonData.getInt("short_capture_time"));
            }

            if (jsonData.has("medium_capture_time")) {

                this.setMediumCaptureTime(jsonData.getInt("medium_capture_time"));
            }

            if (jsonData.has("normal_capture_time")) {

                this.setNormalCaptureTime(jsonData.getInt("normal_capture_time"));
            }

            if (jsonData.has("long_capture_time")) {

                this.setLongCaptureTime(jsonData.getInt("long_capture_time"));
            }

            if (jsonData.has("androidVideoBitrate")) {

                this.setVideoBitrate(jsonData.getInt("androidVideoBitrate"));
            }

            if (jsonData.has("allow_market_feature")) {

                this.setMarketFeature(jsonData.getBoolean("allow_market_feature"));
            }

            if (jsonData.has("allow_upgrades_feature")) {

                this.setUpgradesFeature(jsonData.getBoolean("allow_upgrades_feature"));
            }

            if (jsonData.has("allow_referrals_feature")) {

                this.setReferralsFeature(jsonData.getBoolean("allow_referrals_feature"));
            }

            if (jsonData.has("allow_otp_feature")) {

                this.setOtpFeature(jsonData.getBoolean("allow_otp_feature"));
            }

            if (jsonData.has("allow_google_pay_test_button")) {

                this.setGooglePayTestButton(jsonData.getBoolean("allow_google_pay_test_button"));
            }

            if (jsonData.has("allow_google_auth_feature")) {

                this.setGoogleAuthFeature(jsonData.getBoolean("allow_google_auth_feature"));
            }

            if (jsonData.has("allow_facebook_auth_feature")) {

                this.setFacebookAuthFeature(jsonData.getBoolean("allow_facebook_auth_feature"));
            }

            if (jsonData.has("allow_apple_auth_feature")) {

                this.setAppleAuthFeature(jsonData.getBoolean("allow_apple_auth_feature"));
            }

            if (jsonData.has("otp_bonus")) {

                this.setOtpBonus(jsonData.getInt("otp_bonus"));
            }

            if (jsonData.has("referral_bonus")) {

                this.setReferralBonus(jsonData.getInt("referral_bonus"));
            }

            if (jsonData.has("allow_rewarded_ads_feature")) {

                this.setRewardedAdsFeature(jsonData.getBoolean("allow_rewarded_ads_feature"));
            }

            if (jsonData.has("rewarded_ads_bonus")) {

                this.setRewardedAdsBonus(jsonData.getInt("rewarded_ads_bonus"));
            }

            if (jsonData.has("ghost_mode_cost")) {

                this.setGhostModeCost(jsonData.getInt("ghost_mode_cost"));
            }

            if (jsonData.has("disable_ads_cost")) {

                this.setDisableAdsCost(jsonData.getInt("disable_ads_cost"));
            }

            if (jsonData.has("video_blogger_cost")) {

                this.setVideoBloggerCost(jsonData.getInt("video_blogger_cost"));
            }

            if (jsonData.has("music_fan_cost")) {

                this.setMusicFanCost(jsonData.getInt("music_fan_cost"));
            }

        } catch (Throwable t) {

            Log.e("AppSettings", "Could not parse malformed JSON: \"" + jsonData.toString() + "\"");

        } finally {

            Log.e("AppSettings", "finally");
        }
    }

    //

    public void setShortCaptureTime(int short_capture_time) {

        this.short_capture_time = short_capture_time;
    }

    public int getShortCaptureTime() {

        return this.short_capture_time;
    }

    //

    public void setMediumCaptureTime(int medium_capture_time) {

        this.medium_capture_time = medium_capture_time;
    }

    public int getMediumCaptureTime() {

        return this.medium_capture_time;
    }

    //

    public void setNormalCaptureTime(int normal_capture_time) {

        this.normal_capture_time = normal_capture_time;
    }

    public int getNormalCaptureTime() {

        return this.normal_capture_time;
    }

    //

    public void setLongCaptureTime(int long_capture_time) {

        this.long_capture_time = long_capture_time;
    }

    public int getLongCaptureTime() {

        return this.long_capture_time;
    }

    //

    public void setVideoBitrate(int videoBitrate) {

        this.videoBitrate = videoBitrate;
    }

    public int getVideoBitrate() {

        return this.videoBitrate;
    }

    //

    public void setMarketFeature(Boolean allow_market_feature) {

        this.allow_market_feature = allow_market_feature;
    }

    public Boolean getMarketFeature() {

        return this.allow_market_feature;
    }

    //

    public void setUpgradesFeature(Boolean allow_upgrades_feature) {

        this.allow_upgrades_feature = allow_upgrades_feature;
    }

    public Boolean getUpgradesFeature() {

        return this.allow_upgrades_feature;
    }

    //

    public void setOtpFeature(Boolean allow_otp_feature) {

        this.allow_otp_feature = allow_otp_feature;
    }

    public Boolean getOtpFeature() {

        return this.allow_otp_feature;
    }

    //

    public void setReferralsFeature(Boolean allow_referrals_feature) {

        this.allow_referrals_feature = allow_referrals_feature;
    }

    public Boolean getReferralsFeature() {

        return this.allow_referrals_feature;
    }

    //

    public void setGooglePayTestButton(Boolean allow_google_pay_test_button) {

        this.allow_google_pay_test_button = allow_google_pay_test_button;
    }

    public Boolean getGooglePayTestButton() {

        return this.allow_google_pay_test_button;
    }

    //

    public void setGoogleAuthFeature(Boolean allow_google_auth_feature) {

        this.allow_google_auth_feature = allow_google_auth_feature;
    }

    public Boolean getGoogleAuthFeature() {

        return this.allow_google_auth_feature;
    }

    //

    public void setFacebookAuthFeature(Boolean allow_facebook_auth_feature) {

        this.allow_facebook_auth_feature = allow_facebook_auth_feature;
    }

    public Boolean getFacebookAuthFeature() {

        return this.allow_facebook_auth_feature;
    }

    //

    public void setAppleAuthFeature(Boolean allow_apple_auth_feature) {

        this.allow_apple_auth_feature = allow_apple_auth_feature;
    }

    public Boolean getAppleAuthFeature() {

        return this.allow_apple_auth_feature;
    }

    //

    public void setOtpBonus(int otp_bonus) {

        this.otp_bonus = otp_bonus;
    }

    public int getOtpBonus() {

        return this.otp_bonus;
    }

    //

    public void setReferralBonus(int referral_bonus) {

        this.referral_bonus = referral_bonus;
    }

    public int getReferralBonus() {

        return this.referral_bonus;
    }

    //

    public void setRewardedAdsBonus(int rewarded_ads_bonus) {

        this.rewarded_ads_bonus = rewarded_ads_bonus;
    }

    public int getRewardedAdsBonus() {

        return this.rewarded_ads_bonus;
    }

    //

    public void setGhostModeCost(int ghost_mode_cost) {

        this.ghost_mode_cost = ghost_mode_cost;
    }

    public int getGhostModeCost() {

        return this.ghost_mode_cost;
    }

    //

    public void setDisableAdsCost(int disable_ads_cost) {

        this.disable_ads_cost = disable_ads_cost;
    }

    public int getDisableAdsCost() {

        return this.disable_ads_cost;
    }

    //

    public void setVideoBloggerCost(int video_blogger_cost) {

        this.video_blogger_cost = video_blogger_cost;
    }

    public int getVideoBloggerCost() {

        return this.video_blogger_cost;
    }

    //

    public void setMusicFanCost(int music_fan_cost) {

        this.music_fan_cost = music_fan_cost;
    }

    public int getMusicFanCost() {

        return this.music_fan_cost;
    }

    //

    public void setRewardedAdsFeature(Boolean allow_rewarded_ads_feature) {

        this.allow_rewarded_ads_feature = allow_rewarded_ads_feature;
    }

    public Boolean getRewardedAdsFeature() {

        return this.allow_rewarded_ads_feature;
    }
}