package com.raccoonsquare.reels;

import static android.content.Context.RECEIVER_NOT_EXPORTED;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.Dialog;
import android.app.DownloadManager;
import android.app.ProgressDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.widget.NestedScrollView;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;
import androidx.viewpager2.widget.ViewPager2;

import com.aghajari.emojiview.view.AXEmojiEditText;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.balysv.materialripple.MaterialRippleLayout;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomsheet.BottomSheetBehavior;
import com.google.android.material.bottomsheet.BottomSheetDialog;
import com.raccoonsquare.reels.adapter.CommentsListAdapter;
import com.raccoonsquare.reels.adapter.VideoSliderAdapter;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.common.FragmentBase;
import com.raccoonsquare.reels.constants.Constants;
import com.raccoonsquare.reels.model.Comment;
import com.raccoonsquare.reels.model.Item;
import com.raccoonsquare.reels.util.Api;
import com.raccoonsquare.reels.util.CustomRequest;
import com.raccoonsquare.reels.util.Helper;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class HomeFragment extends FragmentBase implements Constants, SwipeRefreshLayout.OnRefreshListener{

    private static final String STATE_LIST = "State Adapter Data";

    private ProgressDialog pDialog;

    private SwipeRefreshLayout mItemsContainer;

    private ViewPager2 mViewPager;

    private TextView mTabFollowing, mTabPopular, mTabRelated, mMessage;
    private ProgressBar mProgressBar;
    private ImageButton mCloseButton, mSearchButton;

    private RelativeLayout mTabLayout;

    //
    private BottomSheetBehavior mBehavior;
    private BottomSheetDialog mBottomSheetDialog;
    private View mBottomSheet;

    long replyToUserId = 0; // For comments
    //

    GoogleSignInClient mGoogleSignInClient;
    ActivityResultLauncher<Intent> googleSigninActivityResultLauncher;

    //
    private int itemId = 0, arrayLength = 0;

    private Boolean loadingMore = false, viewMore = true;

    private ArrayList<Item> itemsList;

    private VideoSliderAdapter mPagerStateAdapter;

    private int sectionId = 0;
    private int position = 0;
    private int rating = 0;

    private Boolean isMainScreen = true;

    public HomeFragment() {

        // Required empty public constructor
    }

    public HomeFragment newInstance(Boolean isMainScreen) {

        HomeFragment myFragment = new HomeFragment();

        Bundle args = new Bundle();
        args.putBoolean("isMainScreen", isMainScreen);
        myFragment.setArguments(args);

        return myFragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        Log.e("tester", "HomeFragment onCreate");

        //

        initpDialog();

        //

        Intent i = getActivity().getIntent();
        position = i.getIntExtra("position", 0);
        sectionId = i.getIntExtra("sectionId", 0);

        if (getArguments() != null) {

            isMainScreen = getArguments().getBoolean("isMainScreen", true);
        }

        if (savedInstanceState != null) {

            itemId = savedInstanceState.getInt("itemId");

        } else {

            itemId = 0;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {

        View rootView = inflater.inflate(R.layout.fragment_home, container, false);

        mItemsContainer = (SwipeRefreshLayout) rootView.findViewById(R.id.container_items);
        mItemsContainer.setProgressViewOffset(false, 200, 250);
        mItemsContainer.setOnRefreshListener(this);

        //

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();

        mGoogleSignInClient = GoogleSignIn.getClient(getActivity(), gso);

        googleSigninActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    // There are no request codes
                    Intent data = result.getData();

                    Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);

                    try {

                        GoogleSignInAccount account = task.getResult(ApiException.class);

                        // Signed in successfully, show authenticated UI.

                        showpDialog();

                        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_ACCOUNT_OAUTH, null,
                                new Response.Listener<JSONObject>() {
                                    @Override
                                    public void onResponse(JSONObject response) {

                                        if (App.getInstance().authorize(response)) {

                                            if (App.getInstance().getAccount().getState() == ACCOUNT_STATE_ENABLED) {

                                                Intent intent = new Intent(getActivity(), MainActivity.class);
                                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                startActivity(intent);

                                            } else {

                                                if (App.getInstance().getAccount().getState() == ACCOUNT_STATE_BLOCKED) {

                                                    App.getInstance().logout();
                                                    Toast.makeText(getActivity(), getText(R.string.msg_account_blocked), Toast.LENGTH_SHORT).show();

                                                } else {

                                                    App.getInstance().updateGeoLocation();

                                                    Intent intent = new Intent(getActivity(), MainActivity.class);
                                                    intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                                    startActivity(intent);
                                                }
                                            }

                                        } else {

                                            Toast.makeText(getActivity(), getString(R.string.error_data_loading), Toast.LENGTH_SHORT).show();
                                        }

                                        hidepDialog();
                                    }
                                }, new Response.ErrorListener() {
                            @Override
                            public void onErrorResponse(VolleyError error) {

                                Log.e("Google", "signInWithCredential:failure");

                                Toast.makeText(getActivity(), getText(R.string.error_data_loading), Toast.LENGTH_LONG).show();

                                hidepDialog();
                            }
                        }) {

                            @Override
                            protected Map<String, String> getParams() {
                                Map<String, String> params = new HashMap<String, String>();

                                params.put("client_id", CLIENT_ID);

                                params.put("account_id", Long.toString(App.getInstance().getId()));
                                params.put("access_token", App.getInstance().getAccessToken());

                                params.put("app_type", Integer.toString(APP_TYPE_ANDROID));
                                params.put("fcm_regId", App.getInstance().getFcmToken());

                                params.put("action", "");

                                params.put("uid", account.getId());
                                params.put("oauth_type", Integer.toString(OAUTH_TYPE_GOOGLE));
                                params.put("oauth_name", account.getDisplayName());
                                params.put("oauth_email", account.getEmail());
                                params.put("oauth_photo", account.getPhotoUrl().toString());

                                return params;
                            }
                        };

                        App.getInstance().addToRequestQueue(jsonReq);

                    } catch (ApiException e) {

                        // The ApiException status code indicates the detailed failure reason.
                        // Please refer to the GoogleSignInStatusCodes class reference for more information.
                        Log.e("Google", "Google sign in failed", e);
                    }
                }
            }
        });

        //

        // Prepare bottom sheet

        mBottomSheet = rootView.findViewById(R.id.bottom_sheet);
        mBehavior = BottomSheetBehavior.from(mBottomSheet);

        //

        mViewPager = rootView.findViewById(R.id.view_pager);
        //mViewPager.setOffscreenPageLimit(3);

//        mViewPager.setPageTransformer(true, new ViewPager.PageTransformer() {
//
//            @Override
//            public void transformPage(View page, float position) {
//
//                float translationX;
//                float scale;
//                float alpha;
//
//                if (position >= 1 || position <= -1) {
//                    // Fix for https://code.google.com/p/android/issues/detail?id=58918
//                    translationX = 0;
//                    scale = 1;
//                    alpha = 1;
//                } else if (position >= 0) {
//                    translationX = -page.getWidth() * position;
//                    scale = -0.2f * position + 1;
//                    alpha = Math.max(1 - position, 0);
//                } else {
//                    translationX = 0.5f * page.getWidth() * position;
//                    scale = 1.0f;
//                    alpha = Math.max(0.1f * position + 1, 0);
//                }
//
////                ViewHelper.setTranslationX(page, translationX);
////                ViewHelper.setScaleX(page, scale);
////                ViewHelper.setScaleY(page, scale);
////                ViewHelper.setAlpha(page, alpha);
//            }
//        });

        //

        //

        mTabLayout = rootView.findViewById(R.id.tab_layout);

        mTabFollowing = rootView.findViewById(R.id.tab_following);
        mTabFollowing.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (App.getInstance().getId() == 0) {

                    showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);

                } else {

                    mTabFollowing.setBackground(getActivity().getDrawable(R.drawable.top_menu_item_active));
                    mTabRelated.setBackground(getActivity().getDrawable(R.drawable.top_menu_item));
                    mTabPopular.setBackground(getActivity().getDrawable(R.drawable.top_menu_item));

                    mTabFollowing.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_active_text_size));
                    mTabFollowing.setTypeface(mTabFollowing.getTypeface(), Typeface.BOLD);
                    mTabRelated.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_text_size));
                    mTabRelated.setTypeface(mTabRelated.getTypeface(), Typeface.NORMAL);
                    mTabPopular.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_text_size));
                    mTabPopular.setTypeface(mTabPopular.getTypeface(), Typeface.NORMAL);

                    itemId = 0;
                    rating = 0;
                    loadingMore = false;
                    sectionId = 2;
                    getItems();
                }
            }
        });

        mTabPopular = rootView.findViewById(R.id.tab_ads);
        mTabPopular.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mTabFollowing.setBackground(getActivity().getDrawable(R.drawable.top_menu_item));
                mTabRelated.setBackground(getActivity().getDrawable(R.drawable.top_menu_item));
                mTabPopular.setBackground(getActivity().getDrawable(R.drawable.top_menu_item_active));

                mTabFollowing.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_text_size));
                mTabFollowing.setTypeface(mTabFollowing.getTypeface(), Typeface.NORMAL);
                mTabRelated.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_text_size));
                mTabRelated.setTypeface(mTabRelated.getTypeface(), Typeface.NORMAL);
                mTabPopular.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_active_text_size));
                mTabPopular.setTypeface(mTabPopular.getTypeface(), Typeface.BOLD);

                itemId = 0;
                rating = 0;
                loadingMore = false;
                sectionId = 1;
                getItems();
            }
        });

        mTabRelated = rootView.findViewById(R.id.tab_related);
        mTabRelated.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mTabFollowing.setBackground(getActivity().getDrawable(R.drawable.top_menu_item));
                mTabPopular.setBackground(getActivity().getDrawable(R.drawable.top_menu_item));
                mTabRelated.setBackground(getActivity().getDrawable(R.drawable.top_menu_item_active));

                mTabFollowing.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_text_size));
                mTabFollowing.setTypeface(mTabFollowing.getTypeface(), Typeface.NORMAL);
                mTabRelated.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_active_text_size));
                mTabRelated.setTypeface(mTabRelated.getTypeface(), Typeface.BOLD);
                mTabPopular.setTextSize(TypedValue.COMPLEX_UNIT_PX, getResources().getDimension(R.dimen.top_menu_text_size));
                mTabPopular.setTypeface(mTabPopular.getTypeface(), Typeface.NORMAL);

                itemId = 0;
                rating = 0;
                loadingMore = false;
                sectionId = 0;
                getItems();
            }
        });

        mMessage = rootView.findViewById(R.id.message_label);
        hideMessage();

        mProgressBar = rootView.findViewById(R.id.progress_bar);
        mProgressBar.setVisibility(View.GONE);

        mSearchButton = rootView.findViewById(R.id.search_button);
        mSearchButton.setVisibility(View.GONE);

        mSearchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent i = new Intent(getActivity(), FinderActivity.class);
                i.putExtra("tab_position", 0);
                startActivity(i);
            }
        });

        mCloseButton = rootView.findViewById(R.id.close_button);
        mCloseButton.setVisibility(View.GONE);

        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                getActivity().finish();
            }
        });

        //

        init();

        return rootView;
    }

    public void init() {

        if (!isMainScreen) {

            mSearchButton.setVisibility(View.GONE);
            mTabLayout.setVisibility(View.GONE);
            mCloseButton.setVisibility(View.VISIBLE);
            mItemsContainer.setEnabled(false);
        }

        itemsList = new ArrayList<Item>();

        mPagerStateAdapter = new VideoSliderAdapter(getChildFragmentManager(), mViewPager, getLifecycle());

        mViewPager.setAdapter(mPagerStateAdapter);
        //mViewPager.setOffscreenPageLimit(3);
        //mViewPager.setSaveFromParentEnabled(false);

        mViewPager.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {

                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
            }

            @Override
            public void onPageSelected(int position) {

                super.onPageSelected(position);

                if (position == 0) {

                    if (isMainScreen) {

                        mItemsContainer.setEnabled(true);
                    }

                } else {

                    mItemsContainer.setEnabled(false);
                }

                if (position == 0 && (mPagerStateAdapter != null && mPagerStateAdapter.getCount() > 0)) {

                    ItemFragment fragment = (ItemFragment) mPagerStateAdapter.getItem(mViewPager.getCurrentItem());
                    fragment.updateView();

                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
                        @Override
                        public void run() {

                            fragment.setPlayer(true);
                        }

                    }, 200);
                }

                Log.e("Dimon3", "callVideoApi() onPageSelected " + Integer.toString(position));

                if (!loadingMore && viewMore && position == itemsList.size() - 3) {

                    loadingMore = true;

                    getItems();
                }
            }

            @Override
            public void onPageScrollStateChanged(int state) {
                super.onPageScrollStateChanged(state);
            }
        });

//        mViewPager.setOnPageChangeListener(new ViewPager.OnPageChangeListener() {
//
//            @Override
//            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
//
//            }
//
//            @Override
//            public void onPageSelected(int position) {
//
//                if (position == 0) {
//
//                    if (isMainScreen) {
//
//                        mItemsContainer.setEnabled(true);
//                    }
//
//                } else {
//
//                    mItemsContainer.setEnabled(false);
//                }
//
//                if (position == 0 && (mPagerStateAdapter != null && mPagerStateAdapter.getCount() > 0)) {
//
//                    ItemFragment fragment = (ItemFragment) mPagerStateAdapter.getItem(mViewPager.getCurrentItem());
//                    fragment.updateView();
//
//                    new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {
//                        @Override
//                        public void run() {
//
//                            fragment.setPlayer(true);
//                        }
//
//                    }, 200);
//                }
//
//                Log.e("Dimon3", "callVideoApi() onPageSelected " + Integer.toString(position));
//
//                if (!loadingMore && viewMore && position == itemsList.size() - 3) {
//
//                    loadingMore = true;
//
//                    getItems();
//                }
//            }
//
//            @Override
//            public void onPageScrollStateChanged(int state) {
//
//
//            }
//        });

        if (isMainScreen) {

            getItems();

        } else {

            itemsList = (ArrayList<Item>)App.getInstance().getHomeItemsList().clone();

            for (int i = 0; i < itemsList.size(); i++) {

                mPagerStateAdapter.addFragment(new ItemFragment(itemsList.get(i), mViewPager, isMainScreen));
            }

            loadingComplete();
        }
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {

        super.onSaveInstanceState(outState);

        outState.putInt("itemId", itemId);
    }

    @Override
    public void onRefresh() {

        if (App.getInstance().isConnected()) {

            itemId = 0;
            rating = 0;
            getItems();

        } else {

            mItemsContainer.setRefreshing(false);
        }
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == ITEM_EDIT && resultCode == getActivity().RESULT_OK) {

            int position = data.getIntExtra("position", 0);

            if (data.getExtras() != null) {

                Item item = (Item) data.getExtras().getParcelable("item");

                itemsList.set(position, item);
            }

            mPagerStateAdapter.notifyDataSetChanged();
        }
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {

        super.onCreateOptionsMenu(menu, inflater);
    }

    public void getItems() {

        mMessage.setVisibility(View.GONE);

        if (loadingMore) {

            mItemsContainer.setRefreshing(true);

        } else {

            mProgressBar.setVisibility(View.VISIBLE);
        }


        CustomRequest jsonReq = new CustomRequest(Request.Method.POST, METHOD_HOME_GET, null,
                new Response.Listener<JSONObject>() {
                    @Override
                    public void onResponse(JSONObject response) {

                        if (!isAdded() || getActivity() == null) {

                            Log.e("ERROR", "HomeFragment Not Added to Activity");

                            return;
                        }

                        if (!loadingMore) {

                            itemsList.clear();

                            mPagerStateAdapter = new VideoSliderAdapter(getChildFragmentManager(), mViewPager, getLifecycle());
                            mViewPager.setAdapter(mPagerStateAdapter);
                        }

                        try {

                            arrayLength = 0;

                            if (!response.getBoolean("error")) {

                                if (response.has("itemId")) {

                                    itemId = response.getInt("itemId");
                                }

                                if (response.has("rating")) {

                                    rating = response.getInt("rating");
                                }

                                if (response.has("items")) {

                                    JSONArray itemsArray = response.getJSONArray("items");

                                    arrayLength = itemsArray.length();

                                    if (arrayLength > 0) {

                                        for (int i = 0; i < itemsArray.length(); i++) {

                                            JSONObject itemObj = (JSONObject) itemsArray.get(i);

                                            Item item = new Item(itemObj);

                                            if (!App.getInstance().getDatabaseManager().isExist(item.getId())) {

                                                itemsList.add(item);
                                                mPagerStateAdapter.addFragment(new ItemFragment(item, mViewPager, isMainScreen));
                                            }
                                        }
                                    }
                                }
                            }

                        } catch (JSONException e) {

                            e.printStackTrace();

                        } finally {

                            Log.e("METHOD_HOME_GET RESPONSE", response.toString());

                            loadingComplete();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {

                if (!isAdded() || getActivity() == null) {

                    Log.e("METHOD_HOME_GET ERROR", "HomeFragment Not Added to Activity");

                    return;
                }

                loadingComplete();
            }
        }) {

            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<String, String>();
                params.put("account_id", Long.toString(App.getInstance().getId()));
                params.put("access_token", App.getInstance().getAccessToken());

                params.put("rating", Integer.toString(rating));

                params.put("item_id", Integer.toString(itemId));
                params.put("section_id", Integer.toString(sectionId));
                params.put("language", "en");

                return params;
            }
        };

        App.getInstance().addToRequestQueue(jsonReq);
    }

    public void loadingComplete() {

        mProgressBar.setVisibility(View.GONE);

        if (arrayLength == LIST_ITEMS) {

            viewMore = true;

        } else {

            viewMore = false;
        }

        if (itemsList.size() == 0) {

            mPagerStateAdapter = new VideoSliderAdapter(getChildFragmentManager(), mViewPager, getLifecycle());
            mViewPager.setAdapter(mPagerStateAdapter);
        }

        mPagerStateAdapter.notifyDataSetChanged();

        if (mPagerStateAdapter.getCount() == 0) {

            if (HomeFragment.this.isVisible()) {

                showMessage(getText(R.string.label_empty_list).toString());
            }

        } else {

            hideMessage();

            if (!loadingMore) {

                if (isMainScreen) {

                    mViewPager.setCurrentItem(0, false);

                } else {

                    mViewPager.setCurrentItem(position, false);
                }
            }
        }

        loadingMore = false;
        mItemsContainer.setRefreshing(false);
    }

    public void showMessage(String message) {

        mMessage.setText(message);
        mMessage.setVisibility(View.VISIBLE);

        //mSplash.setVisibility(View.VISIBLE);
    }

    public void hideMessage() {

        mMessage.setVisibility(View.GONE);
        //mSplash.setVisibility(View.GONE);
    }

    @Override
    public void setMenuVisibility(final boolean visible) {
        super.setMenuVisibility(visible);
        //is_visible_to_user = visible;

        if (visible && mPagerStateAdapter != null && mPagerStateAdapter.getCount() > 0) {

            new Handler(Looper.getMainLooper()).postDelayed(new Runnable() {

                @Override
                public void run() {

                    ItemFragment fragment = (ItemFragment) mPagerStateAdapter.getItem(mViewPager.getCurrentItem());
                    fragment.mainMenuVisibility(visible);
                }

            },200);
        }
    }

    @Override
    public void onAttach(Activity activity) {
        super.onAttach(activity);
    }

    @Override
    public void onDetach() {
        super.onDetach();
    }

    private void showAuthorizationBottomSheet(int state) {

        mBehavior.setState(state);

        final View view = getLayoutInflater().inflate(R.layout.bottom_sheet_authorization, null);

        // Close

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        //

        LinearLayout mMainPanel = (LinearLayout) view.findViewById(R.id.main_panel);
        Button mGoogleLoginButton = (Button) view.findViewById(R.id.action_google_login);
        Button mSignupButton = (Button) view.findViewById(R.id.action_signup);
        TextView mLoginButton = (TextView) view.findViewById(R.id.button_login);
        TextView mTermsButton = (TextView) view.findViewById(R.id.button_terms);

        mGoogleLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {

                Intent signInIntent = mGoogleSignInClient.getSignInIntent();
                googleSigninActivityResultLauncher.launch(signInIntent);
            }
        });

        mTermsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent i = new Intent(getActivity(), WebViewActivity.class);
                i.putExtra("url", METHOD_APP_TERMS);
                i.putExtra("title", getText(R.string.settings_terms));
                startActivity(i);
            }
        });

        mLoginButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(getActivity(), LoginActivity.class);
                startActivity(i);
            }
        });

        mSignupButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();
                //showAuthorizationBottomSheet(BottomSheetBehavior.STATE_HIDDEN);

                Intent i = new Intent(getActivity(), RegisterActivity.class);
                startActivity(i);
            }
        });

        mBottomSheetDialog = new BottomSheetDialog(getActivity());
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    public void showItemActionBottomSheet(int state) {

        mBehavior.setState(state);

        int currentPosition = mViewPager.getCurrentItem();
        Item p = itemsList.get(currentPosition);

        final View view = getLayoutInflater().inflate(R.layout.item_action_sheet_list, null);

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        MaterialRippleLayout mReportButton = view.findViewById(R.id.report_button);
        MaterialRippleLayout mLoginButton = view.findViewById(R.id.login_button);
        MaterialRippleLayout mSignupButton = view.findViewById(R.id.signup_button);
        MaterialRippleLayout mEditButton = view.findViewById(R.id.edit_button);
        MaterialRippleLayout mDeleteButton = view.findViewById(R.id.delete_button);
        MaterialRippleLayout mShareButton = view.findViewById(R.id.share_button);
        MaterialRippleLayout mDownloadButton = view.findViewById(R.id.download_button);
        MaterialRippleLayout mRepostButton = view.findViewById(R.id.repost_button);
        MaterialRippleLayout mPinButton = view.findViewById(R.id.pin_button);
        MaterialRippleLayout mCopyUrlButton = view.findViewById(R.id.copy_url_button);
        MaterialRippleLayout mOpenUrlButton = view.findViewById(R.id.open_url_button);
        MaterialRippleLayout mNotInterestedButton = view.findViewById(R.id.not_interested_button);

        mLoginButton.setVisibility(View.GONE);
        mSignupButton.setVisibility(View.GONE);
        mRepostButton.setVisibility(View.GONE);
        mCopyUrlButton.setVisibility(View.GONE);
        mOpenUrlButton.setVisibility(View.GONE);
        mPinButton.setVisibility(View.GONE);
        mReportButton.setVisibility(View.GONE);
        mShareButton.setVisibility(View.GONE);
        mNotInterestedButton.setVisibility(View.GONE);
        mDownloadButton.setVisibility(View.GONE);
        mEditButton.setVisibility(View.GONE);
        mDeleteButton.setVisibility(View.GONE);

        if (p.getFromUserId() == App.getInstance().getAccount().getId()) {

            mEditButton.setVisibility(View.VISIBLE);
            mDeleteButton.setVisibility(View.VISIBLE);

        } else {

            mReportButton.setVisibility(View.VISIBLE);
        }

        mEditButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(getActivity(), NewItemActivity.class);
                i.putExtra("item", p);
                i.putExtra("position", currentPosition);
                startActivityForResult(i, ITEM_EDIT);
            }
        });

        mDeleteButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                AlertDialog.Builder alertDialog = new AlertDialog.Builder(getActivity());
                alertDialog.setTitle(getText(R.string.label_delete));

                alertDialog.setMessage(getText(R.string.label_delete_video_item));
                alertDialog.setCancelable(true);

                alertDialog.setNegativeButton(getText(R.string.action_no), new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.cancel();
                    }
                });

                alertDialog.setPositiveButton(getText(R.string.action_yes), new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        Api api = new Api(getContext());
                        api.postDelete(p.getId(), 0);

                        Toast.makeText(getActivity(), getActivity().getString(R.string.msg_video_has_been_removed), Toast.LENGTH_SHORT).show();

                        mPagerStateAdapter.removeFragment(currentPosition);
                        mViewPager.setAdapter(mPagerStateAdapter);
                        mPagerStateAdapter.notifyDataSetChanged();
                        mViewPager.setCurrentItem(currentPosition);

                        if (mPagerStateAdapter.getCount() == 0 && !isMainScreen) {

                            getActivity().finish();
                        }
                    }
                });

                alertDialog.show();
            }
        });

        if (p.getFromUserId() != App.getInstance().getAccount().getId()) {

            mNotInterestedButton.setVisibility(View.VISIBLE);
        }

        mNotInterestedButton.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                androidx.appcompat.app.AlertDialog.Builder alertDialog = new androidx.appcompat.app.AlertDialog.Builder(getActivity());
                alertDialog.setTitle(getText(R.string.action_hide_item));

                alertDialog.setMessage(getText(R.string.label_hide_item));
                alertDialog.setCancelable(true);

                alertDialog.setNegativeButton(getText(R.string.action_no), new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.cancel();
                    }
                });

                alertDialog.setPositiveButton(getText(R.string.action_yes), new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        if (!App.getInstance().getDatabaseManager().isExist(p.getId())) {

                            long unixTime = System.currentTimeMillis() / 1000L;

                            App.getInstance().getDatabaseManager().insert(p.getId(), unixTime);
                        }

                        Toast.makeText(getActivity(), getActivity().getString(R.string.msg_video_has_been_hidden), Toast.LENGTH_SHORT).show();

                        mPagerStateAdapter.removeFragment(currentPosition);
                        mViewPager.setAdapter(mPagerStateAdapter);
                        mPagerStateAdapter.notifyDataSetChanged();
                        mViewPager.setCurrentItem(currentPosition);
                    }
                });

                alertDialog.show();
            }
        });

        mReportButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                String[] profile_report_categories = new String[] {

                        getActivity().getText(R.string.label_profile_report_0).toString(),
                        getActivity().getText(R.string.label_profile_report_1).toString(),
                        getActivity().getText(R.string.label_profile_report_2).toString(),
                        getActivity().getText(R.string.label_profile_report_3).toString(),

                };

                androidx.appcompat.app.AlertDialog.Builder alertDialog = new androidx.appcompat.app.AlertDialog.Builder(getActivity());
                alertDialog.setTitle(getActivity().getText(R.string.label_post_report_title));

                alertDialog.setSingleChoiceItems(profile_report_categories, 0, null);
                alertDialog.setCancelable(true);

                alertDialog.setNegativeButton(getActivity().getText(R.string.action_cancel), new DialogInterface.OnClickListener() {

                    @Override
                    public void onClick(DialogInterface dialog, int which) {

                        dialog.cancel();
                    }
                });

                alertDialog.setPositiveButton(getActivity().getText(R.string.action_ok), new DialogInterface.OnClickListener() {

                    public void onClick(DialogInterface dialog, int which) {

                        androidx.appcompat.app.AlertDialog alert = (androidx.appcompat.app.AlertDialog) dialog;
                        int reason = alert.getListView().getCheckedItemPosition();

                        Api api = new Api(getContext());
                        api.newReport(p.getId(), REPORT_TYPE_ITEM, reason);

                        Toast.makeText(getActivity(), getActivity().getString(R.string.label_item_reported), Toast.LENGTH_SHORT).show();
                    }
                });

                alertDialog.show();
            }
        });

        //

        mBottomSheetDialog = new BottomSheetDialog(getActivity(), R.style.AppBottomSheetDialogTheme);
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    public void showItemShareBottomSheet(int state) {

        mBehavior.setState(state);

        int currentPosition = mViewPager.getCurrentItem();
        Item p = itemsList.get(currentPosition);

        final View view = getLayoutInflater().inflate(R.layout.item_action_sheet_list, null);

        //

        ImageButton mCloseButton = view.findViewById(R.id.close_button);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                mBottomSheetDialog.dismiss();
            }
        });

        //

        MaterialRippleLayout mReportButton = view.findViewById(R.id.report_button);
        MaterialRippleLayout mLoginButton = view.findViewById(R.id.login_button);
        MaterialRippleLayout mSignupButton = view.findViewById(R.id.signup_button);
        MaterialRippleLayout mEditButton = view.findViewById(R.id.edit_button);
        MaterialRippleLayout mDeleteButton = view.findViewById(R.id.delete_button);
        MaterialRippleLayout mShareButton = view.findViewById(R.id.share_button);
        MaterialRippleLayout mDownloadButton = view.findViewById(R.id.download_button);
        MaterialRippleLayout mRepostButton = view.findViewById(R.id.repost_button);
        MaterialRippleLayout mPinButton = view.findViewById(R.id.pin_button);
        MaterialRippleLayout mCopyUrlButton = view.findViewById(R.id.copy_url_button);
        MaterialRippleLayout mOpenUrlButton = view.findViewById(R.id.open_url_button);
        MaterialRippleLayout mNotInterestedButton = view.findViewById(R.id.not_interested_button);

        mReportButton.setVisibility(View.GONE);
        mLoginButton.setVisibility(View.GONE);
        mSignupButton.setVisibility(View.GONE);
        mRepostButton.setVisibility(View.GONE);
        mCopyUrlButton.setVisibility(View.GONE);
        mOpenUrlButton.setVisibility(View.GONE);
        mPinButton.setVisibility(View.GONE);
        mEditButton.setVisibility(View.GONE);
        mDeleteButton.setVisibility(View.GONE);
        mNotInterestedButton.setVisibility(View.GONE);
        mDownloadButton.setVisibility(View.GONE);

        if (p.getAllowDownloadVideos() == 1 || App.getInstance().getId() == p.getFromUserId()) {

            mDownloadButton.setVisibility(View.VISIBLE);
        }

        mDownloadButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                String filename = Helper.randomString(6) + ".mp4";
                String downloadUrlOfImage = p.getVideoUrl();

                DownloadManager dm = (DownloadManager) getContext().getSystemService(Context.DOWNLOAD_SERVICE);
                Uri downloadUri = Uri.parse(downloadUrlOfImage);
                DownloadManager.Request request = new DownloadManager.Request(downloadUri);
                request.setAllowedNetworkTypes(DownloadManager.Request.NETWORK_WIFI | DownloadManager.Request.NETWORK_MOBILE)
                        .setAllowedOverRoaming(false)
                        .setTitle(filename)
                        .setMimeType("video/mp4")
                        .setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                        .setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);

                dm.enqueue(request);

                Toast.makeText(getActivity(), getString(R.string.msg_download_started), Toast.LENGTH_SHORT).show();
            }
        });

        mShareButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mBottomSheetDialog.dismiss();

                Intent i = new Intent(Intent.ACTION_SEND);
                i.setType("text/plain");
                i.putExtra(Intent.EXTRA_SUBJECT, String.format(getString(R.string.label_share_subject), getString(R.string.app_name)));
                i.putExtra(Intent.EXTRA_TEXT, API_DOMAIN + "i/" + Long.toString(p.getId()));
                startActivity(Intent.createChooser(i, getString(R.string.label_share_title)));
            }
        });

        //

        mBottomSheetDialog = new BottomSheetDialog(getActivity());
        mBottomSheetDialog.setContentView(view);
        ((View) view.getParent()).setBackgroundColor(Color.TRANSPARENT);

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {

            mBottomSheetDialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }

        mBottomSheetDialog.show();

        doKeepDialog(mBottomSheetDialog);

        mBottomSheetDialog.setOnDismissListener(new DialogInterface.OnDismissListener() {

            @Override
            public void onDismiss(DialogInterface dialog) {

                mBottomSheetDialog = null;
            }
        });
    }

    private void showItemCommentsDialog(int state, final Item item, final int item_position) {

//        mBehavior.setState(state);

        if (item.getRemoveAt() != 0) {

            return;
        }

        final ArrayList<Comment> itemsList;
        final CommentsListAdapter itemsAdapter;

        itemsList = new ArrayList<Comment>();
        itemsAdapter = new CommentsListAdapter(getContext(), itemsList);

//        BottomSheetDialog dialog = new BottomSheetDialog(getActivity());
//        dialog.setContentView(R.layout.dialog_comments);

//        final View view = getLayoutInflater().inflate(R.layout.dialog_comments, null);

        final Dialog dialog = new Dialog(getContext(), R.style.CommentsDialogStyle);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.getWindow().setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.MATCH_PARENT);
        dialog.setContentView(R.layout.dialog_comments);
        dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        dialog.setCancelable(true);

        final LinearLayout mItemBottomContainer = (LinearLayout) dialog.findViewById(R.id.item_bottom_container);
        mItemBottomContainer.setVisibility(View.GONE);

        if (item.getAllowComments() == 1) {

            mItemBottomContainer.setVisibility(View.VISIBLE);
        }

        final LinearLayout mItemInfoContainer = (LinearLayout) dialog.findViewById(R.id.item_info_container);
        mItemInfoContainer.setVisibility(View.VISIBLE);

        final MaterialRippleLayout mShowLikesButton = (MaterialRippleLayout) dialog.findViewById(R.id.show_likes_button);
        mShowLikesButton.setVisibility(View.GONE);

        mShowLikesButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (App.getInstance().getId() != 0) {

                    Intent intent = new Intent(getActivity(), ReactionsActivity.class);
                    intent.putExtra("itemId", item.getId());
                    getActivity().startActivity(intent);
                }
            }
        });

        final TextView mLikesCountLabel = (TextView) dialog.findViewById(R.id.likes_count_label);

        if (item.getLikesCount() != 0) {

            //mShowLikesButton.setVisibility(View.VISIBLE);

            mLikesCountLabel.setText(Integer.toString(item.getLikesCount()));
        }

        final MaterialRippleLayout mCloseDialogButton = (MaterialRippleLayout) dialog.findViewById(R.id.close_dialog_button);
        mCloseDialogButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                dialog.cancel();
            }
        });

        final AXEmojiEditText mCommentEditor = (AXEmojiEditText) dialog.findViewById(R.id.comment_editor);
        final LinearLayout mSendButton = (LinearLayout) dialog.findViewById(R.id.send_comment_button);

        final ProgressBar mProgressBar = (ProgressBar) dialog.findViewById(R.id.progress_bar);
        mProgressBar.setVisibility(View.GONE);

        final TextView mMessageLabel = (TextView) dialog.findViewById(R.id.message_label);
        mMessageLabel.setVisibility(View.GONE);

        final NestedScrollView mDlgNestedView = (NestedScrollView) dialog.findViewById(R.id.nested_view);
        final RecyclerView mDlgRecyclerView = (RecyclerView) dialog.findViewById(R.id.recycler_view);

        final GridLayoutManager mLayoutManager = new GridLayoutManager(getActivity(), 1);
        mDlgRecyclerView.setLayoutManager(mLayoutManager);

        itemsAdapter.setOnMoreButtonClickListener(new CommentsListAdapter.OnItemMenuButtonClickListener() {

            @Override
            public void onItemClick(View v, Comment obj, int actionId, final int position) {

                switch (actionId){

                    case R.id.action_remove: {

                        AlertDialog.Builder alertDialog = new AlertDialog.Builder(getContext());
                        alertDialog.setTitle(getContext().getText(R.string.label_delete));

                        alertDialog.setMessage(getContext().getText(R.string.label_delete_comment));
                        alertDialog.setCancelable(true);

                        alertDialog.setNegativeButton(getContext().getText(R.string.action_cancel), new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.cancel();
                            }
                        });

                        alertDialog.setPositiveButton(getContext().getText(R.string.action_yes), new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int which) {

                                Api api = new Api(getContext());
                                api.commentDelete(itemsList.get(position).getId(), Constants.ITEM_TYPE_POST);

                                itemsList.remove(position);
                                itemsAdapter.notifyItemRemoved(position);

                                item.setCommentsCount(item.getCommentsCount() - 1);

                                //

//                                App.getInstance().setHomeCurrentItemId(item.getId());
//                                App.getInstance().setHomeCurrentItemCommentsCnt(item.getCommentsCount());

                                Intent intent = new Intent(TAG_UPDATE_VIDEO_ITEM);
                                intent.putExtra("itemId", item.getId());
                                intent.putExtra("comments_cnt", item.getCommentsCount());
                                getContext().sendBroadcast(intent);

                                //notifyItemChanged(item_position);
                            }
                        });

                        alertDialog.show();

                        break;
                    }

                    case R.id.action_reply: {

                        if (App.getInstance().getId() != 0) {

                            replyToUserId = obj.getFromUserId();

                            mCommentEditor.setText("@" + obj.getOwner().getUsername() + ", ");
                            mCommentEditor.setSelection(mCommentEditor.getText().length());

                            mCommentEditor.requestFocus();

                        }

                        break;
                    }

                    case R.id.action_report: {

                        String[] profile_report_categories = new String[] {

                                getContext().getText(R.string.label_profile_report_0).toString(),
                                getContext().getText(R.string.label_profile_report_1).toString(),
                                getContext().getText(R.string.label_profile_report_2).toString(),
                                getContext().getText(R.string.label_profile_report_3).toString(),

                        };

                        androidx.appcompat.app.AlertDialog.Builder alertDialog = new androidx.appcompat.app.AlertDialog.Builder(getContext());
                        alertDialog.setTitle(getContext().getText(R.string.label_post_report_title));

                        alertDialog.setSingleChoiceItems(profile_report_categories, 0, null);
                        alertDialog.setCancelable(true);

                        alertDialog.setNegativeButton(getContext().getText(R.string.action_cancel), new DialogInterface.OnClickListener() {

                            @Override
                            public void onClick(DialogInterface dialog, int which) {

                                dialog.cancel();
                            }
                        });

                        alertDialog.setPositiveButton(getContext().getText(R.string.action_ok), new DialogInterface.OnClickListener() {

                            public void onClick(DialogInterface dialog, int which) {

                                androidx.appcompat.app.AlertDialog alert = (androidx.appcompat.app.AlertDialog) dialog;
                                int reason = alert.getListView().getCheckedItemPosition();

                                Toast.makeText(getActivity(), getContext().getString(R.string.label_item_reported), Toast.LENGTH_SHORT).show();
                            }
                        });

                        alertDialog.show();

                        break;
                    }
                }
            }
        });

        mDlgRecyclerView.setAdapter(itemsAdapter);

        mDlgRecyclerView.setNestedScrollingEnabled(true);

        itemsAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {

            @Override
            public void onChanged() {

                super.onChanged();

                if (itemsList.size() != 0) {

                    mDlgRecyclerView.setVisibility(View.VISIBLE);
                    mProgressBar.setVisibility(View.GONE);
                    mMessageLabel.setVisibility(View.GONE);

                    mDlgNestedView.post(new Runnable() {

                        @Override
                        public void run() {
                            // Select the last row so it will scroll into view...
                            mDlgNestedView.fullScroll(View.FOCUS_DOWN);
                        }
                    });

                } else {

                    mProgressBar.setVisibility(View.GONE);
                    mMessageLabel.setVisibility(View.VISIBLE);
                }
            }
        });

        if (item.getCommentsCount() != 0) {

            if (itemsList.size() == 0) {

                mMessageLabel.setVisibility(View.GONE);
                mDlgRecyclerView.setVisibility(View.GONE);
                mProgressBar.setVisibility(View.VISIBLE);

                Api api = new Api(getContext());
                api.getItemComments(item.getId(), itemsList, itemsAdapter);
            }

        } else {

            mMessageLabel.setVisibility(View.VISIBLE);
        }

        mCommentEditor.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                mSendButton.setEnabled(!s.toString().trim().isEmpty());
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        mSendButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String text = mCommentEditor.getText().toString().trim();

                if (text.length() != 0) {

                    item.setCommentsCount(item.getCommentsCount() + 1);

                    //

//                    App.getInstance().setHomeCurrentItemId(item.getId());
//                    App.getInstance().setHomeCurrentItemCommentsCnt(item.getCommentsCount());

                    Intent intent = new Intent(TAG_UPDATE_VIDEO_ITEM);
                    intent.putExtra("itemId", item.getId());
                    intent.putExtra("comments_cnt", item.getCommentsCount());
                    getContext().sendBroadcast(intent);

                    //notifyItemChanged(item_position);

                    Api api = new Api(getContext());
                    api.sendComment(item.getId(), Constants.ITEM_TYPE_POST, replyToUserId, text, itemsList, itemsAdapter);

                    replyToUserId = 0;
                }

                mCommentEditor.setText("");
            }
        });

//        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
//
//            dialog.getWindow().addFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
//        }

//        mBehavior.setPeekHeight(800);
//        dialog.getBehavior().setFitToContents(false);
//        dialog.getBehavior().setExpandedOffset(100);
//        dialog.getBehavior().setPeekHeight(800);
        dialog.setCancelable(true);
        dialog.setCanceledOnTouchOutside(true);
        dialog.show();

//        doKeepDialog(dialog);
//
//        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
//
//            @Override
//            public void onDismiss(DialogInterface dialog) {
//
//                dialog = null;
//            }
//        });

//        dialog.show();

        WindowManager.LayoutParams lp = new  WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.gravity = Gravity.BOTTOM;
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = 1600;
        dialog.getWindow().setAttributes(lp);
    }

    private static void doKeepDialog(Dialog dialog){

        WindowManager.LayoutParams lp = new  WindowManager.LayoutParams();
        lp.copyFrom(dialog.getWindow().getAttributes());
        lp.width = WindowManager.LayoutParams.MATCH_PARENT;
        lp.height = WindowManager.LayoutParams.MATCH_PARENT;
        dialog.getWindow().setAttributes(lp);
    }

    protected void initpDialog() {

        pDialog = new ProgressDialog(getActivity());
        pDialog.setMessage(getString(R.string.msg_loading));
        pDialog.setCancelable(false);
    }

    protected void showpDialog() {

        if (!pDialog.isShowing()) pDialog.show();
    }

    protected void hidepDialog() {

        if (pDialog.isShowing()) pDialog.dismiss();
    }

    @Override
    public void onResume() {

        super.onResume();

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            getActivity().registerReceiver(mFragmentReceiver, new IntentFilter(TAG_ITEM_ACTION_BOTTOM_SHEET), RECEIVER_NOT_EXPORTED);

        } else {

            getActivity().registerReceiver(mFragmentReceiver, new IntentFilter(TAG_ITEM_ACTION_BOTTOM_SHEET));
        }
    }

    @Override
    public void onPause() {

        super.onPause();

        getActivity().unregisterReceiver(mFragmentReceiver);
    }

    @Override
    public void onStart() {

        super.onStart();

        getActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    @Override
    public void onStop() {

        super.onStop();

        getActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }

    private BroadcastReceiver mFragmentReceiver = new BroadcastReceiver() {

        @Override
        public void onReceive(Context context, Intent intent) {

            // Extract data included in the Intent
            String message = intent.getStringExtra("message");

            int currentPosition = mViewPager.getCurrentItem();
            Item p = itemsList.get(currentPosition);

            switch (message) {

                case "auth": {

                    showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);

                    break;
                }

                case "share": {

                    showItemShareBottomSheet(BottomSheetBehavior.STATE_EXPANDED);

                    break;
                }

                case "comments": {

                    if (App.getInstance().getId() == 0) {

                        showAuthorizationBottomSheet(BottomSheetBehavior.STATE_EXPANDED);

                    } else {

                        showItemCommentsDialog(BottomSheetBehavior.STATE_EXPANDED, p, currentPosition);
                    }

                    break;
                }

                case "actions": {

                    showItemActionBottomSheet(BottomSheetBehavior.STATE_EXPANDED);

                    break;
                }

                default: {

                    break;
                }
            }
        }
    };
}