package com.raccoonsquare.reels.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.recyclerview.widget.RecyclerView;

import com.android.volley.toolbox.ImageLoader;
import com.raccoonsquare.reels.R;
import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.model.MarketItem;
import com.raccoonsquare.reels.util.Helper;
import com.squareup.picasso.Callback;
import com.squareup.picasso.Picasso;

import java.util.List;


public class MarketListAdapterV2 extends RecyclerView.Adapter<MarketListAdapterV2.MyViewHolder> {

	private Context mContext;
	private List<MarketItem> itemList;

    ImageLoader imageLoader = App.getInstance().getImageLoader();

    private OnItemClickListener mOnItemClickListener;

    public interface OnItemClickListener {

        void onItemClick(View view, MarketItem obj, int position);
    }

    public void setOnItemClickListener(final OnItemClickListener mItemClickListener) {

        this.mOnItemClickListener = mItemClickListener;
    }

	public class MyViewHolder extends RecyclerView.ViewHolder {

        public TextView mPriceLabel;
        public ProgressBar mItemImageProgress;

        public ImageView mItemImg;

		public MyViewHolder(View v) {

			super(v);

            mItemImageProgress = v.findViewById(R.id.item_image_progress);
            mPriceLabel = v.findViewById(R.id.price_label);
            mItemImg = v.findViewById(R.id.item_image);
		}
	}


	public MarketListAdapterV2(Context mContext, List<MarketItem> itemList) {

		this.mContext = mContext;
		this.itemList = itemList;
	}

	@Override
	public MyViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {

		View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_market_layout_2, parent, false);


		return new MyViewHolder(itemView);
	}

	@Override
	public void onBindViewHolder(final MyViewHolder holder, final int position) {

		final MarketItem p = itemList.get(position);

        holder.mItemImg.setVisibility(View.GONE);
        holder.mItemImageProgress.setVisibility(View.VISIBLE);

        if (p.getImgUrl().length() != 0){

            final ProgressBar progressView = holder.mItemImageProgress;
            final ImageView imageView = holder.mItemImg;

            Picasso.with(mContext)
                    .load(p.getImgUrl())
                    .into(holder.mItemImg, new Callback() {

                        @Override
                        public void onSuccess() {

                            imageView.setVisibility(View.VISIBLE);
                            progressView.setVisibility(View.GONE);
                        }

                        @Override
                        public void onError() {

                            progressView.setVisibility(View.GONE);
                            imageView.setVisibility(View.VISIBLE);
                            imageView.setImageResource(R.drawable.img_loading_error);
                        }
                    });

        }

        Helper helper = new Helper();

        holder.mPriceLabel.setText(mContext.getString(R.string.label_currency) + helper.getFormatedAmount(p.getPrice()));

        holder.mItemImg.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                if (mOnItemClickListener != null) {

                    mOnItemClickListener.onItemClick(view, p, position);
                }
            }
        });
	}

	@Override
	public int getItemCount() {

		return itemList.size();
	}
}