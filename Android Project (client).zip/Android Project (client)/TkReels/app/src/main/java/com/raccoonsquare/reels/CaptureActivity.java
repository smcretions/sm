package com.raccoonsquare.reels;

import android.Manifest;
import android.annotation.SuppressLint;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.media.Image;
import android.media.MediaPlayer;
import android.media.ThumbnailUtils;
import android.net.Uri;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.provider.MediaStore;
import android.provider.Settings;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.animation.OvershootInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.result.ActivityResult;
import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.annotation.WorkerThread;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.content.res.AppCompatResources;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.core.view.ViewCompat;

import com.raccoonsquare.reels.util.Helper;
import com.coremedia.iso.boxes.Container;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;

import com.googlecode.mp4parser.authoring.Movie;
import com.googlecode.mp4parser.authoring.Track;
import com.googlecode.mp4parser.authoring.builder.DefaultMp4Builder;
import com.googlecode.mp4parser.authoring.container.mp4.MovieCreator;
import com.googlecode.mp4parser.authoring.tracks.AppendTrack;
import com.otaliastudios.cameraview.CameraListener;
import com.otaliastudios.cameraview.CameraLogger;
import com.otaliastudios.cameraview.CameraOptions;
import com.otaliastudios.cameraview.CameraView;
import com.otaliastudios.cameraview.VideoResult;
import com.otaliastudios.cameraview.controls.Audio;
import com.otaliastudios.cameraview.controls.Facing;
import com.otaliastudios.cameraview.filter.Filters;
import com.otaliastudios.cameraview.frame.Frame;
import com.otaliastudios.cameraview.frame.FrameProcessor;
import com.otaliastudios.cameraview.size.Size;


import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

import com.raccoonsquare.reels.app.App;
import com.raccoonsquare.reels.common.ActivityBase;
import com.raccoonsquare.reels.videotrimmer.utils.FileUtils;
import com.raccoonsquare.reels.videotrimmer.utils.TrimType;
import com.raccoonsquare.reels.videotrimmer.utils.TrimVideo;

public class CaptureActivity extends ActivityBase {

    private final CameraLogger LOG = CameraLogger.create("CaptureApp");
    private final Boolean USE_FRAME_PROCESSOR = false;
    private final Boolean DECODE_BITMAP = false;

    private int currentFilter = 0;
    private final Filters[] allFilters = Filters.values();

    private CameraView mCameraView;
    private ProgressBar mProgressBar;
    private ImageButton mCloseButton;
    private FloatingActionButton mFabCapture, mFabUpload, mFabToggle, mFabAudio, mFabTimeMenu, mFabTimeShortVideo, mFabTimeMediumVideo, mFabTimeNormalVideo, mFabTimeLongVideo;

    private int currentProgress = 0;
    private int duration = App.getInstance().getAppSettings().getShortCaptureTime();

    private CountDownTimer countdownTimer;
    public Boolean isTimerRunning = false;
    public Boolean isPaused = false;

    private Animation fabOpenAnimation;
    private Animation fabCloseAnimation;
    private boolean isFabMenuOpen = false;
    private ConstraintLayout mConstraintLayout;
    private LinearLayout mLongVideoLayout, mNormalVideoLayout, mMediumVideoLayout, mShortVideoLayout;
    private RelativeLayout mActionsMenuLayout;

    private LinearLayout mAddSoundLayout;
    private TextView mAddSoundTitle;

    private TextView mShortTimeLabel, mMediumTimeLabel, mNormalTimeLabel, mLongTimeLabel;
    private TextView mTimeTip;

    private long soundId = 0;
    private String soundTitle = "", soundUrl = "";

    private MediaPlayer mediaPlayer;

    private ArrayList<String> filesList;

    private ActivityResultLauncher<Intent> trimVideoActivityResultLauncher;
    private ActivityResultLauncher<Intent> selectSoundActivityResultLauncher;
    private ActivityResultLauncher<Intent> previewCaptureActivityResultLauncher;
    private ActivityResultLauncher<Intent> videoFromGalleryActivityResultLauncher;
    private ActivityResultLauncher<String[]> storagePermissionLauncher;


    @SuppressLint({"ResourceType", "ClickableViewAccessibility"})
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_capture);

        //

        filesList = new ArrayList<>();

        //

        Intent i = getIntent();

        soundId = i.getLongExtra("soundId", 0);
        soundTitle = i.getStringExtra("soundTitle");
        soundUrl = i.getStringExtra("soundUrl");

        //

        try {

            File f = new File(App.getInstance().getDirectory(), VIDEO_SRC_FILE);
            f.delete();

            File f_thumb = new File(App.getInstance().getDirectory(), VIDEO_THUMBNAIL_FILE);
            f_thumb.delete();

        } catch (Exception e) {

            Log.e("deleteTmpDir", "Unable to delete tmp folder");
        }

        //

        mActionsMenuLayout = findViewById(R.id.actions_menu_layout);

        //

        mConstraintLayout = findViewById(R.id.time_menu_layout);

        mConstraintLayout.setOnTouchListener((view, motionEvent) -> {

            if (isFabMenuOpen) {

                collapseFabMenu();
            }

            return false;
        });

        //

        mAddSoundLayout = findViewById(R.id.add_sound_layout);
        mAddSoundTitle = findViewById(R.id.add_sound_title);

        mAddSoundLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (!mCameraView.isTakingPicture() && !mCameraView.isTakingVideo() && !isPaused) {

                    Intent i = new Intent(CaptureActivity.this, SoundContentActivity.class);
                    selectSoundActivityResultLauncher.launch(i);
                }
            }
        });

        //

        mTimeTip = findViewById(R.id.time_tip);
        mTimeTip.setText(Integer.toString(duration / 1000) + "s");

        mShortTimeLabel = findViewById(R.id.time_short_video);
        mMediumTimeLabel = findViewById(R.id.time_medium_video);
        mNormalTimeLabel = findViewById(R.id.time_normal_video);
        mLongTimeLabel = findViewById(R.id.time_long_video);

        mShortTimeLabel.setText(String.format(getString(R.string.label_video_short), App.getInstance().getAppSettings().getShortCaptureTime() / 1000));
        mMediumTimeLabel.setText(String.format(getString(R.string.label_video_medium), App.getInstance().getAppSettings().getMediumCaptureTime() / 1000));
        mNormalTimeLabel.setText(String.format(getString(R.string.label_video_normal), App.getInstance().getAppSettings().getNormalCaptureTime() / 1000));
        mLongTimeLabel.setText(String.format(getString(R.string.label_video_long), App.getInstance().getAppSettings().getLongCaptureTime() / 1000));

        mLongVideoLayout = findViewById(R.id.long_video_layout);
        mNormalVideoLayout = findViewById(R.id.normal_video_layout);
        mMediumVideoLayout = findViewById(R.id.medium_video_layout);
        mShortVideoLayout = findViewById(R.id.short_video_layout);

        mFabTimeShortVideo = findViewById(R.id.fab_time_short_video);

        mFabTimeShortVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                duration = App.getInstance().getAppSettings().getShortCaptureTime();

                if (isFabMenuOpen) {

                    collapseFabMenu();

                } else {

                    expandFabMenu();
                }
            }
        });

        mFabTimeMediumVideo = findViewById(R.id.fab_time_medium_video);

        mFabTimeMediumVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                duration = App.getInstance().getAppSettings().getMediumCaptureTime();

                if (isFabMenuOpen) {

                    collapseFabMenu();

                } else {

                    expandFabMenu();
                }
            }
        });

        mFabTimeNormalVideo = findViewById(R.id.fab_time_normal_video);

        mFabTimeNormalVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isFabMenuOpen) {

                    collapseFabMenu();

                } else {

                    expandFabMenu();
                }

                if (App.getInstance().getAccount().getBloggerMode() == 0) {

                    AlertDialog alertDialog = new AlertDialog.Builder(CaptureActivity.this).create();
                    alertDialog.setIcon(R.drawable.ic_video_blogger);
                    alertDialog.setTitle(getString(R.string.label_upgrades_video_blogger_mode));
                    alertDialog.setMessage("\n" +  getString(R.string.label_tooltip_capture_video_blogger_feature) + "\n");

                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.action_cancel), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                        }
                    });

                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.action_open_upgrades_section), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            Intent i = new Intent(CaptureActivity.this, UpgradesActivity.class);
                            startActivity(i);

                            dialog.dismiss();
                        }
                    });

                    alertDialog.show();

                } else {

                    duration = App.getInstance().getAppSettings().getNormalCaptureTime();
                }
            }
        });

        mFabTimeLongVideo = findViewById(R.id.fab_time_long_video);

        mFabTimeLongVideo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isFabMenuOpen) {

                    collapseFabMenu();

                } else {

                    expandFabMenu();
                }

                if (App.getInstance().getAccount().getBloggerMode() == 0) {

                    AlertDialog alertDialog = new AlertDialog.Builder(CaptureActivity.this).create();
                    alertDialog.setIcon(R.drawable.ic_video_blogger);
                    alertDialog.setTitle(getString(R.string.label_upgrades_video_blogger_mode));
                    alertDialog.setMessage("\n" +  getString(R.string.label_tooltip_capture_video_blogger_feature) + "\n");

                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.action_cancel), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                        }
                    });

                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.action_open_upgrades_section), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            Intent i = new Intent(CaptureActivity.this, UpgradesActivity.class);
                            startActivity(i);

                            dialog.dismiss();
                        }
                    });

                    alertDialog.show();

                } else {

                    duration = App.getInstance().getAppSettings().getLongCaptureTime();
                }
            }
        });

        mFabTimeMenu = findViewById(R.id.fab_time_menu);

        //

        mFabTimeMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isFabMenuOpen) {

                    collapseFabMenu();

                } else {

                    expandFabMenu();
                }
            }
        });

        fabOpenAnimation = AnimationUtils.loadAnimation(this, R.animator.fab_open);
        fabCloseAnimation = AnimationUtils.loadAnimation(this, R.animator.fab_close);
        fabCloseAnimation.setFillAfter(true);

        //

        selectSoundActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == 100) {

                    Intent data = result.getData();

                    if (data != null) {

                        soundId = data.getLongExtra("soundId", 0);
                        soundTitle = data.getStringExtra("soundTitle");
                        soundUrl = data.getStringExtra("soundUrl");

                        if (soundId != 0) {

//                            try {
//
//                                mediaPlayer = MediaPlayer.create(CaptureActivity.this, Uri.parse(soundUrl));
//                                mediaPlayer.prepare();
//
//                            } catch (Exception e) {
//
//                                Log.e("mp3", "Exception: " + e.getMessage());
//                            }

                            if (soundTitle.length() != 0) {

                                mAddSoundTitle.setText(soundTitle);
                            }

                            mAddSoundTitle.setSelected(true);
                        }
                    }
                }
            }
        });

        //

        previewCaptureActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == 100) {

//                    Intent i = new Intent();
//                    setResult(100, i);

                    Log.e("Dimon", "run new item");

                    Intent i = new Intent(CaptureActivity.this, NewItemActivity.class);
                    startActivity(i);

                    finish();

                } else {

                    finish();
                    startActivity(getIntent());
                    overridePendingTransition(0, 0);
                }
            }
        });

        //

        videoFromGalleryActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {

            @Override
            public void onActivityResult(ActivityResult result) {

                if (result.getResultCode() == Activity.RESULT_OK) {

                    // The document selected by the user won't be returned in the intent.
                    // Instead, a URI to that document will be contained in the return intent
                    // provided to this method as a parameter.  Pull that uri using "resultData.getData()"

                    if (result.getData() != null) {

                        Log.e("Uri VideoUri", result.getData().getData().toString());

                        Helper helper = new Helper(App.getInstance().getApplicationContext());
                        App.getInstance().setSelectedVideoPath(FileUtils.getPath(getApplicationContext(), result.getData().getData()));
                        //App.getInstance().setSelectedVideoPath(Helper.getRealPath(result.getData().getData()));

                        Log.e("Str VideoUri", App.getInstance().getSelectedVideoPath());

                        File videoFile = new File(App.getInstance().getSelectedVideoPath());

                        if (videoFile.length() > VIDEO_FILE_MAX_SIZE_FROM_GALLERY) {

                            Toast.makeText(CaptureActivity.this, getString(R.string.msg_video_too_large), Toast.LENGTH_SHORT).show();

                        } else {

                            long timeInSec = 0;

                            MediaPlayer mp = MediaPlayer.create(getApplicationContext(), result.getData().getData());
                            timeInSec = TimeUnit.MILLISECONDS.toSeconds(mp.getDuration());
                            mp.release();

                            //int min_time = App.getInstance().getAppSettings().getShortCaptureTime() / 1000;
                            int min_time = 5; // seconds

                            if (timeInSec != 0 && timeInSec <= min_time) {

                                Intent i = new Intent(CaptureActivity.this, CapturePreviewActivity.class);
                                i.putExtra("imagePath", App.getInstance().getSelectedVideoPath());
                                i.putExtra("soundId", soundId);
                                i.putExtra("soundTitle", soundTitle);
                                i.putExtra("soundUrl", soundUrl);
                                previewCaptureActivityResultLauncher.launch(i);

                            } else {

                                long max_time = App.getInstance().getAppSettings().getMediumCaptureTime() / 1000;

                                if (App.getInstance().getAccount().getBloggerMode() == 1) {

                                    max_time = App.getInstance().getAppSettings().getLongCaptureTime() / 1000;
                                }

                                TrimVideo.activity(String.valueOf(result.getData().getData()))
                                        .setHideSeekBar(true)
                                        .setTrimType(TrimType.MIN_MAX_DURATION)
                                        //.setMinToMax(App.getInstance().getAppSettings().getShortCaptureTime() / 1000, max_time)  //seconds
                                        .setMinToMax(min_time, max_time)  //seconds
                                        .setDestination(App.getInstance().getDirectory().toString())
                                        .start(CaptureActivity.this);
                            }

                            mCameraView.destroy();
                        }
                    }
                }
            }
        });

        //

//        trimVideoActivityResultLauncher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), new ActivityResultCallback<ActivityResult>() {
//
//            @Override
//            public void onActivityResult(ActivityResult result) {
//
//                if (result.getResultCode() == Activity.RESULT_OK && result.getData() != null) {
//
////                    Uri uri = Uri.parse(TrimVideo.getTrimmedVideoPath(result.getData()));
////                    Log.d(TAG, "Trimmed path:: " + uri);
//
//                    //App.getInstance().setSelectedVideoPath(TrimVideo.getTrimmedVideoPath(result.getData()));
//
//                    File videoFile = new File(App.getInstance().getSelectedVideoPath());
//
//                    if (videoFile.length() > (VIDEO_FILE_MAX_SIZE * 2)) {
//
//                        Toast.makeText(CaptureActivity.this, getString(R.string.msg_video_too_large), Toast.LENGTH_SHORT).show();
//
//                    } else {
//
//                        Helper helper = new Helper(App.getInstance().getApplicationContext());
//                        helper.createThumbnail(ThumbnailUtils.createVideoThumbnail(App.getInstance().getSelectedVideoPath(), MediaStore.Images.Thumbnails.MINI_KIND), VIDEO_THUMBNAIL_FILE);
//
//                        Intent i = new Intent(CaptureActivity.this, CapturePreviewActivity.class);
//                        i.putExtra("imagePath", App.getInstance().getSelectedVideoPath());
//                        i.putExtra("soundId", soundId);
//                        i.putExtra("soundTitle", soundTitle);
//                        i.putExtra("soundUrl", soundUrl);
//                        previewCaptureActivityResultLauncher.launch(i);
//                    }
//
//                } else {
//
//                    //LogMessage.v("videoTrimResultLauncher data is null");
//                }
//            }
//        });

        //

        storagePermissionLauncher = registerForActivityResult(new ActivityResultContracts.RequestMultiplePermissions(), (Map<String, Boolean> isGranted) -> {

            boolean granted = false;
            String storage_permission = Manifest.permission.READ_EXTERNAL_STORAGE;

            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

                storage_permission = Manifest.permission.READ_MEDIA_VIDEO;
            }

            for (Map.Entry<String, Boolean> x : isGranted.entrySet()) {

                if (x.getKey().equals(storage_permission)) {

                    if (x.getValue()) {

                        granted = true;
                    }
                }
            }

            if (granted) {

                Log.e("Permissions", "granted");

                selectVideo();

            } else {

                Log.e("Permissions", "denied");

                Snackbar.make(findViewById(android.R.id.content), getString(R.string.label_no_storage_permission) , Snackbar.LENGTH_LONG).setAction(getString(R.string.action_settings), new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        Intent appSettingsIntent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + App.getInstance().getPackageName()));
                        startActivity(appSettingsIntent);

                        Toast.makeText(getApplicationContext(), getString(R.string.label_grant_storage_permission), Toast.LENGTH_SHORT).show();
                    }

                }).show();
            }

        });

        //

        mCameraView = findViewById(R.id.camera);
        mProgressBar = findViewById(R.id.progressBar);

        //

        mCloseButton = findViewById(R.id.closeButton);
        mCloseButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                mCameraView.stopVideo();

                finish();
            }
        });

        //

        mFabCapture = findViewById(R.id.fab_capture);

        mFabCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                captureVideo();
            }
        });

        mFabUpload = findViewById(R.id.fab_upload);

        mFabUpload.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                Helper helper = new Helper(App.getInstance().getApplicationContext());

                if (!helper.checkVideoPermission()) {

                    requestStoragePermission();

                } else {

                    selectVideo();
                }
            }
        });

        mFabToggle = findViewById(R.id.fab_toggle);

        mFabToggle.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {

                toggleCamera();
            }
        });

        mFabAudio = findViewById(R.id.fab_audio);

        mFabAudio.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if (isPaused) {

                    AlertDialog alertDialog = new AlertDialog.Builder(CaptureActivity.this).create();
                    alertDialog.setCancelable(true);
                    alertDialog.setTitle(getString(R.string.action_video_capture));
                    alertDialog.setMessage(getString(R.string.msg_cancel_capture_progress));

                    alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.action_yes), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            filesList.clear();

                            currentProgress = 0;
                            isPaused = false;
                            stopMp3();

                            stopTimer();

                            dialog.dismiss();
                        }
                    });

                    alertDialog.setButton(AlertDialog.BUTTON_NEGATIVE, getString(R.string.action_no), new DialogInterface.OnClickListener() {

                        public void onClick(DialogInterface dialog, int which) {

                            dialog.dismiss();
                        }
                    });

                    alertDialog.show();

                } else {

                    toggleAudio();
                }
            }
        });

        CameraLogger.setLogLevel(CameraLogger.LEVEL_VERBOSE);

        // StatusBar

        Window window = this.getWindow();
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);

        window.setStatusBarColor(Color.TRANSPARENT);

        int statusBarHeight = 0;
        int resourceId = getResources().getIdentifier("status_bar_height", "dimen", "android");

        if (resourceId > 0) {

            statusBarHeight = getResources().getDimensionPixelSize(resourceId);
        }

        FrameLayout.LayoutParams layoutParams = (FrameLayout.LayoutParams) mProgressBar.getLayoutParams();
        layoutParams.setMargins(16, statusBarHeight + 16, 16, 0);
        mProgressBar.setLayoutParams(layoutParams);

        CoordinatorLayout.LayoutParams layoutParams2 = (CoordinatorLayout.LayoutParams) mCloseButton.getLayoutParams();
        layoutParams2.setMargins(0, statusBarHeight + 26, 0, 0);
        mCloseButton.setLayoutParams(layoutParams2);

        //

        mCameraView.setLifecycleOwner(this);

        mCameraView.addCameraListener(new CameraListener() {
            @Override
            public void onCameraOpened(@NonNull CameraOptions options) {

                super.onCameraOpened(options);
            }

            @Override
            public void onVideoTaken(@NonNull VideoResult result) {

                super.onVideoTaken(result);

                Log.e("onVideoTaken", "onVideoTaken");

                if (result.getFile().exists()) {

                    filesList.add(App.getInstance().getDirectory().toString() + File.separator + result.getFile().getName());

                } else {

                    Log.e("onVideoTaken", "!result.getFile().exists()");
                }

                Log.e("onVideoTaken currentProgress: ", Integer.toString(currentProgress));

                if (currentProgress + 3000 >= duration) {

                    if (filesList.size() > 1) {

                        mergeVideoParts();

                    } else {

                        Log.e("onVideoTaken", "filesList.size() == 1");

                        if (result.getFile().exists()) {

                            Log.e("onVideoTaken", "getFile().exists()");

                            File from = new File(filesList.get(0));
                            File to = new File(App.getInstance().getDirectory(), VIDEO_SRC_FILE);

                            if (from.exists()) from.renameTo(to);

                            Intent i = new Intent(CaptureActivity.this, CapturePreviewActivity.class);
                            i.putExtra("soundId", soundId);
                            i.putExtra("soundTitle", soundTitle);
                            i.putExtra("soundUrl", soundUrl);
                            previewCaptureActivityResultLauncher.launch(i);

                            mCameraView.destroy();

                            filesList.clear();
                        }
                    }

                    currentProgress = 0;
                    isPaused = false;
                    stopMp3();
                }

                stopTimer();
            }

            @Override
            public void onVideoRecordingStart() {

                super.onVideoRecordingStart();

                startTimer();
            }



            @Override
            public void onVideoRecordingEnd() {

                super.onVideoRecordingEnd();

                stopTimer();
            }
        });

        mCameraView.addFrameProcessor(new FrameProcessor() {

            @Override
            @WorkerThread
            public void process(@NonNull Frame frame) {

                long time = frame.getTime();
                Size size = frame.getSize();
                int format = frame.getFormat();
                int userRotation = frame.getRotationToUser();
                int viewRotation = frame.getRotationToView();

                if (frame.getDataClass() == byte[].class) {

                    byte[] data = frame.getData();
                    // Process byte array...
                } else if (frame.getDataClass() == Image.class) {

                    Image data = frame.getData();
                    // Process android.media.Image...
                }
            }
        });

        if (App.getInstance().getTooltipsSettings().isAllowShowCaptureVideoTimeTooltip()) {

            AlertDialog alertDialog = new AlertDialog.Builder(this).create();
            alertDialog.setIcon(R.drawable.ic_time);
            alertDialog.setTitle(getString(R.string.label_tooltip));
            alertDialog.setMessage("\n" +  getString(R.string.label_tooltip_capture_video_time) + "\n");

            alertDialog.setButton(AlertDialog.BUTTON_POSITIVE, getString(R.string.action_understand), new DialogInterface.OnClickListener() {

                public void onClick(DialogInterface dialog, int which) {

                    App.getInstance().getTooltipsSettings().setShowCaptureVideoTimeTooltip(false);
                    App.getInstance().saveTooltipsSettings();

                    dialog.dismiss();
                }
            });

            alertDialog.show();
        }

        updateView();
    }

    private void mergeVideoParts() {

        final ProgressDialog progressDialog = new ProgressDialog(CaptureActivity.this);
        new Thread(new Runnable() {
            @Override
            public void run() {

                runOnUiThread(new Runnable() {
                    public void run() {

                        progressDialog.setMessage(getString(R.string.msg_loading));
                        progressDialog.show();
                    }
                });

                try {

                    Movie[] inMovies = new Movie[filesList.size()];

                    for (int i = 0; i < filesList.size(); i++) {

                        inMovies[i] = MovieCreator.build(filesList.get(i));
                    }


                    List<Track> videoTracks = new LinkedList<Track>();
                    List<Track> audioTracks = new LinkedList<Track>();

                    for (Movie m : inMovies) {

                        for (Track t : m.getTracks()) {

                            if (t.getHandler().equals("soun")) {

                                audioTracks.add(t);
                            }

                            if (t.getHandler().equals("vide")) {

                                videoTracks.add(t);
                            }
                        }
                    }

                    Movie result = new Movie();

                    if (audioTracks.size() > 0) {

                        result.addTrack(new AppendTrack(audioTracks.toArray(new Track[audioTracks.size()])));
                    }

                    if (videoTracks.size() > 0) {

                        result.addTrack(new AppendTrack(videoTracks.toArray(new Track[videoTracks.size()])));
                    }

                    Container out = new DefaultMp4Builder().build(result);

                    String outputFilePath = App.getInstance().getDirectory().toString() + File.separator + VIDEO_SRC_FILE;

                    File file =  new File(App.getInstance().getDirectory(), Integer.toString(filesList.size()) + "_" + VIDEO_SRC_FILE);

                    FileOutputStream fos = new FileOutputStream(new File(outputFilePath));
                    out.writeContainer(fos.getChannel());
                    fos.close();

                    runOnUiThread(new Runnable() {
                        public void run() {

                            if (progressDialog != null && progressDialog.isShowing()) {

                                progressDialog.dismiss();
                            }

                            Intent i = new Intent(CaptureActivity.this, CapturePreviewActivity.class);
                            i.putExtra("soundId", soundId);
                            i.putExtra("soundTitle", soundTitle);
                            i.putExtra("soundUrl", soundUrl);
                            previewCaptureActivityResultLauncher.launch(i);

                            mCameraView.destroy();

                            filesList.clear();
                        }
                    });


                } catch (Exception e) {

                    Log.e("Dimon V", filesList.toString());

                    Log.e("Dimon V", e.toString());

                    e.printStackTrace();
                }
            }
        }).start();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {

        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == TrimVideo.VIDEO_TRIMMER_REQ_CODE && data != null) {

            Uri uri = Uri.parse(TrimVideo.getTrimmedVideoPath(data));
            Log.e("Dimon", "Trimmed path:: " + uri);

            App.getInstance().setSelectedVideoPath(TrimVideo.getTrimmedVideoPath(data));

            File videoFile = new File(App.getInstance().getSelectedVideoPath());

            if (videoFile.length() > VIDEO_FILE_MAX_SIZE_FROM_GALLERY) {

                Toast.makeText(CaptureActivity.this, getString(R.string.msg_video_too_large), Toast.LENGTH_SHORT).show();

            } else {

                Helper helper = new Helper(App.getInstance().getApplicationContext());
                helper.createThumbnail(ThumbnailUtils.createVideoThumbnail(App.getInstance().getSelectedVideoPath(), MediaStore.Images.Thumbnails.MINI_KIND), VIDEO_THUMBNAIL_FILE);

                Intent i = new Intent(CaptureActivity.this, CapturePreviewActivity.class);
                i.putExtra("imagePath", App.getInstance().getSelectedVideoPath());
                i.putExtra("soundId", soundId);
                i.putExtra("soundTitle", soundTitle);
                i.putExtra("soundUrl", soundUrl);
                previewCaptureActivityResultLauncher.launch(i);

                mCameraView.destroy();
            }

        } else if (requestCode == TrimVideo.VIDEO_TRIMMER_REQ_CODE && data == null) {

            Log.e("Dimon17", "Trimmed path:: ");

            finish();
            startActivity(getIntent());
            overridePendingTransition(0, 0);
        }
    }

    private void updateView() {

        mProgressBar.setProgressDrawable(AppCompatResources.getDrawable(this, R.drawable.capture_progressbar));

        if (soundId != 0) {

            if (soundTitle.length() != 0) {

                mAddSoundTitle.setText(soundTitle);
            }

            mAddSoundTitle.setSelected(true);
        }

        if (mCameraView.isTakingPicture() || mCameraView.isTakingVideo()) {

            playMp3();

            if (soundId == 0) {

                mAddSoundLayout.setVisibility(View.GONE);
            }

            mTimeTip.setVisibility(View.GONE);
            mFabCapture.setImageResource(R.drawable.ic_pause);
            mProgressBar.setVisibility(View.VISIBLE);
            mFabUpload.setVisibility(View.GONE);
            mFabAudio.setVisibility(View.GONE);
            mFabToggle.setVisibility(View.GONE);
            mCloseButton.setVisibility(View.GONE);
            mFabTimeMenu.setVisibility(View.GONE);

        } else {

            if (soundId == 0 && isPaused) {

                mAddSoundLayout.setVisibility(View.GONE);

            } else {

                mAddSoundLayout.setVisibility(View.VISIBLE);
            }

            stopMp3();

            mFabCapture.setImageResource(R.drawable.ic_capture_start);

            if (mCameraView.getAudio() == Audio.ON) {

                mFabAudio.setImageResource(R.drawable.ic_capture_micro_on);

            } else {

                mFabAudio.setImageResource(R.drawable.ic_capture_micro_off);
            }

            if (!isPaused) {

                mTimeTip.setVisibility(View.VISIBLE);
                mProgressBar.setVisibility(View.GONE);
                mFabUpload.setVisibility(View.VISIBLE);
                mFabToggle.setVisibility(View.VISIBLE);
                mCloseButton.setVisibility(View.VISIBLE);
                mFabTimeMenu.setVisibility(View.VISIBLE);

                mFabAudio.setVisibility(View.VISIBLE);

            } else {

                mProgressBar.setProgressDrawable(AppCompatResources.getDrawable(this, R.drawable.capture_progressbar_paused));

                mFabAudio.setVisibility(View.VISIBLE);
                mFabAudio.setImageResource(R.drawable.ic_backspace);
            }
        }
    }

    private void toggleAudio() {

        if (mCameraView.getAudio() == Audio.ON) {

            mCameraView.setAudio(Audio.OFF);

        } else {

            mCameraView.setAudio(Audio.ON);
        }

        updateView();
    }

    private void toggleCamera() {

        if (mCameraView.isTakingPicture() || mCameraView.isTakingVideo()) return;

        if (mCameraView.getFacing() == Facing.BACK) {

            //mCameraView.setFacing(Facing.FRONT);

        } else {

            //mCameraView.setFacing(Facing.BACK);
        }

        mCameraView.toggleFacing();
    }

    private void captureVideo() {

        if (mCameraView.isTakingVideo()) {

            isPaused = true;

            mCameraView.stopVideo();

        } else {

            File file =  new File(App.getInstance().getDirectory(), Integer.toString(filesList.size()) + "_" + VIDEO_SRC_FILE);

            mCameraView.takeVideo(file, duration - currentProgress);
        }

        updateView();
    }

    private void startTimer() {

        mCloseButton.setVisibility(View.GONE);
        mProgressBar.setVisibility(View.VISIBLE);

//        if (!isPaused) {
//
//            currentProgress = 0;
//        }

        mProgressBar.setProgress(currentProgress);
        mProgressBar.setMax(duration);

        countdownTimer = new CountDownTimer(duration, 1000) {
            @Override
            public void onTick(long l) {

                mProgressBar.setProgress(currentProgress + 1000);
                currentProgress = mProgressBar.getProgress();
                currentProgress = mProgressBar.getProgress();
            }

            @Override
            public void onFinish() {

                mCloseButton.setVisibility(View.VISIBLE);
                mProgressBar.setVisibility(View.GONE);

                countdownTimer.cancel();
                isTimerRunning = false;
                isPaused = false;
                mCameraView.stopVideo();

                updateView();
            }
        };

        isTimerRunning = true;

        countdownTimer.start();

        updateView();
    }

    private void stopTimer() {

        mCloseButton.setVisibility(View.VISIBLE);

        if (!isPaused) {

            mProgressBar.setVisibility(View.GONE);
        }

        if (countdownTimer != null) {

            countdownTimer.cancel();
        }

        isTimerRunning = false;

        updateView();
    }

    @Override
    public void onBackPressed() {

        if (isFabMenuOpen) {

            collapseFabMenu();

        } else {

            super.onBackPressed();
        }
    }

    private void expandFabMenu() {

        mTimeTip.setVisibility(View.GONE);

        mActionsMenuLayout.startAnimation(fabCloseAnimation);
        mAddSoundLayout.setVisibility(View.GONE);

        mFabTimeMenu.setImageResource(R.drawable.ic_plus);

        ViewCompat.animate(mFabTimeMenu).rotation(45.0F).withLayer().setDuration(300).setInterpolator(new OvershootInterpolator(10.0F)).start();
        mShortVideoLayout.startAnimation(fabOpenAnimation);
        mMediumVideoLayout.startAnimation(fabOpenAnimation);
        mNormalVideoLayout.startAnimation(fabOpenAnimation);
        mLongVideoLayout.startAnimation(fabOpenAnimation);

        isFabMenuOpen = true;
    }

    private void collapseFabMenu() {

        mTimeTip.setVisibility(View.VISIBLE);
        mTimeTip.setText(Integer.toString(duration / 1000) + "s");

        mActionsMenuLayout.startAnimation(fabOpenAnimation);
        mAddSoundLayout.setVisibility(View.VISIBLE);

        ViewCompat.animate(mFabTimeMenu).rotation(0.0F).withLayer().setDuration(300).setInterpolator(new OvershootInterpolator(10.0F)).withEndAction(new Runnable() {
            @Override
            public void run() {

                mFabTimeMenu.setImageResource(R.drawable.ic_time);
            }
        }).start();

        mShortVideoLayout.startAnimation(fabCloseAnimation);
        mMediumVideoLayout.startAnimation(fabCloseAnimation);
        mNormalVideoLayout.startAnimation(fabCloseAnimation);
        mLongVideoLayout.startAnimation(fabCloseAnimation);

        isFabMenuOpen = false;
    }

    private void selectVideo() {

        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("video/mp4");

        videoFromGalleryActivityResultLauncher.launch(intent);
    }

    private void requestStoragePermission() {

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {

            storagePermissionLauncher.launch(new String[]{android.Manifest.permission.READ_MEDIA_IMAGES, android.Manifest.permission.READ_MEDIA_VIDEO, android.Manifest.permission.ACCESS_MEDIA_LOCATION});

        } else {

            storagePermissionLauncher.launch(new String[]{android.Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.READ_EXTERNAL_STORAGE});
        }
    }

    private void playMp3() {

        stopMp3();

        Log.e("mp3", "playMp3");

        if (mediaPlayer == null && soundId != 0) {

            mediaPlayer = MediaPlayer.create(this, Uri.parse(soundUrl));
            mediaPlayer.start();

            mediaPlayer.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {

                @Override
                public void onCompletion(MediaPlayer mp) {

                    if (mediaPlayer != null) {

                        try {

                            stopMp3();

                        } catch (Exception e) {

                            e.printStackTrace();
                        }
                    }
                }
            });

        } else {

            if (mediaPlayer != null) {

                mediaPlayer.start();
            }
        }
    }

    private void stopMp3() {

        Log.e("mp3", "stopMp3");

        if (mediaPlayer != null) {

            if (isPaused) {

                mediaPlayer.pause();

            } else {

                mediaPlayer.reset();
                mediaPlayer.release();
                mediaPlayer = null;
            }
        }
    }

    private void pauseMp3() {

        Log.e("mp3", "pauseMp3");

        if (mediaPlayer != null) {

            mediaPlayer.pause();
        }
    }

    @Override
    protected void onStart() {

        Log.e("Dimon17", "CaptureActivity onStart");

        super.onStart();

//        finish();
//        startActivity(getIntent());
//        overridePendingTransition(0, 0);

        //mCameraView.g
    }

    @Override
    protected void onStop() {

        Log.e("Dimon17", "CaptureActivity onStop");

        super.onStop();
    }

    @Override
    protected void onDestroy() {

        Log.e("Dimon17", "CaptureActivity onDestroy");

        super.onDestroy();

        //mCameraView.destroy();

        stopMp3();
    }
}

